/*
 * 冰岛 (Bingdao) - Android 灵动岛
 * Copyright (c) 2026 casuallw (Gitee: casual-wear / GitHub: Casuallw)
 * All rights reserved. Licensed under the Bingdao Non-Commercial License 1.1.
 * 非商业许可：禁止商用、倒卖或收费分发。完整条款见项目根目录 LICENSE 文件。
 * https://gitee.com/casual-wear/bingdao
 */
package com.sihua.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Point;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** 首页：状态、开关、入口。 */
public class MainActivity extends Activity {

    private LinearLayout list;
    private boolean built;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Window win = getWindow();
        win.setStatusBarColor(Color.TRANSPARENT);
        win.setNavigationBarColor(Ui.BG);
        win.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        Point p = new Point();
        win.getWindowManager().getDefaultDisplay().getSize(p);
        FrameLayout root = new FrameLayout(this);
        root.setBackground(new Ui.GlowDrawable(p.x, p.y));
        ScrollView sv = new ScrollView(this);
        sv.setClipToPadding(false);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(Ui.dp(this, 20), Ui.dp(this, 52), Ui.dp(this, 20), Ui.dp(this, 30));
        sv.addView(list, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT));
        root.addView(sv, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        build();
        ensureIsland();
    }

    private void ensureIsland() {
        if (!Common.getB(this, Common.K_ISLAND, true)) return;
        if (!Common.hasOverlay(this)) return;
        try {
            Intent i = new Intent(this, IslandService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
        } catch (Exception e) {
            Toast.makeText(this, "灵动岛启动失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void section(String s) {
        TextView t = Ui.text(this, s, 11.5f, Ui.DIM, true);
        t.setLetterSpacing(0.18f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, 16);
        lp.bottomMargin = Ui.dp(this, 8);
        lp.leftMargin = Ui.dp(this, 4);
        list.addView(t, lp);
    }

    private LinearLayout clickable(LinearLayout row, View.OnClickListener l) {
        row.setClickable(true);
        row.setFocusable(true);
        row.setOnClickListener(l);
        Ui.press(row);
        return row;
    }

    private void build() {
        list.removeAllViews();

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(android.view.Gravity.CENTER_VERTICAL);
        head.addView(new Ui.Logo(this, Ui.dp(this, 46)),
                new LinearLayout.LayoutParams(Ui.dp(this, 46), Ui.dp(this, 46)));
        LinearLayout hc = new LinearLayout(this);
        hc.setOrientation(LinearLayout.VERTICAL);
        hc.addView(Ui.text(this, "冰岛", 26, Ui.TEXT, true));
        TextView sub = Ui.text(this, "冰岛 · v1.7.1", 12, Ui.SUB, false);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        slp.topMargin = Ui.dp(this, 5);
        hc.addView(sub, slp);
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        hlp.leftMargin = Ui.dp(this, 13);
        head.addView(hc, hlp);
        list.addView(head);

        section("权限");
        LinearLayout permCard = Ui.card(this);
        permCard.setPadding(Ui.dp(this, 14), Ui.dp(this, 4), Ui.dp(this, 14), Ui.dp(this, 4));
        permCard.addView(clickable(permRow("悬浮窗", "灵动岛显示在其他应用上层",
                Common.hasOverlay(this)), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Perm.overlay(MainActivity.this);
            }
        }));
        Ui.divider(this, permCard);
        permCard.addView(clickable(permRow("通知使用权", "读取消息、音乐与下载进度",
                Common.hasNotiListener(this)), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Perm.notiListener(MainActivity.this);
            }
        }));
        Ui.divider(this, permCard);
        permCard.addView(clickable(permRow("无障碍服务", "放开系统对悬浮窗的拦截",
                Common.hasA11y(this)), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Perm.a11y(MainActivity.this);
            }
        }));
        Ui.divider(this, permCard);
        permCard.addView(clickable(permRow("忽略电池优化", "降低后台被系统杀掉的可能",
                Common.batteryIgnored(this)), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Perm.battery(MainActivity.this);
            }
        }));
        list.addView(permCard);

        section("灵动岛");
        LinearLayout swCard = Ui.card(this);
        swCard.setPadding(Ui.dp(this, 14), Ui.dp(this, 6), Ui.dp(this, 14), Ui.dp(this, 6));
        final Switch island = Ui.toggle(this, Common.getB(this, Common.K_ISLAND, true));
        island.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton b, boolean c) {
                Common.setB(MainActivity.this, Common.K_ISLAND, c);
                Intent s = new Intent(MainActivity.this, IslandService.class);
                if (c) {
                    if (!Common.hasOverlay(MainActivity.this)) {
                        Perm.overlay(MainActivity.this);
                        return;
                    }
                    startForegroundService(s);
                } else {
                    s.setAction(Common.ACTION_STOP);
                    startService(s);
                }
            }
        });
        swCard.addView(Ui.row(this, "开启灵动岛", "消息 · 音乐 · 下载 · 充电", 0, island));
        Ui.divider(this, swCard);
        swCard.addView(clickable(Ui.row(this, "测试弹出", "发一条示例消息，先看效果", Ui.ACCENT, null),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        testIsland();
                    }
                }));
        Ui.divider(this, swCard);
        String look = (Common.getI(this, Common.K_SHAPE, 0) == 1 ? "刘海" : "胶囊")
                + " · " + Common.getI(this, Common.K_W, 139) + "×"
                + Common.getI(this, Common.K_H, 34) + "dp";
        swCard.addView(clickable(Ui.row(this, "岛设置", look, 0, null),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        startActivity(new Intent(MainActivity.this, SettingsActivity.class)
                                .putExtra("tab", 1));
                    }
                }));
        list.addView(swCard);

        LinearLayout keep = Ui.card(this);
        keep.setBackground(Common.round(0xFF10131B, 0x33FFB84D, Ui.dp(this, 18)));
        TextView kt = Ui.text(this, "别让系统把灵动岛清掉：在系统设置里允许「冰岛」自启动、"
                + "后台运行；最近任务里能看到「冰岛」的话，长按卡片点锁定。", 12, 0xFFE8C07A, false);
        kt.setLineSpacing(Ui.dp(this, 4), 1f);
        keep.addView(kt);
        keep.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                info("后台保活", "大多数系统会清理后台，两步能稳住：\n\n"
                        + "1. 系统设置 → 应用 → 冰岛 → 自启动 / 后台运行 → 允许\n"
                        + "2. 最近任务（多任务）里长按「冰岛」卡片 → 锁定\n\n"
                        + "不同品牌入口名称不一样，一般叫「自启动」「后台运行」「后台耗电管理」。"
                        + "本应用已从最近任务隐藏，看不到卡片时做第一步即可。");
            }
        });
        list.addView(keep);

        section("更多");
        LinearLayout more = Ui.card(this);
        more.setPadding(Ui.dp(this, 14), Ui.dp(this, 4), Ui.dp(this, 14), Ui.dp(this, 4));
        more.addView(clickable(Ui.row(this, "作者抖音", "抖音号 42351991718", Ui.VIOLET, null),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        author();
                    }
                }));
        Ui.divider(this, more);
        more.addView(clickable(Ui.row(this, "作者声明", "关于作者与这份作品", 0xFF5EE7FF, null),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        About.declaration(MainActivity.this);
                    }
                }));
        Ui.divider(this, more);
        more.addView(clickable(Ui.row(this, "关于应用", "许可 · 隐私 · 免责 · 禁止事项", Ui.SUB, null),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        About.legal(MainActivity.this);
                    }
                }));
        Ui.divider(this, more);
        more.addView(clickable(Ui.row(this, "赞助作者", "微信转账，感谢支持", 0xFFE8C07A, null),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        sponsor();
                    }
                }));
        Ui.divider(this, more);
        more.addView(clickable(Ui.row(this, "隐藏后台", "不出现在最近任务，可后台常驻", 0, null),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        info("隐藏后台",
                                "本版已把「冰岛」从最近任务列表隐藏（系统级设置，无法在应用内关闭）。\n\n"
                                        + "保活方式：前台服务 + 忽略电池优化。部分品牌（小米/华为/OPPO/vivo）"
                                        + "还需要在系统设置里允许「自启动」「后台运行」，否则重启后可能被清理。");
                    }
                }));
        list.addView(more);

        LinearLayout tip = Ui.card(this);
        tip.setBackground(Common.round(0xFF10131B, 0x225EE7FF, Ui.dp(this, 18)));
        TextView tt = Ui.text(this, "灵动岛不会自己乱弹：开启悬浮窗 + 通知使用权后，"
                + "收到消息、播放音乐、下载、充电时才会出现；也可以点上面的「测试弹出」。", 12, Ui.SUB, false);
        tt.setLineSpacing(Ui.dp(this, 4), 1f);
        tip.addView(tt);
        list.addView(tip);

        TextView foot = Ui.text(this, "用 agent 花了不少，求回血 🙏", 12, Ui.SUB, false);
        foot.setGravity(android.view.Gravity.CENTER);
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        flp.topMargin = Ui.dp(this, 6);
        flp.bottomMargin = Ui.dp(this, 18);
        list.addView(foot, flp);
    }

    private void testIsland() {
        if (!Common.hasOverlay(this)) {
            Perm.overlay(this);
            return;
        }
        if (!Common.getB(this, Common.K_ISLAND, true)) {
            Common.setB(this, Common.K_ISLAND, true);
        }
        Intent i = new Intent(this, IslandService.class);
        i.setAction(Common.ACTION_TEST);
        startForegroundService(i);
    }

    private LinearLayout permRow(String name, String desc, boolean ok) {
        TextView state = Ui.pill(this, ok ? "已开启" : "去开启", ok ? Ui.OK : Ui.WARN);
        return Ui.row(this, name, desc, ok ? Ui.OK : 0xFF3A3F4D, state);
    }

    private void author() {
        openDouyin();
    }

    private void openDouyin() {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("抖音号", "42351991718"));
        } catch (Exception ignored) {
        }
        Toast.makeText(this, "抖音号 42351991718 已复制，搜索里点用户即可关注",
                Toast.LENGTH_LONG).show();
        // 抖音号不是 uid，直接开 user/profile 会落到空白页；用搜索页定位账号
        String[] links = {
                "snssdk1128://search?keyword=42351991718",
                "https://www.douyin.com/search/42351991718"
        };
        for (String l : links) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(l)));
                return;
            } catch (Exception ignored) {
            }
        }
    }

    private void sponsor() {
        Sponsor.show(this);
    }

    private void info(String title, String msg) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(msg)
                .setPositiveButton("知道了", null).show();
    }
}
