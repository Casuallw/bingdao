/*
 * 冰岛 (Bingdao) - Android 灵动岛
 * Copyright (c) 2026 casuallw (Gitee: casual-wear / GitHub: Casuallw)
 * All rights reserved. Licensed under the Bingdao Non-Commercial License 1.1.
 * 非商业许可：禁止商用、倒卖或收费分发。完整条款见项目根目录 LICENSE 文件。
 * https://gitee.com/casual-wear/bingdao
 */
package com.sihua.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Point;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** 全部设置：灵动岛外观、内容、权限、后台、关于。 */
public class SettingsActivity extends Activity {

    private LinearLayout list;
    private int tab;
    private final android.os.Handler handler = new android.os.Handler(android.os.Looper.getMainLooper());
    private Runnable pending;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Window win = getWindow();
        win.setStatusBarColor(Color.TRANSPARENT);
        win.setNavigationBarColor(Ui.BG);
        win.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        Point p = new Point();
        win.getWindowManager().getDefaultDisplay().getSize(p);
        FrameLayout root = new FrameLayout(this);
        root.setBackground(new Ui.GlowDrawable(p.x, p.y));
        ScrollView sv = new ScrollView(this);
        sv.setClipToPadding(false);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(Ui.dp(this, 20), Ui.dp(this, 52), Ui.dp(this, 20), Ui.dp(this, 30));
        sv.addView(list, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT));
        root.addView(sv, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        tab = getIntent().getIntExtra("tab", 0);
        setContentView(root);
        build();
    }

    private void build() {
        list.removeAllViews();

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView back = Ui.text(this, "‹", 30, Ui.TEXT, false);
        back.setPadding(0, 0, Ui.dp(this, 12), Ui.dp(this, 4));
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        top.addView(back);
        top.addView(Ui.text(this, "设置", 22, Ui.TEXT, true));
        list.addView(top);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = Ui.dp(this, 14);
        tlp.bottomMargin = Ui.dp(this, 2);
        tabs.setLayoutParams(tlp);
        tabs.addView(tabChip("通用", 0));
        tabs.addView(tabChip("外观", 1));
        list.addView(tabs);

        if (tab == 1) buildLook();
        else buildGeneral();
    }

    private View tabChip(String name, final int idx) {
        boolean on = tab == idx;
        TextView t = Ui.text(this, name, 13, on ? 0xFF07080C : Ui.SUB, on);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(Ui.dp(this, 18));
        g.setColor(on ? Ui.ACCENT : 0xFF171B24);
        if (!on) g.setStroke(Ui.dp(this, 1), 0x1AFFFFFF);
        t.setBackground(g);
        t.setPadding(Ui.dp(this, 22), Ui.dp(this, 8), Ui.dp(this, 22), Ui.dp(this, 8));
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tab = idx;
                build();
                if (tab == 1) previewIsland(false);
                else if (!Common.getB(SettingsActivity.this, Common.K_PIN, false)) {
                    endPreview();
                }
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.rightMargin = Ui.dp(this, 8);
        t.setLayoutParams(lp);
        return t;
    }

    private void buildLook() {
        section("形状与尺寸");
        LinearLayout look = Ui.card(this);
        look.addView(Ui.text(this, "形状", 13, Ui.SUB, false));
        LinearLayout shapeRow = chips(new String[]{"胶囊", "刘海"},
                Common.getI(this, Common.K_SHAPE, 0), Common.K_SHAPE, new int[]{0, 1});
        LinearLayout.LayoutParams shapeLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        shapeLp.topMargin = Ui.dp(this, 9);
        look.addView(shapeRow, shapeLp);
        look.addView(stepper("高度", Common.K_H, 30, 70, 34, "dp"));
        look.addView(stepper("长度（收起）", Common.K_W, 24, 280, 139, "dp"));
        look.addView(stepper("左右偏移", Common.K_X, -120, 120, 0, "dp"));
        look.addView(Ui.text(this, "副岛位置", 13, Ui.SUB, false));
        look.addView(sidePicker());
        look.addView(stepper("距顶部", Common.K_Y, 0, 240, 3, "dp"));
        look.addView(stepper("弹岛停留", Common.K_TAU, 3, 60, 5, "s"));
        look.addView(stepper("展开动画时长", Common.K_EXPAND_MS, 200, 1200, 520, "ms"));
        look.addView(stepper("消失动画时长", Common.K_DISMISS_MS, 200, 1000, 520, "ms"));
        look.addView(stepper("展开消息行数", Common.K_LINES, 1, 4, 2, "行"));
        list.addView(look);

        section("收到消息时");
        LinearLayout pop = Ui.card(this);
        pop.addView(Ui.text(this, "弹岛形态", 13, Ui.SUB, false));
        pop.addView(popupPicker());
        list.addView(pop);
        list.addView(pad(Ui.text(this,
                "调参数时灵动岛会临时停在屏幕上，离开设置页自动收起。",
                11.5f, Ui.DIM, false), 10));

        section("音乐");
        LinearLayout m1 = Ui.card(this);
        m1.addView(Ui.row(this, "音乐律动", "播放时在岛上显示律动", Ui.VIOLET, toggle(Common.K_MUSIC, true)));
        Ui.divider(this, m1);
        final Switch micSw = Ui.toggle(this, Common.getB(this, Common.K_MIC, false));
        micSw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean v) {
                if (!v) {
                    Common.setB(SettingsActivity.this, Common.K_MIC, false);
                    applySoon();
                    return;
                }
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                        != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 11);
                    return;
                }
                if (Common.getI(SettingsActivity.this, Common.K_MIC_MODE, 0) == 2
                        && Build.VERSION.SDK_INT >= 29) {
                    requestSystemAudio();
                    return;
                }
                Common.setB(SettingsActivity.this, Common.K_MIC, true);
                applySoon();
            }
        });
        m1.addView(clickRow(Ui.row(this, "真实音律",
                "跟随系统播放的声音，可在下方选来源", Ui.ACCENT, micSw),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        micSw.toggle();
                    }
                }));
        Ui.divider(this, m1);
        m1.addView(Ui.row(this, "多颜色可视化", "按封面颜色做渐变彩虹条", Ui.SUB, toggle(Common.K_COLORFUL, false)));
        Ui.divider(this, m1);
        m1.addView(Ui.row(this, "高分辨率可视化", "条数变密，占用宽度不变", Ui.SUB, toggle(Common.K_HIRES, false)));
        Ui.divider(this, m1);
        m1.addView(Ui.row(this, "封面取色", "高亮色取自专辑封面，默认蓝色", Ui.SUB, toggle(Common.K_COVER, false)));

        Ui.divider(this, m1);
        m1.addView(clickRow(Ui.row(this, "音律来源", micModeLabel(), Ui.VIOLET,
                Ui.text(this, "选择 ›", 12, Ui.DIM, false)), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickMicMode();
            }
        }));
        list.addView(m1);
    }

    private void buildGeneral() {
        section("灵动岛");
        LinearLayout i1 = Ui.card(this);
        i1.addView(Ui.row(this, "开启灵动岛", "在状态栏下方显示悬浮胶囊", 0,
                toggle(Common.K_ISLAND, true)));
        Ui.divider(this, i1);
        i1.addView(Ui.row(this, "永久常驻", "无事件时显示一条短胶囊", Ui.VIOLET,
                toggle(Common.K_PIN, false)));
        Ui.divider(this, i1);
        i1.addView(clickRow(Ui.row(this, "圆形常驻岛", idleCircleLabel(), 0xFF5EE7FF,
                Ui.text(this, "调整 ›", 12, Ui.DIM, false)), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                idleCircleDialog();
            }
        }));
        Ui.divider(this, i1);
        i1.addView(Ui.row(this, "左右滑动切歌", "收起时左滑上一首、右滑下一首", Ui.ACCENT,
                toggle(Common.K_SWIPE, true)));
        Ui.divider(this, i1);
        i1.addView(Ui.row(this, "前台时自动隐藏", "通知来自的 App 切到前台时，岛自动消失",
                Ui.SUB, toggle(Common.K_FG_HIDE, false)));
        Ui.divider(this, i1);
        i1.addView(Ui.row(this, "多岛（事件分裂）", "主事件显示时，新事件从旁边分裂成小圆",
                Ui.VIOLET, toggle(Common.K_MULTI, true)));
        Ui.divider(this, i1);
        i1.addView(Ui.row(this, "快捷回复", "展开消息后点一下，直接弹键盘回复",
                Ui.ACCENT, toggle(Common.K_REPLY, false)));
        i1.addView(pad(Ui.text(this, "部分消息（群通知、合集通知）本身没有回复入口，"
                + "这类只能打开应用回复。", 11f, Ui.DIM, false), 6));
        Ui.divider(this, i1);
        i1.addView(clickRow(Ui.row(this, "快捷应用", quickLabel(), 0xFF5EE7FF,
                Ui.text(this, "选择 ›", 12, Ui.DIM, false)), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickQuickApp();
            }
        }));
        Ui.divider(this, i1);
        i1.addView(clickRow(Ui.row(this, "长按动作",
                longLabel() + " · 有事件时长按灵动岛", 0xFF9A6BFF,
                Ui.text(this, "选择 ›", 12, Ui.DIM, false)), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickLongAction();
            }
        }));
        Ui.divider(this, i1);
        i1.addView(clickRow(Ui.row(this, "系统事件", "解锁 · 耳机 · 电量 · 铃声", 0xFF5EE7FF,
                Ui.text(this, "设置 ›", 12, Ui.DIM, false)), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SettingsActivity.this, SysEventsActivity.class));
            }
        }));
        Ui.divider(this, i1);
        i1.addView(clickRow(Ui.row(this, "测试弹出", "发一条示例消息看效果", Ui.ACCENT, null),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        test();
                    }
                }));
        list.addView(i1);

        section("显示内容");
        LinearLayout c1 = Ui.card(this);
        c1.addView(Ui.row(this, "消息通知", "应用通知弹出", Ui.ACCENT, toggle(Common.K_NOTI, true)));
        Ui.divider(this, c1);
        c1.addView(Ui.row(this, "下载进度", "持续显示下载百分比", Ui.OK, toggle(Common.K_DL, true)));
        list.addView(c1);

        section("权限");
        LinearLayout p1 = Ui.card(this);
        p1.setPadding(Ui.dp(this, 14), Ui.dp(this, 4), Ui.dp(this, 14), Ui.dp(this, 4));
        p1.addView(permRow("悬浮窗", "显示灵动岛", Common.hasOverlay(this),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Perm.overlay(SettingsActivity.this);
                    }
                }));
        Ui.divider(this, p1);
        p1.addView(permRow("通知使用权", "读取消息 / 音乐", Common.hasNotiListener(this),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Perm.notiListener(SettingsActivity.this);
                    }
                }));
        Ui.divider(this, p1);
        p1.addView(permRow("无障碍服务", "放开系统对悬浮窗的拦截", Common.hasA11y(this),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Perm.a11y(SettingsActivity.this);
                    }
                }));
        Ui.divider(this, p1);
        p1.addView(permRow("自启动 / 后台运行", "允许开机自启、不被清理", false,
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Perm.vivoPopup(SettingsActivity.this);
                    }
                }));
        Ui.divider(this, p1);
        p1.addView(permRow("忽略电池优化", "后台常驻", Common.batteryIgnored(this),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Perm.battery(SettingsActivity.this);
                    }
                }));
        list.addView(p1);

        LinearLayout lockTip = Ui.card(this);
        lockTip.setBackground(Common.round(0xFF10131B, 0x225EE7FF, Ui.dp(this, 18)));
        TextView lt = Ui.text(this,
                "后台保活建议：在系统设置里允许「冰岛」自启动 / 后台运行；"
                        + "最近任务里能看到卡片的长按锁定。不同品牌入口名称不同，"
                        + "一般在「应用管理」「电池」「后台耗电管理」里。", 11.5f, Ui.SUB, false);
        lt.setLineSpacing(Ui.dp(this, 4), 1f);
        lockTip.addView(lt);
        list.addView(lockTip);

        section("后台");
        LinearLayout b1 = Ui.card(this);
        b1.addView(Ui.row(this, "隐藏后台", "已从最近任务中隐藏", Ui.OK, null));
        Ui.divider(this, b1);
        b1.addView(Ui.row(this, "前台服务", "灵动岛运行时显示常驻通知", Ui.SUB, null));
        Ui.divider(this, b1);
        b1.addView(Ui.row(this, "开机自启", "重启后自动恢复灵动岛", Ui.SUB, null));
        list.addView(b1);

        section("关于");
        LinearLayout ab = Ui.card(this);
        ab.addView(clickRow(Ui.row(this, "作者抖音", "42351991718 · 点击关注", Ui.VIOLET, null),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        author();
                    }
                }));
        Ui.divider(this, ab);
        ab.addView(clickRow(Ui.row(this, "作者声明", "关于作者与这份作品", 0xFF5EE7FF, null),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        About.declaration(SettingsActivity.this);
                    }
                }));
        Ui.divider(this, ab);
        ab.addView(clickRow(Ui.row(this, "关于应用", "许可 · 隐私 · 免责 · 禁止事项", Ui.SUB, null),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        About.legal(SettingsActivity.this);
                    }
                }));
        Ui.divider(this, ab);
        ab.addView(clickRow(Ui.row(this, "赞助作者", "微信转账，感谢支持", 0xFFE8C07A, null),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        sponsor();
                    }
                }));
        Ui.divider(this, ab);
        ab.addView(Ui.row(this, "版本", "1.7.1 · 2026.11", Ui.SUB, null));
        list.addView(ab);
    }

    /** 收到消息时的形态：两张可选卡片 + 圆点单选。 */
    private LinearLayout sidePicker() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rlp.topMargin = Ui.dp(this, 10);
        row.setLayoutParams(rlp);
        String[] names = {"副岛在右", "副岛在左"};
        int sel = Common.getI(this, Common.K_MULTI_SIDE, 0);
        for (int i = 0; i < 2; i++) {
            final int idx = i;
            boolean on = sel == i;
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
            card.setPadding(Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10));
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(Ui.dp(this, 16));
            g.setColor(on ? 0x145EE7FF : 0xFF12151D);
            g.setStroke(Ui.dp(this, on ? 1.5f : 1), on ? 0x995EE7FF : 0x14FFFFFF);
            card.setBackground(g);
            FrameLayout box = new FrameLayout(this);
            box.addView(new MiniIsland(this, false, i),
                    new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,
                            Ui.dp(this, 74)));
            card.addView(box, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this, 74)));
            card.addView(Ui.text(this, names[i], 13, on ? Ui.TEXT : Ui.SUB, on));
            card.addView(new Dot(this, on),
                    new LinearLayout.LayoutParams(Ui.dp(this, 18), Ui.dp(this, 18)) {{
                        topMargin = Ui.dp(SettingsActivity.this, 8);
                    }});
            card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Common.setI(SettingsActivity.this, Common.K_MULTI_SIDE, idx);
                    build();
                    previewIsland(false);
                }
            });
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            clp.rightMargin = i == 0 ? Ui.dp(this, 10) : 0;
            clp.leftMargin = i == 1 ? Ui.dp(this, 10) : 0;
            row.addView(card, clp);
        }
        return row;
    }

    private LinearLayout popupPicker() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rlp.topMargin = Ui.dp(this, 10);
        row.setLayoutParams(rlp);
        String[] names = {"缩小版", "展开版"};
        String[] tips = {"只露图标", "显示内容"};
        int sel = Common.getI(this, Common.K_POPUP, 1);
        for (int i = 0; i < 2; i++) {
            final int idx = i;
            boolean on = sel == i;
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
            card.setPadding(Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10));
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(Ui.dp(this, 16));
            g.setColor(on ? 0x145EE7FF : 0xFF12151D);
            g.setStroke(Ui.dp(this, on ? 1.5f : 1), on ? 0x995EE7FF : 0x14FFFFFF);
            card.setBackground(g);
            FrameLayout box = new FrameLayout(this);
            box.addView(new MiniIsland(this, i == 1),
                    new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,
                            Ui.dp(this, 74)));
            card.addView(box, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this, 74)));
            TextView nm = Ui.text(this, names[i], 13, on ? Ui.TEXT : Ui.SUB, on);
            LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            nlp.topMargin = Ui.dp(this, 6);
            card.addView(nm, nlp);
            TextView tp = Ui.text(this, tips[i], 10.5f, Ui.DIM, false);
            card.addView(tp);
            card.addView(new Dot(this, on),
                    new LinearLayout.LayoutParams(Ui.dp(this, 18), Ui.dp(this, 18)) {{
                        topMargin = Ui.dp(SettingsActivity.this, 8);
                    }});
            card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Common.setI(SettingsActivity.this, Common.K_POPUP, idx);
                    build();
                }
            });
            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            clp.rightMargin = i == 0 ? Ui.dp(this, 10) : 0;
            clp.leftMargin = i == 1 ? Ui.dp(this, 10) : 0;
            row.addView(card, clp);
        }
        return row;
    }

    private static class Dot extends View {
        private final boolean on;
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);

        Dot(Context c, boolean on) {
            super(c);
            this.on = on;
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(Common.dp(c, 1.5f));
        }

        @Override
        protected void onDraw(Canvas cv) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float r = Math.min(cx, cy) - Common.dp(getContext(), 1f);
            if (on) {
                fill.setColor(Ui.ACCENT);
                cv.drawCircle(cx, cy, r, fill);
                fill.setColor(0xFF0B0D12);
                cv.drawCircle(cx, cy, r * 0.42f, fill);
            } else {
                ring.setColor(0x55FFFFFF);
                cv.drawCircle(cx, cy, r - Common.dp(getContext(), 0.8f), ring);
            }
        }
    }

    /** 两张卡片里的小岛示意。 */
    private static class MiniIsland extends View {
        private final boolean big;
        private final int subSide;
        private final Paint body = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint accent = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF box = new RectF();

        MiniIsland(Context c, boolean big) {
            this(c, big, -1);
        }

        MiniIsland(Context c, boolean big, int subSide) {
            super(c);
            this.big = big;
            this.subSide = subSide;
            body.setColor(0xFF000000);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(Common.dp(c, 1f));
            line.setColor(0x665EE7FF);
            accent.setColor(0xFF5EE7FF);
        }

        private float dp(float v) {
            return Common.dp(getContext(), v);
        }

        @Override
        protected void onDraw(Canvas cv) {
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float w = big ? Math.min(getWidth() - dp(14), dp(132))
                    : dp(76);
            float h = big ? dp(46) : dp(24);
            box.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f);
            cv.drawRoundRect(box, h / 2f, h / 2f, body);
            cv.drawRoundRect(box, h / 2f, h / 2f, line);
            float ir = big ? dp(13) : dp(7);
            float ix = box.left + dp(8) + ir;
            cv.drawCircle(ix, cy, ir, accent);
            if (big) {
                line.setStrokeWidth(dp(2f));
                cv.drawLine(ix + ir + dp(7), cy - dp(6),
                        box.right - dp(14), cy - dp(6), line);
                line.setStrokeWidth(dp(1.5f));
                cv.drawLine(ix + ir + dp(7), cy + dp(7),
                        box.right - dp(24), cy + dp(7), line);
            } else {
                accent.setStrokeWidth(dp(2f));
                if (subSide >= 0) {
                    float r = dp(7);
                    float sx = subSide == 1 ? box.left - dp(7) - r : box.right + dp(7) + r;
                    accent.setStyle(Paint.Style.FILL);
                    accent.setColor(0xFF000000);
                    cv.drawCircle(sx, cy, r, accent);
                    accent.setStyle(Paint.Style.STROKE);
                    accent.setStrokeWidth(dp(1f));
                    accent.setColor(0x995EE7FF);
                    cv.drawCircle(sx, cy, r, accent);
                    accent.setStyle(Paint.Style.FILL);
                    accent.setColor(0xFF5EE7FF);
                    cv.drawCircle(sx, cy, r * 0.42f, accent);
                    return;
                }
                accent.setStrokeWidth(dp(2f));
                float rx = box.right - dp(12);
                cv.drawLine(rx - dp(7), cy - dp(5), rx - dp(7),
                        cy + dp(5), accent);
                cv.drawLine(rx - dp(2), cy - dp(8), rx - dp(2),
                        cy + dp(8), accent);
            }
        }
    }

    private LinearLayout chips(String[] labels, int selected, final String key, final int[] values) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            boolean on = i == selected;
            TextView t = Ui.text(this, labels[i], 12.5f, on ? 0xFF07080C : Ui.SUB, on);
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(Ui.dp(this, 16));
            g.setColor(on ? Ui.ACCENT : 0xFF1B1F28);
            t.setBackground(g);
            t.setPadding(Ui.dp(this, 16), Ui.dp(this, 7), Ui.dp(this, 16), Ui.dp(this, 7));
            t.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Common.setI(SettingsActivity.this, key, values[idx]);
                    reload();
                    build();
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.rightMargin = Ui.dp(this, 8);
            row.addView(t, lp);
        }
        return row;
    }

    private LinearLayout stepper(String name, String key, int min, int max, int def, String unit) {
        final String k = key;
        final int lo = min, hi = max;
        final String u = unit;
        final int[] cur = {Common.clamp(Common.getI(this, k, def), lo, hi)};

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        blp.topMargin = Ui.dp(this, 14);
        box.setLayoutParams(blp);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(android.view.Gravity.CENTER_VERTICAL);
        head.addView(Ui.text(this, name, 13, Ui.SUB, false),
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        final TextView val = Ui.text(this, cur[0] + " " + u, 13, Ui.ACCENT, false);
        val.setGravity(android.view.Gravity.CENTER);
        head.addView(val, new LinearLayout.LayoutParams(Ui.dp(this, 58),
                LinearLayout.LayoutParams.WRAP_CONTENT));

        final SeekBar sb = new SeekBar(this);
        sb.setMax(hi - lo);
        sb.setProgress(cur[0] - lo);

        TextView minus = circleBtn("−");
        TextView plus = circleBtn("+");
        head.addView(minus, new LinearLayout.LayoutParams(Ui.dp(this, 32), Ui.dp(this, 32)));
        head.addView(new View(this), new LinearLayout.LayoutParams(Ui.dp(this, 6), 1));
        head.addView(plus, new LinearLayout.LayoutParams(Ui.dp(this, 32), Ui.dp(this, 32)));
        box.addView(head);

        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cur[0] = Math.max(lo, cur[0] - 1);
                val.setText(cur[0] + " " + u);
                sb.setProgress(cur[0] - lo);
                Common.setI(SettingsActivity.this, k, cur[0]);
                applySoon();
            }
        });
        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cur[0] = Math.min(hi, cur[0] + 1);
                val.setText(cur[0] + " " + u);
                sb.setProgress(cur[0] - lo);
                Common.setI(SettingsActivity.this, k, cur[0]);
                applySoon();
            }
        });

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int prog, boolean fromUser) {
                cur[0] = prog + lo;
                val.setText(cur[0] + " " + u);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                Common.setI(SettingsActivity.this, k, cur[0]);
                applySoon();
            }
        });
        box.addView(sb);
        return box;
    }

    private TextView circleBtn(String s) {
        TextView t = Ui.text(this, s, 18, Ui.TEXT, false);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(0xFF1B1F28);
        g.setStroke(Ui.dp(this, 1), 0x22FFFFFF);
        t.setBackground(g);
        t.setGravity(android.view.Gravity.CENTER);
        Ui.press(t);
        return t;
    }

    private boolean editingCircle;

    private String idleCircleLabel() {
        if (!Common.getB(this, Common.K_IDLE_CIRCLE, false)) return "未开启";
        int d = Common.clamp(Common.getI(this, Common.K_IDLE_SIZE, 34), 20, 60);
        String pos = Common.getB(this, Common.K_IDLE_LINK, true)
                ? "跟随缩小岛中心" : "单独位置";
        return "已开启 · " + d + "dp · " + pos;
    }

    /** 圆形常驻岛：打开开关、调大小、调位置。 */
    private void idleCircleDialog() {
        final LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(this, 20), Ui.dp(this, 8), Ui.dp(this, 20), Ui.dp(this, 4));

        final Switch on = Ui.toggle(this, Common.getB(this, Common.K_IDLE_CIRCLE, false));
        on.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean v) {
                Common.setB(SettingsActivity.this, Common.K_IDLE_CIRCLE, v);
                previewIdle();
            }
        });
        box.addView(Ui.row(this, "启用圆形常驻岛", "常驻时只显示一个圆，点一下展开成卡片", 0xFF5EE7FF, on));

        final Switch link = Ui.toggle(this, Common.getB(this, Common.K_IDLE_LINK, true));
        link.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean v) {
                Common.setB(SettingsActivity.this, Common.K_IDLE_LINK, v);
                previewIdle();
            }
        });
        box.addView(Ui.row(this, "跟随缩小岛中心", "关掉后可单独调圆心的左右 / 上下", Ui.ACCENT, link));

        box.addView(stepper("直径", Common.K_IDLE_SIZE, 20, 60, 34, "dp"));
        box.addView(stepper("左右位置", Common.K_IDLE_X, -160, 160, 0, "dp"));
        box.addView(stepper("上下位置", Common.K_IDLE_Y, -160, 160, 0, "dp"));
        box.addView(pad(Ui.text(this, "开关关闭时，左右 / 上下位置不生效；"
                + "触控范围比画出来的圆略大一圈。", 11f, Ui.DIM, false), 8));

        final ScrollView sv = new ScrollView(this);
        sv.addView(box);
        AlertDialog.Builder bd = new AlertDialog.Builder(this);
        bd.setTitle("圆形常驻岛");
        bd.setView(sv);
        bd.setNegativeButton("关闭", null);
        final AlertDialog dlg = bd.create();
        dlg.setOnShowListener(new android.content.DialogInterface.OnShowListener() {
            @Override
            public void onShow(android.content.DialogInterface d) {
                editingCircle = true;
                previewIdle();
            }
        });
        dlg.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(android.content.DialogInterface d) {
                editingCircle = false;
                reload();
            }
        });
        dlg.show();
    }

    private String micModeLabel() {
        int m = Common.getI(this, Common.K_MIC_MODE, 0);
        String base = m == 1 ? "仅麦克风" : m == 2 ? "系统音（录屏授权）" : "自动（系统音→麦克风）";
        if (m == 0 && Common.getB(this, Common.K_VIS_FAILED, false)) {
            base += " · 本机系统音不可用";
        }
        return base;
    }

    private void pickMicMode() {
        final String[] items = {"自动（系统音 → 麦克风）", "仅麦克风", "系统音（需录屏授权）"};
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("音律来源");
        b.setSingleChoiceItems(items, Common.getI(this, Common.K_MIC_MODE, 0),
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        d.dismiss();
                        if (which == 2) {
                            if (Build.VERSION.SDK_INT < 29) {
                                Toast.makeText(SettingsActivity.this,
                                        "Android 10 以下不支持系统内录", Toast.LENGTH_SHORT).show();
                                return;
                            }
                            Common.setB(SettingsActivity.this, Common.K_VIS_FAILED, false);
                            Common.setI(SettingsActivity.this, Common.K_MIC_MODE, 2);
                            requestSystemAudio();
                            return;
                        }
                        Common.setI(SettingsActivity.this, Common.K_MIC_MODE, which);
                        Common.setB(SettingsActivity.this, Common.K_VIS_FAILED, false);
                        applySoon();
                    }
                });
        b.setNegativeButton("取消", null);
        b.show();
    }

    private static final int REQ_PROJECTION = 21;

    private void requestSystemAudio() {
        try {
            android.media.projection.MediaProjectionManager mpm =
                    (android.media.projection.MediaProjectionManager)
                            getSystemService(MEDIA_PROJECTION_SERVICE);
            if (mpm == null) return;
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION);
        } catch (Exception e) {
            Toast.makeText(this, "无法申请录屏授权：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PROJECTION) return;
        if (res != RESULT_OK || data == null) {
            Common.setI(this, Common.K_MIC_MODE, 0);
            Toast.makeText(this, "没有授权，已回到自动模式", Toast.LENGTH_SHORT).show();
            reload();
            return;
        }
        try {
            Intent i = new Intent(this, IslandService.class);
            i.setAction(Common.ACTION_PROJECTION);
            i.putExtra("code", res);
            i.putExtra("data", data);
            startForegroundService(i);
            Common.setB(this, Common.K_MIC, true);
            Common.setI(this, Common.K_MIC_MODE, 2);
            applySoon();
        } catch (Exception e) {
            Toast.makeText(this, "启动系统音失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void previewIdle() {
        if (!Common.getB(this, Common.K_ISLAND, true)) return;
        if (!Common.hasOverlay(this)) return;
        try {
            Intent i = new Intent(this, IslandService.class);
            i.setAction(Common.ACTION_PREVIEW_IDLE);
            startForegroundService(i);
        } catch (Exception ignored) {
        }
    }

    private void applySoon() {
        if (editingCircle) {
            previewIdle();
            return;
        }
        if (pending != null) handler.removeCallbacks(pending);
        pending = new Runnable() {
            @Override
            public void run() {
                reload();
            }
        };
        handler.postDelayed(pending, 260);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (tab == 1) previewIsland(false);
    }

    @Override
    protected void onStop() {
        if (!Common.getB(this, Common.K_PIN, false)) endPreview();
        super.onStop();
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] p, int[] r) {
        super.onRequestPermissionsResult(req, p, r);
        if (req == 11) {
            boolean ok = r.length > 0 && r[0] == PackageManager.PERMISSION_GRANTED;
            if (!ok) {
                Common.setB(this, Common.K_MIC, false);
                Toast.makeText(this, "没有录音权限，系统音律用不了", Toast.LENGTH_LONG).show();
                build();
            }
            reload();
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private void reload() {
        previewIsland(true);
    }

    /** 离开设置页：撤掉预览（开了永久常驻就不撤）。 */
    private void endPreview() {
        try {
            Intent i = new Intent(this, IslandService.class);
            i.setAction(Common.ACTION_UNPREVIEW);
            startService(i);
        } catch (Exception ignored) {
        }
    }

    /** 调试外观：直接弹岛并常驻，直到关掉总开关。 */
    private void previewIsland(boolean ask) {
        if (!Common.getB(this, Common.K_ISLAND, true)) return;
        if (!Common.hasOverlay(this)) {
            if (ask) Perm.overlay(this);
            return;
        }
        try {
            Intent i = new Intent(this, IslandService.class);
            i.setAction(Common.ACTION_PREVIEW);
            startForegroundService(i);
        } catch (Exception ignored) {
        }
    }

    private LinearLayout pad(View v, int topDp) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, topDp);
        box.addView(v, lp);
        return box;
    }

    private void test() {
        if (!Common.hasOverlay(this)) {
            Perm.overlay(this);
            return;
        }
        Intent i = new Intent(this, IslandService.class);
        i.setAction(Common.ACTION_TEST);
        startForegroundService(i);
    }

    private void section(String s) {
        TextView t = Ui.text(this, s, 11.5f, Ui.DIM, true);
        t.setLetterSpacing(0.18f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, 16);
        lp.bottomMargin = Ui.dp(this, 8);
        lp.leftMargin = Ui.dp(this, 4);
        list.addView(t, lp);
    }

    private LinearLayout clickRow(LinearLayout row, View.OnClickListener l) {
        row.setClickable(true);
        row.setFocusable(true);
        row.setOnClickListener(l);
        Ui.press(row);
        return row;
    }

    private LinearLayout permRow(String name, String desc, boolean ok, View.OnClickListener l) {
        TextView state = Ui.pill(this, ok ? "已开启" : "去开启", ok ? Ui.OK : Ui.WARN);
        return clickRow(Ui.row(this, name, desc, ok ? Ui.OK : 0xFF3A3F4D, state), l);
    }

    private String quickLabel() {
        String raw = Common.getS(this, Common.K_QUICK_PKG, "");
        int n = 0;
        for (String p : raw.split(",")) if (p.trim().length() > 0) n++;
        if (n == 0) return "常驻岛单击打开 · 未选择";
        return "已选 " + n + " 个 · 1 个直接打开，多个展开选择";
    }

    private String longLabel() {
        int a = Common.getI(this, Common.K_LONG, 0);
        return a == 1 ? "隐藏灵动岛" : a == 2 ? "保存截图" : "打开快捷应用";
    }

    private void pickQuickApp() {
        final android.content.pm.PackageManager pm = getPackageManager();
        final java.util.List<String> pkgs = new java.util.ArrayList<String>();
        final java.util.List<String> names = new java.util.ArrayList<String>();
        final java.util.List<android.graphics.drawable.Drawable> icons =
                new java.util.ArrayList<android.graphics.drawable.Drawable>();
        android.content.Intent main = new android.content.Intent(
                android.content.Intent.ACTION_MAIN).addCategory(
                android.content.Intent.CATEGORY_LAUNCHER);
        java.util.List<android.content.pm.ResolveInfo> all =
                pm.queryIntentActivities(main, 0);
        java.util.HashSet<String> seen = new java.util.HashSet<String>();
        for (android.content.pm.ResolveInfo ri : all) {
            String p = ri.activityInfo.packageName;
            if (!seen.add(p) || p.equals(getPackageName())) continue;
            pkgs.add(p);
            names.add(String.valueOf(ri.loadLabel(pm)));
            try {
                icons.add(pm.getApplicationIcon(p));
            } catch (Exception e) {
                icons.add(null);
            }
        }
        java.util.LinkedHashMap<String, Integer> idx =
                new java.util.LinkedHashMap<String, Integer>();
        for (int i = 0; i < names.size(); i++) idx.put(names.get(i), i);
        java.util.List<String> order = new java.util.ArrayList<String>(idx.keySet());
        java.util.Collections.sort(order, String.CASE_INSENSITIVE_ORDER);

        final java.util.LinkedHashSet<String> sel = new java.util.LinkedHashSet<String>();
        for (String t : Common.getS(this, Common.K_QUICK_PKG, "").split(",")) {
            String v = t.trim();
            if (v.length() > 0) sel.add(v);
        }

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        final EditText search = new EditText(this);
        search.setHint("搜索应用");
        search.setSingleLine(true);
        search.setTextSize(14);
        search.setTextColor(Ui.TEXT);
        search.setHintTextColor(Ui.DIM);
        search.setBackgroundColor(0xFF171A23);
        search.setPadding(Ui.dp(this, 16), Ui.dp(this, 10), Ui.dp(this, 16), Ui.dp(this, 10));
        box.addView(search, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this, 46)));

        final android.widget.ListView lv = new android.widget.ListView(this);
        lv.setDividerHeight(0);
        lv.setBackgroundColor(Ui.CARD);
        final String[] filtered = new String[0];
        final AppPickAdapter adapter = new AppPickAdapter(pkgs, names, icons, sel,
                new java.util.ArrayList<String>());
        lv.setAdapter(adapter);
        box.addView(lv, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this, 380)));
        search.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(android.text.Editable e) {
                adapter.setQuery(e.toString());
            }
        });

        new AlertDialog.Builder(this)
                .setTitle("快捷应用（可多选）")
                .setView(box)
                .setPositiveButton("保存", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        StringBuilder ps = new StringBuilder();
                        StringBuilder ns = new StringBuilder();
                        for (String p : sel) {
                            if (ps.length() > 0) ps.append(',');
                            ps.append(p);
                            int i = pkgs.indexOf(p);
                            if (i >= 0) {
                                if (ns.length() > 0) ns.append(',');
                                ns.append(names.get(i));
                            }
                        }
                        Common.setS(SettingsActivity.this, Common.K_QUICK_PKG,
                                ps.toString());
                        Common.setS(SettingsActivity.this, Common.K_QUICK_NAME,
                                ns.toString());
                        build();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** 快捷应用多选列表：图标 + 名称 + 勾选。 */
    private class AppPickAdapter extends android.widget.BaseAdapter {
        private final java.util.List<String> pkgs;
        private final java.util.List<String> names;
        private final java.util.List<android.graphics.drawable.Drawable> icons;
        private final java.util.LinkedHashSet<String> sel;
        private final java.util.List<Integer> shown = new java.util.ArrayList<Integer>();
        private String query = "";

        AppPickAdapter(java.util.List<String> p, java.util.List<String> n,
                       java.util.List<android.graphics.drawable.Drawable> ic,
                       java.util.LinkedHashSet<String> s,
                       java.util.List<String> unused) {
            pkgs = p;
            names = n;
            icons = ic;
            sel = s;
            refilter();
        }

        void setQuery(String q) {
            query = q == null ? "" : q.toLowerCase();
            refilter();
            notifyDataSetChanged();
        }

        private void refilter() {
            shown.clear();
            for (int i = 0; i < pkgs.size(); i++) {
                if (query.length() == 0
                        || names.get(i).toLowerCase().contains(query)) {
                    shown.add(i);
                }
            }
        }

        @Override
        public int getCount() {
            return shown.size();
        }

        @Override
        public Object getItem(int position) {
            return names.get(shown.get(position));
        }

        @Override
        public long getItemId(int position) {
            return shown.get(position);
        }

        @Override
        public View getView(int position, View convert, android.view.ViewGroup parent) {
            LinearLayout row = new LinearLayout(SettingsActivity.this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(android.view.Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.dp(SettingsActivity.this, 16), Ui.dp(SettingsActivity.this, 8),
                    Ui.dp(SettingsActivity.this, 16), Ui.dp(SettingsActivity.this, 8));
            final int i = shown.get(position);
            android.widget.ImageView iv = new android.widget.ImageView(SettingsActivity.this);
            if (icons.get(i) != null) iv.setImageDrawable(icons.get(i));
            row.addView(iv, new LinearLayout.LayoutParams(
                    Ui.dp(SettingsActivity.this, 34), Ui.dp(SettingsActivity.this, 34)));
            TextView tv = Ui.text(SettingsActivity.this, names.get(i), 14, Ui.TEXT, false);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1);
            lp.leftMargin = Ui.dp(SettingsActivity.this, 12);
            row.addView(tv, lp);
            final android.widget.CheckBox cb = new android.widget.CheckBox(SettingsActivity.this);
            cb.setChecked(sel.contains(pkgs.get(i)));
            cb.setClickable(false);
            cb.setFocusable(false);
            row.addView(cb);
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String p = pkgs.get(i);
                    if (sel.contains(p)) sel.remove(p);
                    else sel.add(p);
                    cb.setChecked(sel.contains(p));
                }
            });
            return row;
        }
    }

    private void pickLongAction() {
        final String[] items = new String[]{"打开快捷应用", "隐藏灵动岛", "保存截图"};
        int cur = Common.getI(this, Common.K_LONG, 0);
        new AlertDialog.Builder(this)
                .setTitle("有事件时长按灵动岛")
                .setSingleChoiceItems(items, cur, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        Common.setI(SettingsActivity.this, Common.K_LONG, which);
                        d.dismiss();
                        build();
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    private Switch toggle(final String key, boolean def) {
        final Switch s = Ui.toggle(this, Common.getB(this, key, def));
        s.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton b, boolean c) {
                Common.setB(SettingsActivity.this, key, c);
                if (key.equals(Common.K_PIN)) {
                    if (c) previewIsland(true);
                    else reload();
                    return;
                }
                if (key.equals(Common.K_MIC) && c) {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                            != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 11);
                    }
                    reload();
                    return;
                }
                if (key.equals(Common.K_ISLAND)) {
                    Intent i = new Intent(SettingsActivity.this, IslandService.class);
                    if (c) {
                        if (!Common.hasOverlay(SettingsActivity.this)) {
                            Perm.overlay(SettingsActivity.this);
                            return;
                        }
                        startForegroundService(i);
                    } else {
                        i.setAction(Common.ACTION_STOP);
                        startService(i);
                    }
                } else if (c && Common.getB(SettingsActivity.this, Common.K_ISLAND, true)) {
                    reload();
                }
            }
        });
        return s;
    }

    private void author() {
        openDouyin();
    }

    private void sponsor() {
        Sponsor.show(this);
    }

    private void openDouyin() {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("抖音号", "42351991718"));
        } catch (Exception ignored) {
        }
        Toast.makeText(this, "抖音号 42351991718 已复制，搜索里点用户即可关注",
                Toast.LENGTH_LONG).show();
        String[] links = {
                "snssdk1128://search?keyword=42351991718",
                "https://www.douyin.com/search/42351991718"
        };
        for (String l : links) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(l)));
                return;
            } catch (Exception ignored) {
            }
        }
    }
}
