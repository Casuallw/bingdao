/*
 * 冰岛 (Bingdao) - Android 灵动岛
 * Copyright (c) 2026 casuallw (Gitee: casual-wear / GitHub: Casuallw)
 * All rights reserved. Licensed under the Bingdao Non-Commercial License 1.1.
 * 非商业许可：禁止商用、倒卖或收费分发。完整条款见项目根目录 LICENSE 文件。
 * https://gitee.com/casual-wear/bingdao
 */
package com.sihua.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.text.method.LinkMovementMethod;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** 「作者声明」「关于应用」两个长文弹窗。 */
final class About {

    /** 官方唯一发布地址：盗版重打包无法移除这里的常量而不破坏功能。 */
    static final String OFFICIAL = "https://gitee.com/casual-wear/bingdao";
    static final String COPYRIGHT = "Copyright (c) 2026 casuallw";
    static final String SIGN_SHA256 =
            "88:55:B9:99:76:DB:7C:F8:DF:B9:7A:95:BB:D1:9A:74:A5:94:CD:E5:CC:E4:49:27:5B:44:23:ED:ED:6D:4F:C3";

    private About() {
    }

    /** 供其它界面展示的版权标识行。 */
    static String stamp() {
        return COPYRIGHT + "\n" + OFFICIAL;
    }

    static void declaration(Activity a) {
        doc(a, "作者声明",
                "作者是一名高中生，日子过得并不宽裕。\n\n"
                        + "这个软件花了我大量的时间和精力：课余、周末、深夜，一点点调出来的。"
                        + "没有团队，没有预算，只有一个想把灵动岛做得像样的念头。\n\n"
                        + "如果你用着舒服，愿意请我喝瓶水、吃顿饭，那会是我坚持下去最大的动力，"
                        + "真的感激不尽。\n\n"
                        + "不支持也没关系，能把它做好、让你愿意留着，本身就够了。\n\n"
                        + "—— 冰岛作者\n\n"
                        + COPYRIGHT + "\n"
                        + "官方地址：" + OFFICIAL + "\n"
                        + "本应用完全免费，谨防他人倒卖。");
    }

    static void legal(Activity a) {
        doc(a, "关于应用",
                "冰岛（以下简称「本应用」）是一款 Android 灵动岛风格的胶囊通知与音乐可视化工具，"
                        + "由个人开发者独立开发并免费提供。\n\n"

                        + "一、许可与使用\n"
                        + "1. 你可以免费下载、安装并在自己的设备上使用本应用。\n"
                        + "2. 未经作者书面同意，不得将本应用或其修改版用于商业用途，"
                        + "包括但不限于预装、捆绑、付费分发、以本应用引流收费。\n"
                        + "3. 不得移除、遮挡或篡改应用内的作者信息、赞助入口与版权标识。\n"
                        + "4. 本应用按「现状」提供，作者不保证在所有机型与系统版本上无故障运行。\n\n"

                        + "二、隐私说明\n"
                        + "1. 本应用不申请联网权限，不收集、不上传任何个人信息，"
                        + "不含广告与统计 SDK。\n"
                        + "2. 通知使用权：读取通知的标题与正文以显示在胶囊上，"
                        + "内容仅在本机处理，不保存、不上传。\n"
                        + "3. 媒体会话：读取歌曲名、歌手、专辑封面，并执行上一首 / 播放暂停 / 下一首，"
                        + "不上传。\n"
                        + "4. 麦克风：仅在开启「真实音律」时实时计算音量大小，"
                        + "音频不录制、不保存、不上传；关闭开关或退出后立即停止。\n"
                        + "5. 无障碍服务：仅用于把胶囊绘制在状态栏之上、判断前台是否为视频类应用；"
                        + "不读取输入内容，不模拟点击，不采集界面文字。\n"
                        + "6. 应用列表：仅用于显示通知来源图标与名称，不上传。\n"
                        + "7. 卸载本应用即删除全部本地设置，不保留任何数据。\n\n"

                        + "三、免责声明\n"
                        + "1. 本应用为非官方个人作品，与 vivo、iQOO、抖音、微信、QQ 音乐、网易云音乐等"
                        + "公司及其产品无任何关联；相关名称与商标归各自权利人所有。\n"
                        + "2. 因使用或无法使用本应用造成的任何直接或间接损失"
                        + "（包括但不限于错过通知、数据丢失、设备异常、系统限制、账号问题），"
                        + "作者不承担赔偿责任。\n"
                        + "3. 本应用依赖悬浮窗、通知使用权、无障碍、麦克风等系统能力；"
                        + "因系统限制、厂商策略或系统升级导致功能失效的，作者不承诺修复期限。\n"
                        + "4. 赞助属于自愿赠与，不构成购买服务，也不因此取得任何权利；"
                        + "不提供退款，不构成功能承诺或售后义务。\n"
                        + "5. 请自行评估在重要场景（如考试、驾驶、医疗提醒）中的使用风险，"
                        + "不要将本应用作为唯一的通知渠道。\n\n"

                        + "四、禁止行为\n"
                        + "1. 禁止将本应用用于任何违法用途，或用于侵犯他人隐私、窃取信息、"
                        + "诈骗、骚扰等行为。\n"
                        + "2. 禁止对本应用进行反向工程、破解、二次打包，"
                        + "或传播植入恶意代码、广告、收费陷阱的改版。\n"
                        + "3. 禁止冒充作者发布、收费，或以「定制」「授权」「官方版」名义牟利。\n"
                        + "4. 禁止利用本应用抓取、存储、传播他人通知内容或隐私信息。\n"
                        + "5. 禁止以任何方式绕过或破坏本应用的安全与权限设计。\n\n"

                        + "五、版权与正版识别\n"
                        + COPYRIGHT + "\n"
                        + "作者：casuallw（Gitee: casual-wear，GitHub: Casuallw）\n"
                        + "官方唯一发布地址：" + OFFICIAL + "\n\n"
                        + "本应用完全免费，任何向您收费的渠道均非作者授权。\n"
                        + "官方安装包的签名证书 SHA-256 指纹为：\n"
                        + SIGN_SHA256 + "\n\n"
                        + "如果您从其他渠道获得本应用，可用工具核对上述签名指纹："
                        + "不一致即为他人重新打包的版本，可能被植入广告或恶意代码，请立即卸载。\n\n"

                        + "六、其他\n"
                        + "1. 本声明可能随版本更新调整，以应用内最新文本为准。\n"
                        + "2. 本声明部分条款被认定无效的，不影响其余条款的效力。\n"
                        + "3. 本声明适用中华人民共和国法律。\n\n"
                        + "版本 1.9.10");
    }

    private static void doc(Activity a, String title, String body) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(a, 20);
        box.setPadding(p, Ui.dp(a, 14), p, Ui.dp(a, 4));

        TextView tv = Ui.text(a, body, 13f, Ui.SUB, false);
        tv.setLineSpacing(Ui.dp(a, 5), 1f);
        tv.setTextIsSelectable(true);
        tv.setMovementMethod(LinkMovementMethod.getInstance());
        box.addView(tv);

        ScrollView sv = new ScrollView(a);
        sv.setFillViewport(true);
        sv.addView(box, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        int h = (int) (a.getResources().getDisplayMetrics().heightPixels * 0.62f);
        sv.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, h));

        new AlertDialog.Builder(a)
                .setTitle(title)
                .setView(sv)
                .setPositiveButton("知道了", null)
                .show();
    }
}
