/*
 * 冰岛 (Bingdao) - Android 灵动岛
 * Copyright (c) 2026 casuallw (Gitee: casual-wear / GitHub: Casuallw)
 * All rights reserved. Licensed under the Bingdao Non-Commercial License 1.1.
 * 非商业许可：禁止商用、倒卖或收费分发。完整条款见项目根目录 LICENSE 文件。
 * https://gitee.com/casual-wear/bingdao
 */
package com.sihua.app;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.PowerManager;
import android.provider.Settings;

/** 公共配置与工具。 */
public final class Common {

    public static final String PREFS = "sihua_prefs";
    public static final String K_ANIM = "anim_on";
    public static final String K_STYLE = "anim_style";
    public static final String K_DUR = "anim_dur";
    public static final String K_ISLAND = "island_on";
    public static final String K_NOTI = "island_noti";
    public static final String K_MUSIC = "island_music";
    public static final String K_DL = "island_dl";
    public static final String K_CHARGE = "island_charge";
    public static final String K_SHAPE = "island_shape";   // 0 胶囊 1 刘海
    public static final String K_H = "island_h";           // 胶囊高度 dp
    public static final String K_W = "island_w";           // 收起长度 dp
    public static final String K_X = "island_x";           // 水平偏移 dp
    public static final String K_Y = "island_y";           // 顶部偏移 dp
    public static final String K_PIN = "island_pin";       // 永久常驻
    public static final String K_TAU = "island_tau";       // 弹岛停留秒数
    public static final String K_DISMISS_MS = "island_dismiss_ms"; // 消失动画时长
    public static final String K_POPUP = "island_popup";   // 0 缩小版 1 展开版
    public static final String K_SWIPE = "island_swipe";   // 左右滑动切歌
    public static final String K_MIC = "music_mic";        // 真实音律
    public static final String K_MIC_MODE = "music_mic_mode"; // 0 自动 1 仅麦克风 2 系统音(录屏)
    public static final String K_VIS_FAILED = "music_vis_failed"; // 系统音不可用已回退
    public static final String K_COLORFUL = "music_colorful"; // 多颜色可视化
    public static final String K_HIRES = "music_hires";    // 高分辨率可视化
    public static final String K_COVER = "music_cover_color"; // 封面取色
    public static final String K_FG_HIDE = "island_fg_hide";  // 前台时不再弹岛
    public static final String K_MULTI = "island_multi";      // 多岛：副事件分裂成小圆
    public static final String K_MULTI_SIDE = "island_multi_side"; // 0 右 1 左
    public static final String K_REPLY = "island_quick_reply"; // 快捷回复
    public static final String K_LINES = "island_lines";       // 展开消息行数
    public static final String K_QUICK_PKG = "quick_app_pkg";    // 常驻岛单击打开的应用
    public static final String K_QUICK_NAME = "quick_app_name";
    public static final String K_LONG = "long_press_action";     // 0 快捷应用 1 隐藏岛 2 截图
    public static final String K_SYS_UNLOCK = "sys_unlock";      // 解锁提示
    public static final String K_SYS_HEADSET = "sys_headset";    // 耳机连接
    public static final String K_SYS_FULL = "sys_full";          // 充满电
    public static final String K_SYS_LOW = "sys_low";            // 低电量
    public static final String K_SYS_RINGER = "sys_ringer";      // 静音 / 振动 / 铃响
    public static final String K_LS_HIDE = "landscape_hide";     // 横屏隐藏常驻岛
    public static final String K_EXPAND_MS = "island_expand_ms";  // 展开动画时长
    public static final String K_PULL = "island_pull_close";      // 向下拉关掉音乐事件
    public static final String K_IDLE_CIRCLE = "idle_circle";     // 常驻岛用圆形
    public static final String K_IDLE_SIZE = "idle_circle_size";  // 常驻圆直径 dp
    public static final String K_IDLE_LINK = "idle_circle_link";  // 圆心跟随缩小岛中心
    public static final String K_IDLE_X = "idle_circle_x";        // 单独位置：左右
    public static final String K_IDLE_Y = "idle_circle_y";        // 单独位置：上下

    public static final String ACTION_NOTI = "com.sihua.app.action.NOTI";
    public static final String ACTION_STOP = "com.sihua.app.action.STOP";
    public static final String ACTION_RELOAD = "com.sihua.app.action.RELOAD";
    public static final String ACTION_TEST = "com.sihua.app.action.TEST";
    public static final String ACTION_PREVIEW = "com.sihua.app.action.PREVIEW";
    public static final String ACTION_UNPREVIEW = "com.sihua.app.action.UNPREVIEW";
    public static final String ACTION_PREVIEW_IDLE = "com.sihua.app.action.PREVIEW_IDLE";
    public static final String ACTION_RESTORE_MUSIC = "com.sihua.app.action.RESTORE_MUSIC";
    public static final String ACTION_PROJECTION = "com.sihua.app.action.PROJECTION";

    private Common() {
    }

    public static boolean getB(Context c, String k, boolean d) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(k, d);
    }

    public static void setB(Context c, String k, boolean v) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(k, v).apply();
    }

    public static int getI(Context c, String k, int d) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(k, d);
    }

    public static void setI(Context c, String k, int v) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(k, v).apply();
    }

    public static String getS(Context c, String k, String d) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(k, d);
    }

    public static void setS(Context c, String k, String v) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(k, v).apply();
    }

    public static int clamp(int v, int min, int max) {
        return v < min ? min : Math.min(v, max);
    }

    public static int dp(Context c, float v) {
        return (int) (c.getResources().getDisplayMetrics().density * v + 0.5f);
    }

    public static GradientDrawable round(int color, int stroke, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        if (stroke != 0) g.setStroke(1, stroke);
        return g;
    }

    public static boolean hasOverlay(Context c) {
        return Settings.canDrawOverlays(c);
    }

    public static boolean hasNotiListener(Context c) {
        String s = Settings.Secure.getString(c.getContentResolver(),
                "enabled_notification_listeners");
        return s != null && s.contains(c.getPackageName());
    }

    public static boolean hasA11y(Context c) {
        String s = Settings.Secure.getString(c.getContentResolver(),
                "enabled_accessibility_services");
        return s != null && s.contains(c.getPackageName());
    }

    public static boolean batteryIgnored(Context c) {
        try {
            PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
            return pm != null && pm.isIgnoringBatteryOptimizations(c.getPackageName());
        } catch (Exception e) {
            return false;
        }
    }

    /** 桌面 Launcher 的包名，用来判断“关闭应用回到桌面”。 */
    public static String homePackage(Context c) {
        try {
            Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
            ResolveInfo ri = c.getPackageManager().resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY);
            return ri == null ? null : ri.activityInfo.packageName;
        } catch (Exception e) {
            return null;
        }
    }

    public static Bitmap iconBitmap(Context c, String pkg, int size) {
        Drawable d;
        try {
            d = c.getPackageManager().getApplicationIcon(pkg);
        } catch (Exception e) {
            d = c.getPackageManager().getDefaultActivityIcon();
        }
        return drawableToBitmap(d, size);
    }

    public static Bitmap drawableToBitmap(Drawable d, int size) {
        Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        d.setBounds(0, 0, size, size);
        d.draw(cv);
        return b;
    }
}
