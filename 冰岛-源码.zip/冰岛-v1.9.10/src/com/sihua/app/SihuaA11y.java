/*
 * 冰岛 (Bingdao) - Android 灵动岛
 * Copyright (c) 2026 casuallw (Gitee: casual-wear / GitHub: Casuallw)
 * All rights reserved. Licensed under the Bingdao Non-Commercial License 1.1.
 * 非商业许可：禁止商用、倒卖或收费分发。完整条款见项目根目录 LICENSE 文件。
 * https://gitee.com/casual-wear/bingdao
 */
package com.sihua.app;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;

/**
 * 无障碍服务：不读取屏幕内容，只做两件事：
 * 1. 提供 TYPE_ACCESSIBILITY_OVERLAY 窗口，让灵动岛能盖在系统状态栏上方；
 * 2. 记录当前前台应用，用来判断视频类 App（B 站 / 相册）。
 */
public class SihuaA11y extends AccessibilityService {

    static SihuaA11y instance;
    static volatile String foreground;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        IslandService s = IslandService.current;
        if (s != null) s.reconnect();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        if (event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            foreground = event.getPackageName().toString();
        }
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        instance = null;
        foreground = null;
        return super.onUnbind(intent);
    }
}
