/*
 * 冰岛 (Bingdao) - Android 灵动岛
 * Copyright (c) 2026 casuallw (Gitee: casual-wear / GitHub: Casuallw)
 * All rights reserved. Licensed under the Bingdao Non-Commercial License 1.1.
 * 非商业许可：禁止商用、倒卖或收费分发。完整条款见项目根目录 LICENSE 文件。
 * https://gitee.com/casual-wear/bingdao
 */
package com.sihua.app;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

/** 界面构建小工具。 */
public final class Ui {

    public static final int BG = 0xFF07080C;
    public static final int CARD = 0xFF12141B;
    public static final int CARD2 = 0xFF171A23;
    public static final int TEXT = 0xFFF3F5F9;
    public static final int SUB = 0xFF8D93A3;
    public static final int DIM = 0xFF5A6070;
    public static final int ACCENT = 0xFF5EE7FF;
    public static final int VIOLET = 0xFF9A6BFF;
    public static final int OK = 0xFF38D98A;
    public static final int WARN = 0xFFFFB23E;
    public static final int LINE = 0x14FFFFFF;

    private Ui() {
    }

    public static int dp(Context c, float v) {
        return (int) (c.getResources().getDisplayMetrics().density * v + 0.5f);
    }

    public static float sp(Context c, float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v,
                c.getResources().getDisplayMetrics());
    }

    public static TextView text(Context c, String s, float sizeSp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sizeSp);
        t.setTextColor(color);
        t.setIncludeFontPadding(false);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        return t;
    }

    public static LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(dp(c, 20));
        g.setStroke(dp(c, 1), LINE);
        l.setBackground(g);
        l.setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(c, 12);
        l.setLayoutParams(lp);
        return l;
    }

    /** 卡片内的一行：圆点 + 标题/副标题 + 右侧控件。 */
    public static LinearLayout row(Context c, String title, String sub, int dotColor, View right) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setMinimumHeight(dp(c, 52));

        if (dotColor != 0) {
            View dot = new View(c);
            GradientDrawable dg = new GradientDrawable();
            dg.setShape(GradientDrawable.OVAL);
            dg.setColor(dotColor);
            dot.setBackground(dg);
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(c, 8), dp(c, 8));
            dlp.setMargins(0, 0, dp(c, 12), 0);
            row.addView(dot, dlp);
        }

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = text(c, title, 15, TEXT, false);
        col.addView(t);
        if (sub != null && sub.length() > 0) {
            TextView s = text(c, sub, 12, SUB, false);
            LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            slp.topMargin = dp(c, 3);
            col.addView(s, slp);
        }
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        row.addView(col, clp);

        if (right != null) {
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.leftMargin = dp(c, 10);
            row.addView(right, rlp);
        }
        return row;
    }

    public static TextView pill(Context c, String s, int color) {
        TextView t = text(c, s, 12, color, false);
        GradientDrawable g = new GradientDrawable();
        g.setColor((color & 0x00FFFFFF) | 0x1F000000);
        g.setCornerRadius(dp(c, 20));
        t.setBackground(g);
        t.setPadding(dp(c, 10), dp(c, 4), dp(c, 10), dp(c, 4));
        return t;
    }

    public static Switch toggle(Context c, boolean checked) {
        Switch s = new Switch(c);
        s.setChecked(checked);
        s.setThumbTintList(new ColorStateList(
                new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}},
                new int[]{0xFFFFFFFF, 0xFFFFFFFF}));
        s.setTrackTintList(new ColorStateList(
                new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}},
                new int[]{ACCENT, 0xFF313644}));
        return s;
    }

    public static void divider(Context c, LinearLayout parent) {
        View v = new View(c);
        v.setBackgroundColor(LINE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, dp(c, 0.6f)));
        lp.setMargins(dp(c, 20), dp(c, 2), 0, dp(c, 2));
        parent.addView(v, lp);
    }

    public static void space(Context c, LinearLayout parent, float h) {
        View v = new View(c);
        parent.addView(v, new LinearLayout.LayoutParams(1, dp(c, h)));
    }

    public static void press(final View v) {
        v.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    view.animate().alpha(0.62f).setDuration(90).start();
                } else if (e.getAction() == MotionEvent.ACTION_UP
                        || e.getAction() == MotionEvent.ACTION_CANCEL) {
                    view.animate().alpha(1f).setDuration(140).start();
                }
                return false;
            }
        });
    }

    /** 可点击的整行（带按压反馈）。 */
    public static LinearLayout clickRow(Context c, LinearLayout row, View.OnClickListener l) {
        row.setClickable(true);
        row.setFocusable(true);
        row.setPadding(dp(c, 4), dp(c, 2), dp(c, 4), dp(c, 2));
        row.setOnClickListener(l);
        press(row);
        return row;
    }

    /** 背景：深色 + 顶部两团彩色光晕。 */
    public static class GlowDrawable extends Drawable {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int w;
        private final int h;

        public GlowDrawable(int w, int h) {
            this.w = Math.max(1, w);
            this.h = Math.max(1, h);
        }

        @Override
        public void draw(Canvas canvas) {
            canvas.drawColor(BG);
            p.setShader(new RadialGradient(w * 0.78f, h * 0.04f, w * 0.85f,
                    new int[]{0x2E5EE7FF, 0x0A9A6BFF, 0x00000000}, new float[]{0f, 0.45f, 1f},
                    Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, p);
            p.setShader(new RadialGradient(w * 0.1f, h * 0.28f, w * 0.7f,
                    new int[]{0x229A6BFF, 0x00000000}, new float[]{0f, 1f},
                    Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, p);
            p.setShader(null);
        }

        @Override
        public void setAlpha(int alpha) {
        }

        @Override
        public void setColorFilter(android.graphics.ColorFilter cf) {
        }

        @Override
        public int getOpacity() {
            return android.graphics.PixelFormat.OPAQUE;
        }
    }

    /** 顶部小 Logo：渐变圆环。 */
    public static class Logo extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int size;

        public Logo(Context c, int sizePx) {
            super(c);
            this.size = sizePx;
            p.setShader(new android.graphics.SweepGradient(sizePx / 2f, sizePx / 2f,
                    new int[]{ACCENT, VIOLET, 0xFFFF7AC6, ACCENT}, null));
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(sizePx * 0.075f);
            ring.setColor(0x33FFFFFF);
        }

        @Override
        protected void onMeasure(int widthSpec, int heightSpec) {
            setMeasuredDimension(size, size);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float c = size / 2f;
            float r = c * 0.78f;
            Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(size * 0.13f);
            stroke.setShader(p.getShader());
            canvas.drawCircle(c, c, r, stroke);
            p.setAlpha(46);
            canvas.drawCircle(c, c, size * 0.24f, p);
        }
    }
}
