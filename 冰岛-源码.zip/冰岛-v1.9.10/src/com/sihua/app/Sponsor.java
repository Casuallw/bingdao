/*
 * 冰岛 (Bingdao) - Android 灵动岛
 * Copyright (c) 2026 casuallw (Gitee: casual-wear / GitHub: Casuallw)
 * All rights reserved. Licensed under the Bingdao Non-Commercial License 1.1.
 * 非商业许可：禁止商用、倒卖或收费分发。完整条款见项目根目录 LICENSE 文件。
 * https://gitee.com/casual-wear/bingdao
 */
package com.sihua.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;

/**
 * 赞助作者：只展示微信收款码图片，不在界面里暴露微信号。
 * 图片放在 assets/sponsor_qr.png；没有图片时显示提示。
 */
final class Sponsor {

    private Sponsor() {
    }

    static void show(final Activity a) {
        Bitmap qr = load(a);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        int p = Ui.dp(a, 18);
        box.setPadding(p, p, p, p);

        if (qr != null) {
            ImageView iv = new ImageView(a);
            iv.setImageBitmap(qr);
            iv.setAdjustViewBounds(true);
            int w = Math.min(Ui.dp(a, 240), a.getResources().getDisplayMetrics().widthPixels
                    - Ui.dp(a, 80));
            iv.setLayoutParams(new LinearLayout.LayoutParams(w,
                    LinearLayout.LayoutParams.WRAP_CONTENT));
            box.addView(iv);
            TextView tip = Ui.text(a, "长按收款码或保存后用微信「扫一扫」付款，感谢支持。",
                    12f, Ui.SUB, false);
            tip.setLineSpacing(Ui.dp(a, 4), 1f);
            tip.setPadding(0, Ui.dp(a, 12), 0, 0);
            box.addView(tip);
            iv.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    save(a);
                    return true;
                }
            });
        } else {
            TextView tip = Ui.text(a, "收款码还没放进来，稍后再试。", 13f, Ui.SUB, false);
            box.addView(tip);
        }

        AlertDialog.Builder b = new AlertDialog.Builder(a)
                .setTitle("赞助作者")
                .setView(box)
                .setNegativeButton("关闭", null);
        if (qr != null) {
            b.setPositiveButton("保存收款码", new android.content.DialogInterface.OnClickListener() {
                @Override
                public void onClick(android.content.DialogInterface d, int w) {
                    save(a);
                }
            });
        }
        b.show();
    }

    private static Bitmap load(Context c) {
        try {
            Bitmap b = BitmapFactory.decodeStream(c.getAssets().open("sponsor_qr.png"));
            if (b == null) return null;
            int w = b.getWidth(), h = b.getHeight();
            float k = Math.min(1f, 1080f / Math.max(w, h));
            if (k < 1f) return Bitmap.createScaledBitmap(b,
                    Math.max(1, (int) (w * k)), Math.max(1, (int) (h * k)), true);
            return b;
        } catch (Exception e) {
            return null;
        }
    }

    /** 存进相册，方便用微信扫一扫。 */
    private static void save(Activity a) {
        Bitmap b = load(a);
        if (b == null) {
            Toast.makeText(a, "没有收款码图片", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "冰岛-赞助收款码.png");
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            v.put(MediaStore.Images.Media.RELATIVE_PATH,
                    Environment.DIRECTORY_PICTURES + "/冰岛");
            Uri uri = a.getContentResolver().insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (uri == null) throw new IllegalStateException();
            OutputStream out = a.getContentResolver().openOutputStream(uri);
            if (out == null) throw new IllegalStateException();
            b.compress(Bitmap.CompressFormat.PNG, 100, out);
            out.close();
            Toast.makeText(a, "已保存到相册", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(a, "保存失败，请截图保存", Toast.LENGTH_SHORT).show();
        }
    }
}
