/*
 * 冰岛 (Bingdao) - Android 灵动岛
 * Copyright (c) 2026 casuallw (Gitee: casual-wear / GitHub: Casuallw)
 * All rights reserved. Licensed under the Bingdao Non-Commercial License 1.1.
 * 非商业许可：禁止商用、倒卖或收费分发。完整条款见项目根目录 LICENSE 文件。
 * https://gitee.com/casual-wear/bingdao
 */
package com.sihua.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.text.TextUtils;

/** 监听系统通知，把内容送给灵动岛。 */
public class NotificationListener extends NotificationListenerService {

    private final Handler h = new Handler(Looper.getMainLooper());
    private static NotificationListener current;

    /** 最近一条带「快捷回复」的通知。 */
    static PendingIntent replyPi;
    static RemoteInput[] replyInputs;
    static String replyPkg;

    /** 媒体通知里的大图（很多播放器不给 MediaSession 封面，只塞通知）。 */
    private static final java.util.LinkedHashMap<String, Bitmap> MEDIA_ICONS =
            new java.util.LinkedHashMap<String, Bitmap>(8, 0.75f, true) {
                @Override
                protected boolean removeEldestEntry(java.util.Map.Entry<String, Bitmap> e) {
                    return size() > 8;
                }
            };

    /** 每个包当前封面的指纹，用来判断是不是同一张图。 */
    private static final java.util.HashMap<String, Integer> MEDIA_SIGS =
            new java.util.HashMap<String, Integer>();

    static Bitmap mediaIcon(String pkg) {
        if (pkg == null) return null;
        synchronized (MEDIA_ICONS) {
            Bitmap b = MEDIA_ICONS.get(pkg);
            if (b != null && !b.isRecycled()) return b;
        }
        return scanActive(pkg);
    }

    @Override
    public void onListenerConnected() {
        current = this;
    }

    @Override
    public void onListenerDisconnected() {
        if (current == this) current = null;
    }

    /** 从当前挂着的通知里再捞一次封面：播放器常常只在通知里放图。 */
    static Bitmap scanActive(String pkg) {
        NotificationListener s = current;
        if (s == null || pkg == null) return null;
        StatusBarNotification[] all;
        try {
            all = s.getActiveNotifications();
        } catch (Exception e) {
            return null;
        }
        if (all == null) return null;
        for (StatusBarNotification n : all) {
            if (n == null || n.getNotification() == null) continue;
            if (!pkg.equals(n.getPackageName())) continue;
            Bitmap b = extractArt(n.getNotification(), n.getNotification().extras);
            if (b != null) {
                synchronized (MEDIA_ICONS) {
                    MEDIA_ICONS.put(pkg, b);
                }
                return b;
            }
        }
        return null;
    }

    /** 通知里能当封面的几种字段全试一遍（Bitmap / Icon / 大图样式）。 */
    private static Bitmap extractArt(Notification n, Bundle ex) {
        Bitmap bm = null;
        if (ex != null) {
            Object o = ex.getParcelable(Notification.EXTRA_LARGE_ICON_BIG);
            bm = asBitmap(o);
            if (bm == null) bm = asBitmap(ex.getParcelable(Notification.EXTRA_LARGE_ICON));
            if (bm == null) bm = asBitmap(ex.getParcelable(Notification.EXTRA_PICTURE));
        }
        if (bm == null && n != null) {
            try {
                Icon icon = n.getLargeIcon();
                if (icon != null) bm = iconToBitmap(icon);
            } catch (Exception ignored) {
            }
        }
        return bm;
    }

    private static Bitmap asBitmap(Object o) {
        if (o instanceof Bitmap) {
            Bitmap b = (Bitmap) o;
            return b.isRecycled() ? null : b;
        }
        if (o instanceof Icon) return iconToBitmap((Icon) o);
        return null;
    }

    private static Bitmap iconToBitmap(Icon icon) {
        try {
            Drawable d = icon.loadDrawable(current);
            if (d == null) return null;
            if (d instanceof BitmapDrawable) {
                Bitmap b = ((BitmapDrawable) d).getBitmap();
                if (b != null && !b.isRecycled()) return b;
            }
            int w = Math.max(1, d.getIntrinsicWidth());
            int hgt = Math.max(1, d.getIntrinsicHeight());
            if (w <= 1 || hgt <= 1) {
                w = 128;
                hgt = 128;
            }
            Bitmap out = Bitmap.createBitmap(w, hgt, Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(out);
            d.setBounds(0, 0, w, hgt);
            d.draw(cv);
            return out;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null) return;
        String pkg = sbn.getPackageName();
        if (pkg == null || pkg.equals(getPackageName())) return;
        Notification n = sbn.getNotification();
        if (n == null || n.extras == null) return;
        Bundle ex = n.extras;
        if (ex.containsKey(Notification.EXTRA_MEDIA_SESSION)) {
            cacheMediaIcon(pkg, ex, n);
            IslandService s = IslandService.current;
            if (s != null) {
                Object tok = ex.getParcelable(Notification.EXTRA_MEDIA_SESSION);
                if (tok instanceof android.media.session.MediaSession.Token) {
                    s.onMediaNotification(pkg, (android.media.session.MediaSession.Token) tok);
                }
            }
            return;
        }

        CharSequence t = ex.getCharSequence(Notification.EXTRA_TITLE);
        CharSequence c = ex.getCharSequence(Notification.EXTRA_TEXT);
        if (TextUtils.isEmpty(t) && TextUtils.isEmpty(c)) return;

        // 先记下「回复」入口，后面点岛回复要用
        cacheReply(pkg, n);

        // 系统对「显示在其他应用上层」的提示：直接从通知栏撤掉，也不进灵动岛
        if (isOverlayWarning(t, c)) {
            final String key = sbn.getKey();
            h.postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        cancelNotification(key);
                    } catch (Exception ignored) {
                    }
                }
            }, 600);
            return;
        }

        int max = ex.getInt(Notification.EXTRA_PROGRESS_MAX, 0);
        int prog = ex.getInt(Notification.EXTRA_PROGRESS, -1);
        int pct = -1;
        if (max > 0 && prog >= 0) pct = prog * 100 / max;

        IslandService s = IslandService.current;
        if (s != null) {
            s.pushNotification(pkg, t == null ? "" : t.toString(),
                    c == null ? "" : c.toString(), pct);
        }
    }

    private void cacheReply(String pkg, Notification n) {
        if (n.actions == null) return;
        for (Notification.Action a : n.actions) {
            if (a == null || a.actionIntent == null) continue;
            RemoteInput[] ri = a.getRemoteInputs();
            if (ri != null && ri.length > 0) {
                replyPi = a.actionIntent;
                replyInputs = ri;
                replyPkg = pkg;
                return;
            }
        }
    }

    private void cacheMediaIcon(String pkg, Bundle ex, Notification n) {
        Bitmap bm = extractArt(n, ex);
        if (bm == null || bm.isRecycled()) return;
        int sig = signature(bm);
        boolean changed;
        synchronized (MEDIA_ICONS) {
            Integer old = MEDIA_SIGS.get(pkg);
            changed = old == null || old != sig;
            MEDIA_ICONS.put(pkg, bm);
            MEDIA_SIGS.put(pkg, sig);
        }
        IslandService s = IslandService.current;
        if (changed && s != null) s.refreshMusicArt();
    }

    /** 抽几个像素当封面指纹：播放器反复重发同一张图时别再触发重画。 */
    private static int signature(Bitmap b) {
        if (b == null || b.isRecycled()) return 0;
        int w = b.getWidth(), h = b.getHeight();
        if (w <= 0 || h <= 0) return 0;
        int sig = w * 31 + h;
        int[] xs = {w / 8, w / 2, w * 7 / 8};
        int[] ys = {h / 8, h / 2, h * 7 / 8};
        try {
            for (int y : ys) {
                for (int x : xs) sig = sig * 31 + b.getPixel(x, Math.min(h - 1, y));
            }
        } catch (Exception ignored) {
        }
        return sig;
    }

    /** 从通知按钮猜「当前是否已收藏」：有「取消喜欢」= 已收藏。 */
    static Boolean likedHint(String pkg) {
        NotificationListener s = current;
        if (s == null || pkg == null) return null;
        StatusBarNotification[] all;
        try {
            all = s.getActiveNotifications();
        } catch (Exception e) {
            return null;
        }
        if (all == null) return null;
        for (StatusBarNotification sn : all) {
            if (sn == null || !pkg.equals(sn.getPackageName())) continue;
            Notification n = sn.getNotification();
            if (n == null || n.actions == null) continue;
            Boolean hint = null;
            for (Notification.Action a : n.actions) {
                if (a == null || a.actionIntent == null) continue;
                String label = a.title == null ? "" : a.title.toString().toLowerCase();
                if (label.length() == 0) continue;
                if (label.contains("取消") || label.contains("unlike")
                        || label.contains("remove from")) {
                    hint = Boolean.TRUE;
                } else if (label.contains("喜欢") || label.contains("收藏")
                        || label.contains("like") || label.contains("favorite")
                        || label.contains("已赞")) {
                    if (hint == null) hint = Boolean.FALSE;
                }
            }
            if (hint != null) return hint;
        }
        return null;
    }

    /** 点通知里的收藏按钮（有的播放器只在这里暴露收藏）。 */
    static boolean tapLike(String pkg, boolean wantLiked) {
        NotificationListener s = current;
        if (s == null || pkg == null) return false;
        StatusBarNotification[] all;
        try {
            all = s.getActiveNotifications();
        } catch (Exception e) {
            return false;
        }
        if (all == null) return false;
        for (StatusBarNotification sn : all) {
            if (sn == null || !pkg.equals(sn.getPackageName())) continue;
            Notification n = sn.getNotification();
            if (n == null || n.actions == null) continue;
            for (Notification.Action a : n.actions) {
                if (a == null || a.actionIntent == null) continue;
                String label = a.title == null ? "" : a.title.toString().toLowerCase();
                if (label.length() == 0) continue;
                boolean cancel = label.contains("取消") || label.contains("unlike")
                        || label.contains("remove from");
                boolean like = label.contains("喜欢") || label.contains("收藏")
                        || label.contains("like") || label.contains("favorite")
                        || label.contains("已赞");
                if (!cancel && !like) continue;
                // 已收藏时按钮是「取消喜欢」，反之是「喜欢」
                if (cancel == !wantLiked) {
                    try {
                        a.actionIntent.send();
                        return true;
                    } catch (Exception e) {
                        return false;
                    }
                }
            }
        }
        return false;
    }

    private boolean isOverlayWarning(CharSequence t, CharSequence c) {
        String a = t == null ? "" : t.toString();
        String b = c == null ? "" : c.toString();
        String all = a + b;
        return all.contains("上层显示") || all.contains("显示在其他应用")
                || all.contains("over other apps") || all.contains("在其他应用的上层");
    }
}
