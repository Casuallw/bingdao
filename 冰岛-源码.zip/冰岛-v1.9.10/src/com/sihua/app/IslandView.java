/*
 * 冰岛 (Bingdao) - Android 灵动岛
 * Copyright (c) 2026 casuallw (Gitee: casual-wear / GitHub: Casuallw)
 * All rights reserved. Licensed under the Bingdao Non-Commercial License 1.1.
 * 非商业许可：禁止商用、倒卖或收费分发。完整条款见项目根目录 LICENSE 文件。
 * https://gitee.com/casual-wear/bingdao
 */
package com.sihua.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.text.TextPaint;
import android.text.StaticLayout;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/**
 * 灵动岛本体。
 * 上边距为 0：胶囊顶边就是窗口顶边，这样「距顶部 0」能真正贴住屏幕顶部。
 * 左右 / 下边留出阴影空间，避免圆角被窗口边界切成方角。
 */
public class IslandView extends View {

    public static final int KIND_NOTI = 0;
    public static final int KIND_MUSIC = 1;
    public static final int KIND_DOWNLOAD = 2;
    public static final int KIND_CHARGE = 3;
    public static final int KIND_SYS = 4;
    public static final int KIND_QUICK = 5;

    // 系统事件图案
    public static final int SYS_UNLOCK = 1;
    public static final int SYS_HEADSET = 2;
    public static final int SYS_FULL = 3;
    public static final int SYS_LOW = 4;
    public static final int SYS_SILENT = 5;
    public static final int SYS_VIBRATE = 6;
    public static final int SYS_RING = 7;

    /** 快捷应用：图标 + 名称 + 包名。 */
    public static class QuickApp {
        public Bitmap icon;
        public String label = "";
        public String pkg = "";
    }

    public static final int ACT_LIKE = 1;
    public static final int ACT_PREV = 2;
    public static final int ACT_TOGGLE = 3;
    public static final int ACT_NEXT = 4;
    public static final int ACT_HIDE = 5;

    public interface Actions {
        void onIslandAction(int action);

        void onTap();

        void onSwipe(int dir);

        void onLong();

        void onQuickApp(int index);

        void onPullDown();

        void onDragMove(int dx);

        void onDragEnd();

        void onPullMove(int dy);

        void onPullCancel();

        void onHideIsland();
    }

    public static int padSide(Context c) {
        return Common.dp(c, 12);
    }

    public static int padBottom(Context c) {
        return Common.dp(c, 14);
    }

    private final Paint body = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint iconPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint barPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint titlePaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint subPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint badgePaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint btnIcon = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Paint btnBg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint btnFg = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint textPaint9 = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final RectF[] btns = new RectF[]{new RectF(), new RectF(), new RectF(), new RectF(), new RectF()};
    private boolean hideBtn;
    private boolean quickHide;
    private int btnCount;
    private final Path clip = new Path();
    private final Path pill = new Path();
    private final RectF oval = new RectF();
    private final RectF iconBox = new RectF();

    private final int padS;
    private final int padB;
    private int kind = KIND_NOTI;
    private int sysStyle;
    private QuickApp[] quickApps = new QuickApp[0];
    private final RectF[] quickRects = new RectF[]{
            new RectF(), new RectF(), new RectF(), new RectF(), new RectF(),
            new RectF(), new RectF(), new RectF(), new RectF(), new RectF()};
    private int quickCount;
    private boolean longPressFired;
    private final Runnable longPressTask = new Runnable() {
        @Override
        public void run() {
            if (!moved && !swipedFlag && pressed < 0 && actions != null) {
                longPressFired = true;
                actions.onLong();
            }
        }
    };

    public void setQuickApps(QuickApp[] apps) {
        quickApps = apps == null ? new QuickApp[0] : apps;
        invalidate();
    }

    public void setSysStyle(int v) {
        sysStyle = v;
        invalidate();
    }
    private int shape = 0;
    private String title = "";
    private String sub = "";
    private Bitmap icon;
    private int progress = -1;
    private int accent = Ui.ACCENT;
    private boolean animating;
    private boolean showText;
    private boolean playing = true;
    private boolean liked;
    private boolean colorful;
    private boolean noLike;
    private boolean idle;
    private float dragX;
    private float dragY;
    private android.animation.ValueAnimator dragAnim;
    private int idleCircleD;
    private float cutR, cutB;
    private float cutScreenR = -1f, cutScreenB = -1f;
    private final int[] locTmp = new int[2];
    private boolean swipedFlag;
    private boolean pullFlag;
    private boolean pullClose;
    private boolean hiRes;
    private float level = -1f;
    private float contentAlpha = 1f;
    private int lines = 2;
    private final float[] env = new float[32];
    private final float[] hsv = new float[3];
    private String cacheSub;
    private int cacheW;
    private StaticLayout cacheBody;
    private long lastBarAt;
    private int pressed = -1;
    private long startAt;
    private int flatSide;
    private float flatAmt;
    private float leftInset;
    private float padR;
    private float bridgeW, bridgeEnd, bridgeMid, bridgeAlpha;
    private int strokeHole;
    private final Path bridgePath = new Path();
    private final Paint bridgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Actions actions;

    public IslandView(Context c) {
        this(c, null);
    }

    public IslandView(Context c, AttributeSet a) {
        super(c, a);
        padS = padSide(c);
        padB = padBottom(c);
        padR = padS;
        leftInset = padS;
        bridgePaint.setColor(0xFF000000);
        body.setColor(0xFF000000);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(Common.dp(c, 1f));
        arc.setStyle(Paint.Style.STROKE);
        track.setColor(0x33FFFFFF);
        barPaint.setStrokeCap(Paint.Cap.ROUND);
        track.setStrokeCap(Paint.Cap.ROUND);
        titlePaint.setTypeface(android.graphics.Typeface.create("sans-serif-medium",
                android.graphics.Typeface.NORMAL));
        titlePaint.setColor(0xFFF2F4F8);
        titlePaint.setTextSize(Ui.sp(c, 13.5f));
        subPaint.setColor(0xFF9AA0AC);
        subPaint.setTextSize(Ui.sp(c, 11f));
        badgePaint.setTextSize(Ui.sp(c, 11.5f));
        badgePaint.setTypeface(android.graphics.Typeface.create("sans-serif-medium",
                android.graphics.Typeface.NORMAL));
        btnIcon.setTextSize(Ui.sp(c, 15f));
        btnIcon.setTextAlign(Paint.Align.CENTER);
        btnIcon.setTypeface(android.graphics.Typeface.create("sans-serif",
                android.graphics.Typeface.NORMAL));
        btnBg.setColor(0x1FFFFFFF);
        startAt = System.currentTimeMillis();
    }

    public void setData(int kind, String title, String sub, Bitmap icon, int progress, int accent) {
        this.kind = kind;
        this.title = title == null ? "" : title;
        this.sub = sub == null ? "" : sub;
        this.icon = icon;
        this.progress = progress;
        this.accent = accent;
        this.startAt = System.currentTimeMillis();
        idle = false;
        badgePaint.setColor(accent);
        animating = kind == KIND_MUSIC;
        invalidate();
    }

    /** 胶囊左边留白：副岛带桥时窗口向左多出一段，胶囊仍然贴着右边。 */
    public void setLeftInset(float px) {
        if (Math.abs(px - leftInset) < 0.5f) return;
        leftInset = Math.max(0f, px);
        invalidate();
    }

    /** 右侧留白：副岛加大触控范围时用，画出来的胶囊宽度不变。 */
    public void setRightInset(float px) {
        padR = Math.max(1f, px);
        invalidate();
    }

    /** 桥接上时，胶囊朝向副岛那一侧的那段描边不要画，接缝才干净。 */
    public void setStrokeHole(int side) {
        if (side == strokeHole) return;
        strokeHole = side;
        invalidate();
    }

    /** 副岛窗口内部的液态桥（画在内容下面，不会盖住图标）。 */
    public void setBridge(float width, float end, float mid, float alpha) {
        bridgeW = Math.max(0f, width);
        bridgeEnd = end;
        bridgeMid = mid;
        bridgeAlpha = Math.max(0f, Math.min(1f, alpha));
        invalidate();
    }

    public boolean isShowText() {
        return showText;
    }

    /** 收起时不画文字：只留两端的图标 / 律动条，避开前摄与状态栏。 */
    public void setShowText(boolean v) {
        showText = v;
        invalidate();
    }

    public void setShape(int s) {
        shape = s;
        invalidate();
    }

    /**
     * 分裂时朝向另一侧的那条边要「削平」，两岛才像一体的。
     * side 1 = 左边，2 = 右边；amt 0 圆角、1 直角。
     */
    public void setFlat(int side, float amt) {
        if (side == flatSide && Math.abs(amt - flatAmt) < 0.001f) return;
        flatSide = side;
        flatAmt = Math.max(0f, Math.min(1f, amt));
        invalidate();
    }

    public void setAnimating(boolean v) {
        animating = v;
        invalidate();
    }

    public void setActions(Actions a) {
        actions = a;
    }

    public void setPlaying(boolean p) {
        playing = p;
        invalidate();
    }

    /** 前摄安全区（屏幕坐标）：文字不要落进这个矩形。 */
    public void setCutout(float rightScreen, float bottomScreen) {
        cutScreenR = rightScreen;
        cutScreenB = bottomScreen;
        invalidate();
    }

    /** 常驻岛画成圆：直径 px，0 表示还是胶囊。 */
    public void setIdleCircle(int d) {
        if (d == idleCircleD) return;
        idleCircleD = Math.max(0, d);
        invalidate();
    }

    public int getIdleCircle() {
        return idleCircleD;
    }

    /** 收起时的触控范围：普通模式只认胶囊，圆形常驻比画的圆大 7dp。 */
    private boolean idleTouch(float x, float y) {
        if (idleCircleD <= 0) {
            // 收起状态：可点范围比胶囊稍大一圈
            float m = Common.dp(getContext(), 10);
            float ih = getHeight() - padB;
            return x >= leftInset - m && x <= getWidth() - padR + m
                    && y >= -m && y <= ih + m;
        }
        float cw = getWidth() - padR - leftInset;
        float ih = getHeight() - padB;
        float cx = leftInset + cw / 2f;
        float cy = ih / 2f;
        float r = idleCircleD / 2f + Common.dp(getContext(), 10);
        float dx = x - cx, dy = y - cy;
        return dx * dx + dy * dy <= r * r;
    }

    /** 横屏时快捷应用网格最左边多一个「隐藏岛」格子。 */
    public void setQuickHide(boolean v) {
        if (quickHide == v) return;
        quickHide = v;
        invalidate();
    }

    /** 横屏时音乐卡最左边多一个「隐藏岛」按钮。 */
    public void setHideBtn(boolean v) {
        if (hideBtn == v) return;
        hideBtn = v;
        invalidate();
    }

    /** 向下拉关掉当前事件（音乐用）。 */
    public void setPullClose(boolean v) {
        pullClose = v;
    }

    public boolean isPullClose() {
        return pullClose;
    }

    public void setLiked(boolean l) {
        liked = l;
        invalidate();
    }

    /** 常驻且没有事件时：只画一条短胶囊，不显示图标。 */
    public void setIdle(boolean v) {
        dragX = 0f;
        dragY = 0f;
        idle = v;
        invalidate();
    }

    /** 视频类 App（B 站 / 相册）不显示收藏按钮。 */
    public boolean isIdle() {
        return idle;
    }

    public void setNoLike(boolean v) {
        noLike = v;
        invalidate();
    }

    public void setVisual(boolean color, boolean hires) {
        colorful = color;
        hiRes = hires;
        invalidate();
    }

    /** 麦克风采到的实时音量（0–1）；-1 表示没有麦克风，走合成律动。 */
    /** 不再画外阴影：窗口缩放时模糊层会重算，边缘会闪。保留接口兼容调用方。 */
    public void setShadow(boolean on) {
    }

    public float getContentAlpha() {
        return contentAlpha;
    }

    public void setContentAlpha(float v) {
        contentAlpha = Math.max(0f, Math.min(1f, v));
        invalidate();
    }

    public void setLines(int n) {
        lines = Math.max(1, Math.min(4, n));
        invalidate();
    }

    public void setLevel(float v) {
        level = v;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        final Context c = getContext();
        float w = getWidth();
        float h = getHeight();
        if (w <= 0 || h <= 0) return;
        float iw = w - padR - leftInset;
        float ih = h - padB;
        if (iw <= 0 || ih <= 0) return;

        if (cutScreenR > 0f) {
            try {
                getLocationOnScreen(locTmp);
                cutR = cutScreenR - locTmp[0];
                cutB = cutScreenB - locTmp[1];
            } catch (Exception ignored) {
                cutR = 0f;
                cutB = 0f;
            }
        } else {
            cutR = 0f;
            cutB = 0f;
        }
        boolean card = showText && ih >= Common.dp(c, 46);
        if (!(showText && kind == KIND_MUSIC && ih >= Common.dp(c, 104))) btnCount = 0;
        float r = card ? Math.min(ih * 0.5f, Common.dp(c, 30))
                : (shape == 1 ? Math.min(ih * 0.5f, Common.dp(c, 22)) : ih / 2f);
        float[] rad = (shape == 1 && !card)
                ? new float[]{0, 0, 0, 0, r, r, r, r}
                : new float[]{r, r, r, r, r, r, r, r};
        if (flatAmt > 0f) {
            float rr = r * (1f - flatAmt);
            if (flatSide == 1) {
                rad[0] = rr;
                rad[1] = rr;
                rad[6] = rr;
                rad[7] = rr;
            } else if (flatSide == 2) {
                rad[2] = rr;
                rad[3] = rr;
                rad[4] = rr;
                rad[5] = rr;
            }
        }

        stroke.setShader(new LinearGradient(leftInset, 0, w - padR, 0,
                new int[]{0x665EE7FF, 0x559A6BFF, 0x33FFFFFF},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        if (idle && !showText && idleCircleD > 0) {
            float cw = w - padR - leftInset;
            float dia = Math.min(idleCircleD, Math.min(cw, ih)) - 1.2f;
            float cx = leftInset + cw / 2f;
            float cy = ih / 2f;
            oval.set(cx - dia / 2f, cy - dia / 2f, cx + dia / 2f, cy + dia / 2f);
            pill.reset();
            pill.addOval(oval, Path.Direction.CW);
        } else {
            oval.set(leftInset + 0.6f, 0.6f, w - padR - 0.6f, ih - 0.6f);
            pill.reset();
            pill.addRoundRect(oval, rad, Path.Direction.CW);
        }
        int saveDrag = canvas.save();
        canvas.translate(dragX, dragY);
        // 桥在岛下面：胶囊把桥压住，接口处更像同一个形状
        if (bridgeW > 1f && bridgeAlpha > 0.01f) drawBridge(canvas, ih);
        canvas.drawPath(pill, body);
        // 削平的那条边不描边，接缝才不会露出一条高光线
        if (flatAmt > 0.02f) {
            canvas.save();
            if (flatSide == 1) canvas.clipRect(leftInset + 0.4f, 0, w, h);
            else if (flatSide == 2) canvas.clipRect(0, 0, w - padR - 0.4f, h);
            canvas.drawPath(pill, stroke);
            canvas.restore();
        } else if (strokeHole != 0) {
            float cy = ih / 2f;
            float hh = ih * 0.32f;
            android.graphics.RectF hole = new android.graphics.RectF();
            if (strokeHole == 1) {
                hole.set(0, cy - hh, leftInset + Common.dp(c, 3f), cy + hh);
            } else {
                hole.set(w - padR - Common.dp(c, 3f), cy - hh, w, cy + hh);
            }
            canvas.save();
            canvas.clipOutRect(hole);
            canvas.drawPath(pill, stroke);
            canvas.restore();
        } else {
            canvas.drawPath(pill, stroke);
        }

        if (idle && !showText) {
            canvas.restoreToCount(saveDrag);
            return;
        }

        int alphaLayer = -1;
        if (contentAlpha < 0.999f) {
            alphaLayer = canvas.saveLayerAlpha(0, 0, w, h,
                    (int) (255 * contentAlpha), Canvas.ALL_SAVE_FLAG);
        }
        boolean big = showText && ih >= Common.dp(c, 46);
        if (big && kind == KIND_MUSIC && ih >= Common.dp(c, 104)) {
            drawMusic(canvas, c, w, ih);
        } else if (big && kind == KIND_QUICK) {
            drawQuick(canvas, c, w, ih);
        } else if (big) {
            drawExpanded(canvas, c, w, ih);
        } else {
            drawCompact(canvas, c, w, ih);
        }
        if (alphaLayer >= 0) canvas.restoreToCount(alphaLayer);
        canvas.restoreToCount(saveDrag);
    }

    /** 收起：图片 / 应用图标贴左侧，律动条（或小亮点）贴右侧。 */
    private void drawCompact(Canvas canvas, Context c, float w, float ih) {
        float avail = w - padR - leftInset;
        boolean twoEnds = avail >= ih * 1.12f;
        float iconSize = Math.min(Common.dp(c, 30), ih * 0.76f);
        iconSize = Math.min(iconSize, twoEnds ? avail * 0.34f : avail * 0.78f);
        float cx = twoEnds ? leftInset + Common.dp(c, 7) + iconSize / 2f
                : leftInset + avail / 2f;
        float cy = ih / 2f;

        drawIcon(canvas, c, cx, cy, iconSize, !twoEnds);
        if (progress >= 0) drawRing(canvas, c, cx, cy, iconSize);

        if (!twoEnds) return;
        float rightEdge = w - padR - Common.dp(c, 8);
        float room = Math.max(Common.dp(c, 12), rightEdge - (cx + iconSize / 2f + Common.dp(c, 6)));
        if (animating && !playing) {
            drawSilentBars(canvas, c, rightEdge, cy, true, room);
        } else if (animating) {
            drawBars(canvas, c, rightEdge, cy, true, room);
        } else {
            // 右侧一个小亮点，让「两边都有东西」的结构成立，同时不挡前摄
            Paint p = barPaint;
            p.setColor(accent);
            p.setAlpha(200);
            canvas.drawCircle(w - padR - Common.dp(c, 10), cy, Common.dp(c, 2.4f), p);
        }
    }

    /** 展开：dynamicSpot 式大卡片，图标 + 标题 + 正文 + 进度 / 律动。 */
    private void drawExpanded(Canvas canvas, Context c, float w, float ih) {
        float iconSize = Math.min(Common.dp(c, 40), ih * 0.50f);
        float left = leftInset + Common.dp(c, 14);
        float cx = left + iconSize / 2f;
        float cy = ih / 2f;
        drawIcon(canvas, c, cx, cy, iconSize, false);
        if (progress >= 0) drawRing(canvas, c, cx, cy, iconSize);

        float textX = left + iconSize + Common.dp(c, 12);
        float right = w - padR - Common.dp(c, 14);
        float accW = animating ? Common.dp(c, 46)
                : (progress >= 0 || kind == KIND_CHARGE) ? Common.dp(c, 44) : 0;
        boolean hasSub = sub.length() > 0;
        float titleH = titlePaint.getTextSize() * 1.2f;
        StaticLayout body = null;
        float blockH = titleH;
        float top;
        boolean overlapped = cutB > Common.dp(c, 10) && textX < cutR;

        float avail = Math.max(0, right - accW - textX);
        if (hasSub && avail > Common.dp(c, 20)) {
            int aw = (int) avail;
            if (cacheBody == null || cacheW != aw || !sub.equals(cacheSub)) {
                cacheSub = sub;
                cacheW = aw;
                cacheBody = StaticLayout.Builder.obtain(sub, 0, sub.length(), subPaint, aw)
                        .setMaxLines(lines)
                        .setEllipsize(TextUtils.TruncateAt.END)
                        .setLineSpacing(Common.dp(c, 2f), 1f)
                        .build();
            }
            body = cacheBody;
            blockH = titleH + body.getHeight() + Common.dp(c, 3);
        }
        top = Math.max(Common.dp(c, 10),
                Math.min(ih - blockH - Common.dp(c, 10), (ih - blockH) / 2f));
        if (overlapped && top < cutB) {
            float down = cutB + Common.dp(c, 4);
            if (down + blockH <= ih - Common.dp(c, 8)) {
                // 能整块放到前摄下面：标题和正文都往下挪，宽度不减
                top = down;
            } else if (right - accW - (cutR + Common.dp(c, 4)) > Common.dp(c, 96)) {
                // 放不下就改成从前摄右侧开始写
                textX = cutR + Common.dp(c, 4);
                avail = Math.max(0, right - accW - textX);
                if (body != null) {
                    int aw = (int) avail;
                    cacheSub = sub;
                    cacheW = aw;
                    cacheBody = StaticLayout.Builder.obtain(sub, 0, sub.length(), subPaint, aw)
                            .setMaxLines(lines)
                            .setEllipsize(TextUtils.TruncateAt.END)
                            .setLineSpacing(Common.dp(c, 2f), 1f)
                            .build();
                    body = cacheBody;
                    blockH = titleH + body.getHeight() + Common.dp(c, 3);
                    top = Math.max(Common.dp(c, 10),
                            Math.min(ih - blockH - Common.dp(c, 10), (ih - blockH) / 2f));
                }
            }
        }
        if (avail > Common.dp(c, 20)) {
            CharSequence t = TextUtils.ellipsize(title, titlePaint, avail, TextUtils.TruncateAt.END);
            canvas.drawText(t.toString(), textX, top + titlePaint.getTextSize(), titlePaint);
            if (body != null) {
                int sv = canvas.save();
                canvas.translate(textX, top + titleH + Common.dp(c, 3));
                body.draw(canvas);
                canvas.restoreToCount(sv);
            }
        }

        if (progress >= 0) {
            float by = ih - Common.dp(c, 16);
            float bw = Math.max(0, right - textX);
            track.setStrokeWidth(Common.dp(c, 3.5f));
            canvas.drawLine(textX, by, textX + bw, by, track);
            barPaint.setColor(accent);
            barPaint.setAlpha(255);
            barPaint.setStrokeWidth(Common.dp(c, 3.5f));
            canvas.drawLine(textX, by, textX + bw * Math.max(0, Math.min(100, progress)) / 100f,
                    by, barPaint);
            String s = progress + "%";
            float tw = badgePaint.measureText(s);
            canvas.drawText(s, right - tw, ih - Common.dp(c, 21), badgePaint);
        } else if (animating) {
            drawBars(canvas, c, right, cy, false, accW - Common.dp(c, 4));
        } else if (kind == KIND_CHARGE) {
            String s = title.replaceAll("[^0-9%]", "");
            float tw = badgePaint.measureText(s);
            canvas.drawText("⚡", right - tw - Ui.sp(c, 14), cy + badgePaint.getTextSize() * 0.35f,
                    badgePaint);
            if (tw > 0) {
                canvas.drawText(s, right - tw, cy + badgePaint.getTextSize() * 0.35f, badgePaint);
            }
        }
    }

    /** 快捷应用选择：展开后一排排图标，点哪个开哪个。 */
    private void drawQuick(Canvas canvas, Context c, float w, float ih) {
        int apps = Math.min(quickApps.length, quickHide ? 9 : 10);
        int n = apps + (quickHide ? 1 : 0);
        quickCount = n;
        for (int i = 0; i < 10; i++) quickRects[i].setEmpty();
        if (n == 0) {
            canvas.drawText("没有选应用", w / 2f - badgePaint.measureText("没有选应用") / 2f,
                    ih / 2f, badgePaint);
            return;
        }
        int cols = Math.min(n, 5);
        int rows = (n + cols - 1) / cols;
        float left = leftInset + Common.dp(c, 8);
        float right = w - padR - Common.dp(c, 8);
        float slot = (right - left) / cols;
        float rowH = ih / rows;
        for (int i = 0; i < n; i++) {
            int r = i / cols;
            int col = i % cols;
            float cx = left + slot * col + slot / 2f;
            float cy = rowH * r + rowH * 0.40f;
            float size = Math.min(Common.dp(c, 34), rowH * 0.48f);
            if (quickHide && i == 0) {
                // 隐藏岛格子
                barPaint.setColor(0x22FFFFFF);
                barPaint.setAlpha(255);
                canvas.drawCircle(cx, cy, size / 2f, barPaint);
                drawGlyph(canvas, c, 4, cx, cy, 0xFFB8BECD);
                textPaint9.setColor(0xFFC8CDDA);
                textPaint9.setTextSize(Ui.sp(c, 10f));
                float tw0 = textPaint9.measureText("隐藏");
                canvas.drawText("隐藏", cx - tw0 / 2f,
                        cy + size / 2f + Common.dp(c, 12), textPaint9);
                quickRects[i].set(cx - slot / 2f, rowH * r, cx + slot / 2f, rowH * (r + 1));
                continue;
            }
            int ai = quickHide ? i - 1 : i;
            Bitmap bmp = quickApps[ai].icon;
            if (bmp != null && !bmp.isRecycled()) {
                iconBox.set(cx - size / 2f, cy - size / 2f, cx + size / 2f, cy + size / 2f);
                int save = canvas.save();
                clip.reset();
                clip.addCircle(cx, cy, size / 2f, Path.Direction.CW);
                canvas.clipPath(clip);
                iconPaint.setAlpha(255);
                canvas.drawBitmap(bmp, null, iconBox, iconPaint);
                canvas.restoreToCount(save);
            } else {
                barPaint.setColor(0x33FFFFFF);
                barPaint.setAlpha(255);
                canvas.drawCircle(cx, cy, size / 2f, barPaint);
            }
            String lab = quickApps[ai].label;
            if (lab.length() > 4) lab = lab.substring(0, 4) + "…";
            textPaint9.setColor(0xFFC8CDDA);
            textPaint9.setTextSize(Ui.sp(c, 10f));
            float tw = textPaint9.measureText(lab);
            canvas.drawText(lab, cx - tw / 2f, cy + size / 2f + Common.dp(c, 12), textPaint9);
            quickRects[i].set(cx - slot / 2f, rowH * r, cx + slot / 2f, rowH * (r + 1));
        }
    }

    /** 音乐展开卡片：封面 + 歌名 + 真实律动 + 喜欢 / 上一首 / 暂停 / 下一首。 */
    private void drawMusic(Canvas canvas, Context c, float w, float ih) {
        float cover = Math.min(Common.dp(c, 60), ih * 0.44f);
        float left = leftInset + Common.dp(c, 14);
        float top = Common.dp(c, 14);
        float cy1 = top + cover / 2f;
        drawIcon(canvas, c, left + cover / 2f, cy1, cover, false);

        float textX = left + cover + Common.dp(c, 12);
        float right = w - padR - Common.dp(c, 14);
        float accW = animating ? Common.dp(c, 44) : 0;
        float avail = Math.max(0, right - accW - textX);
        float ty = cy1;
        if (cutB > Common.dp(c, 10) && textX < cutR
                && cy1 - titlePaint.getTextSize() < cutB) {
            // 歌名整块挪到前摄下面，宽度保持整行
            ty = Math.max(cy1, cutB + Common.dp(c, 14));
            float rowY0 = ih - Common.dp(c, 34);
            if (ty + Common.dp(c, 18) > rowY0 - Common.dp(c, 8)) {
                ty = rowY0 - Common.dp(c, 8) - Common.dp(c, 18);
            }
        }
        if (avail > Common.dp(c, 20)) {
            CharSequence t = TextUtils.ellipsize(title, titlePaint, avail, TextUtils.TruncateAt.END);
            canvas.drawText(t.toString(), textX, ty - Common.dp(c, 3), titlePaint);
            if (sub.length() > 0) {
                CharSequence s = TextUtils.ellipsize(sub, subPaint, avail, TextUtils.TruncateAt.END);
                canvas.drawText(s.toString(), textX, ty + Common.dp(c, 14), subPaint);
            }
        }
        if (animating) {
            if (playing) drawBars(canvas, c, right, cy1, false, accW - Common.dp(c, 4));
            else drawSilentBars(canvas, c, right, cy1, false, accW - Common.dp(c, 4));
        }

        float rowY = ih - Common.dp(c, 34);
        int base = noLike ? 3 : 4;
        int count = base + (hideBtn ? 1 : 0);
        btnCount = count;
        float slot = (w - leftInset - padR - Common.dp(c, 28)) / count;
        float startX = leftInset + Common.dp(c, 14);
        for (int i = 0; i < btns.length; i++) btns[i].setEmpty();
        for (int i = 0; i < count; i++) {
            float cx = startX + slot * i + slot / 2f;
            float r = Common.dp(c, 16);
            float hr = r + Common.dp(c, 6);
            btns[i].set(cx - hr, rowY - hr, cx + hr, rowY + hr);
            int g = hideBtn ? i - 1 : i;
            if (hideBtn && i == 0) {
                btnBg.setColor(0x14FFFFFF);
                if (i == pressed) btnBg.setColor(0x2EFFFFFF);
                canvas.drawCircle(cx, rowY, r, btnBg);
                drawGlyph(canvas, c, 4, cx, rowY, 0xFFB8BECD);
                continue;
            }
            boolean hot = (!noLike && g == 0 && liked);
            btnBg.setColor(hot ? 0x33FF4D6D : 0x14FFFFFF);
            if (i == pressed) btnBg.setColor(0x2EFFFFFF);
            canvas.drawCircle(cx, rowY, r, btnBg);
            int glyph = noLike ? (g == 0 ? 1 : g == 1 ? 2 : 3) : g;
            drawGlyph(canvas, c, glyph, cx, rowY, hot ? 0xFFFF4D6D : 0xFFE8ECF4);
        }
    }

    /** 极简线条图标：喜欢 / 上一首 / 播放暂停 / 下一首。 */
    private void drawGlyph(Canvas canvas, Context c, int i, float cx, float cy, int color) {
        Paint f = btnFg;
        f.setColor(color);
        f.setStyle(Paint.Style.FILL);
        f.setStrokeWidth(Common.dp(c, 1.8f));
        float s = Common.dp(c, 5.2f);
        if (i == 4) {
            f.setStyle(Paint.Style.STROKE);
            Path p = new Path();
            float d = s * 0.9f;
            p.moveTo(cx - d, cy - s * 0.5f);
            p.lineTo(cx, cy + s * 0.55f);
            p.lineTo(cx + d, cy - s * 0.5f);
            p.moveTo(cx - d, cy + s * 1.05f);
            p.lineTo(cx + d, cy + s * 1.05f);
            canvas.drawPath(p, f);
        } else if (i == 0) {
            Path p = new Path();
            p.moveTo(cx, cy + s * 1.15f);
            p.cubicTo(cx - s * 1.5f, cy, cx - s * 1.15f, cy - s * 1.05f, cx, cy - s * 0.35f);
            p.cubicTo(cx + s * 1.15f, cy - s * 1.05f, cx + s * 1.5f, cy, cx,
                    cy + s * 1.15f);
            if (liked) canvas.drawPath(p, f);
            else {
                f.setStyle(Paint.Style.STROKE);
                canvas.drawPath(p, f);
            }
        } else if (i == 1 || i == 3) {
            float dir = i == 1 ? -1f : 1f;
            Path p = new Path();
            p.moveTo(cx - dir * s * 1.25f, cy - s * 0.95f);
            p.lineTo(cx + dir * s * 0.65f, cy);
            p.lineTo(cx - dir * s * 1.25f, cy + s * 0.95f);
            p.close();
            canvas.drawPath(p, f);
            f.setStyle(Paint.Style.STROKE);
            f.setStrokeWidth(Common.dp(c, 1.6f));
            canvas.drawLine(cx + dir * s * 0.9f, cy - s * 0.95f,
                    cx + dir * s * 0.9f, cy + s * 0.95f, f);
        } else if (playing) {
            float bw = Common.dp(c, 1.7f);
            float hh = s * 1.25f;
            f.setStyle(Paint.Style.FILL);
            canvas.drawRoundRect(new RectF(cx - s * 0.75f, cy - hh / 2f,
                    cx - s * 0.75f + bw, cy + hh / 2f), bw / 2f, bw / 2f, f);
            canvas.drawRoundRect(new RectF(cx + s * 0.75f - bw, cy - hh / 2f,
                    cx + s * 0.75f, cy + hh / 2f), bw / 2f, bw / 2f, f);
        } else {
            Path p = new Path();
            p.moveTo(cx - s * 0.55f, cy - s * 1.05f);
            p.lineTo(cx + s * 1.1f, cy);
            p.lineTo(cx - s * 0.55f, cy + s * 1.05f);
            p.close();
            canvas.drawPath(p, f);
        }
    }

    /** 无声状态：静态低矮律动条，表示「当前没有声音」。 */
    private void drawSilentBars(Canvas canvas, Context c, float right, float cy,
                                boolean compact, float maxW) {
        float footprint = Math.min(maxW, compact ? Common.dp(c, 30) : Common.dp(c, 44));
        int n = hiRes ? (compact ? 14 : 16) : (compact ? 5 : 7);
        float bw = Math.max(Common.dp(c, 1f), footprint / (n * 1.95f));
        float gap = bw * 0.95f;
        float base = compact ? Common.dp(c, 4f) : Common.dp(c, 5f);
        barPaint.setStrokeWidth(bw);
        barPaint.setAlpha(110);
        barPaint.setColor(accent);
        for (int i = 0; i < n; i++) {
            float hh = base + (i % 2 == 0 ? Common.dp(c, 1.5f) : 0);
            float x = right - (n - 1 - i) * (bw + gap);
            canvas.drawLine(x, cy - hh / 2f, x, cy + hh / 2f, barPaint);
        }
    }

    /** 律动：一列竖条上下对称，快起慢落，声音大也不会全部顶满。 */
    private void drawBars(Canvas canvas, Context c, float right, float cy,
                          boolean compact, float maxW) {
        float t = (System.currentTimeMillis() - startAt) / 1000f;
        // 高分辨率只改变密度：总占用宽度不变，条数变多、每条更细
        float footprint = Math.min(maxW, compact ? Common.dp(c, 30) : Common.dp(c, 44));
        int n = hiRes ? (compact ? 14 : 16) : (compact ? 5 : 7);
        float bw = Math.max(Common.dp(c, 1f), footprint / (n * 1.95f));
        float gap = bw * 0.95f;
        float maxH = compact ? Common.dp(c, 19) : Common.dp(c, 30);
        barPaint.setStrokeWidth(bw);
        barPaint.setColor(accent);
        barPaint.setAlpha(compact ? 210 : 235);
        long now = System.currentTimeMillis();
        float dt = lastBarAt == 0 ? 0.016f : Math.min(0.06f, (now - lastBarAt) / 1000f);
        lastBarAt = now;
        for (int i = 0; i < n; i++) {
            double phase = t * (3.4 + (i % 5) * 1.35) + i * 1.7;
            // 每根条一个固定权重：长短差异更明显，不再是一片齐刷刷
            float wv = 0.45f + 0.55f * ((i * 7 % 5) / 4f);
            float s1 = (float) Math.abs(Math.sin(phase));
            float target;
            if (level >= 0) {
                // 软饱和：再大声也不会所有条一起顶满，留出层次
                float norm = (float) Math.tanh(level * 1.7f);
                target = 0.10f + 0.90f * norm * (0.35f + 0.65f * wv)
                        * (0.30f + 0.70f * s1);
            } else {
                target = 0.10f + 0.90f * s1 * (0.45f + 0.75f * wv);
            }
            target = Math.min(0.97f, target);
            // 快起慢落：短促的鼓点冲上去，再慢慢落回来
            float e = i < env.length ? env[i] : 0f;
            if (target > e) e += (target - e) * 0.62f;
            else e -= dt * 1.5f;
            e = Math.max(0.04f, Math.min(1f, e));
            if (i < env.length) env[i] = e;
            float f = e;
            if (compact) f = Math.min(1f, f * 1.05f);
            if (colorful) {
                Color.colorToHSV(accent, hsv);
                hsv[0] = (hsv[0] + i * 13f) % 360f;
                hsv[1] = Math.min(1f, hsv[1] + 0.12f);
                barPaint.setColor(Color.HSVToColor(hsv));
            }
            float hgt = maxH * f;
            float x = right - (n - 1 - i) * (bw + gap);
            canvas.drawLine(x, cy - hgt / 2f, x, cy + hgt / 2f, barPaint);
        }
        if (animating && playing) postInvalidateOnAnimation();
    }

    /** 系统事件：极简线条图案。 */
    private void drawSysIcon(Canvas canvas, Context c, float cx, float cy, float size) {
        Paint p = barPaint;
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setStrokeWidth(Math.max(Common.dp(c, 1.4f), size * 0.075f));
        p.setColor(accent);
        p.setAlpha(255);
        float u = size * 0.30f;
        float r = size * 0.30f;
        if (sysStyle == SYS_UNLOCK) {
            // 开锁：锁体 + 抬起的锁梁
            oval.set(cx - u * 1.15f, cy - u * 0.15f, cx + u * 1.15f, cy + u * 1.35f);
            canvas.drawRoundRect(oval, u * 0.45f, u * 0.45f, p);
            Path arc = new Path();
            arc.moveTo(cx - u * 0.72f, cy - u * 0.15f);
            arc.cubicTo(cx - u * 0.72f, cy - u * 1.5f, cx + u * 0.95f, cy - u * 1.5f,
                    cx + u * 0.95f, cy - u * 0.55f);
            canvas.drawPath(arc, p);
            p.setStyle(Paint.Style.FILL);
            canvas.drawCircle(cx, cy + u * 0.62f, u * 0.19f, p);
        } else if (sysStyle == SYS_HEADSET) {
            Path arc = new Path();
            arc.moveTo(cx - u * 1.1f, cy + u * 0.15f);
            arc.cubicTo(cx - u * 1.1f, cy - u * 1.5f, cx + u * 1.1f, cy - u * 1.5f,
                    cx + u * 1.1f, cy + u * 0.15f);
            canvas.drawPath(arc, p);
            float ew = u * 0.56f;
            float eh = u * 1.05f;
            oval.set(cx - u * 1.1f - ew * 0.15f, cy + u * 0.05f,
                    cx - u * 1.1f + ew * 0.85f, cy + u * 0.05f + eh);
            canvas.drawRoundRect(oval, ew * 0.45f, ew * 0.45f, p);
            oval.set(cx + u * 1.1f - ew * 0.85f, cy + u * 0.05f,
                    cx + u * 1.1f + ew * 0.15f, cy + u * 0.05f + eh);
            canvas.drawRoundRect(oval, ew * 0.45f, ew * 0.45f, p);
        } else if (sysStyle == SYS_FULL) {
            drawBattery(canvas, c, cx, cy, size, false);
            Path tick = new Path();
            tick.moveTo(cx - u * 0.42f, cy + u * 0.02f);
            tick.lineTo(cx - u * 0.10f, cy + u * 0.36f);
            tick.lineTo(cx + u * 0.58f, cy - u * 0.42f);
            p.setColor(0xFF38D98A);
            p.setAlpha(255);
            canvas.drawPath(tick, p);
        } else if (sysStyle == SYS_LOW) {
            drawBattery(canvas, c, cx, cy, size, false);
            p.setColor(0xFFFF4D4D);
            p.setStyle(Paint.Style.FILL);
            canvas.drawRect(cx - u * 0.30f, cy - u * 0.20f, cx - u * 0.06f, cy + u * 0.40f, p);
            canvas.drawRect(cx + u * 0.10f, cy - u * 0.20f, cx + u * 0.34f, cy + u * 0.40f, p);
        } else if (sysStyle == SYS_SILENT) {
            Path sp = new Path();
            sp.moveTo(cx - u * 1.05f, cy - u * 0.35f);
            sp.lineTo(cx - u * 0.62f, cy - u * 0.35f);
            sp.lineTo(cx - u * 0.05f, cy - u * 1.05f);
            sp.lineTo(cx - u * 0.05f, cy + u * 1.05f);
            sp.lineTo(cx - u * 0.62f, cy + u * 0.35f);
            sp.lineTo(cx - u * 1.05f, cy + u * 0.35f);
            sp.close();
            canvas.drawPath(sp, p);
            canvas.drawLine(cx + u * 0.35f, cy - u * 0.55f, cx + u * 1.15f, cy + u * 0.55f, p);
            canvas.drawLine(cx + u * 1.15f, cy - u * 0.55f, cx + u * 0.35f, cy + u * 0.55f, p);
        } else if (sysStyle == SYS_VIBRATE) {
            oval.set(cx - u * 0.42f, cy - u * 1.05f, cx + u * 0.42f, cy + u * 1.05f);
            canvas.drawRoundRect(oval, u * 0.28f, u * 0.28f, p);
            canvas.drawLine(cx - u * 0.72f, cy - u * 0.62f, cx - u * 1.05f, cy - u * 0.35f, p);
            canvas.drawLine(cx - u * 0.72f, cy + u * 0.62f, cx - u * 1.05f, cy + u * 0.35f, p);
            canvas.drawLine(cx + u * 0.72f, cy - u * 0.62f, cx + u * 1.05f, cy - u * 0.35f, p);
            canvas.drawLine(cx + u * 0.72f, cy + u * 0.62f, cx + u * 1.05f, cy + u * 0.35f, p);
        } else {
            // 铃响：铃铛
            Path bell = new Path();
            bell.moveTo(cx - u * 1.0f, cy + u * 0.62f);
            bell.cubicTo(cx - u * 0.62f, cy + u * 0.32f, cx - u * 0.72f, cy - u * 1.15f,
                    cx, cy - u * 1.15f);
            bell.cubicTo(cx + u * 0.72f, cy - u * 1.15f, cx + u * 0.62f, cy + u * 0.32f,
                    cx + u * 1.0f, cy + u * 0.62f);
            bell.close();
            canvas.drawPath(bell, p);
            p.setStyle(Paint.Style.FILL);
            canvas.drawCircle(cx, cy + u * 0.92f, u * 0.17f, p);
        }
    }

    /** 充电：画一个电池，充电时带闪电。 */
    private void drawBattery(Canvas canvas, Context c, float cx, float cy, float size, boolean charging) {
        float bw = size * 0.84f;
        float bh = size * 0.48f;
        float l = cx - bw / 2f;
        float t = cy - bh / 2f;
        float r = l + bw;
        float b = t + bh;
        float rad = bh * 0.30f;
        float sw = Math.max(Common.dp(c, 1.3f), size * 0.062f);
        int pct = -1;
        java.util.regex.Matcher m =
                java.util.regex.Pattern.compile("(\\d{1,3})").matcher(title);
        if (m.find()) {
            try {
                pct = Integer.parseInt(m.group(1));
            } catch (Exception ignored) {
            }
        }
        Paint p = barPaint;
        p.setShader(null);
        p.setAlpha(255);
        p.setColor(charging ? 0xFFFFB23E : 0xFF8B93A5);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(sw);
        oval.set(l, t, r, b);
        canvas.drawRoundRect(oval, rad, rad, p);
        // 正极凸起
        p.setStyle(Paint.Style.FILL);
        canvas.drawRoundRect(r + sw * 0.6f, cy - bh * 0.15f,
                r + sw * 0.6f + size * 0.055f, cy + bh * 0.15f, sw * 0.5f, sw * 0.5f, p);
        // 电量
        int lv = pct < 0 ? 50 : Math.max(0, Math.min(100, pct));
        if (charging && lv < 12) lv = 12;
        float in = sw * 1.15f;
        float fw = Math.max(0, (bw - in * 2f) * lv / 100f);
        if (fw > 0.5f) {
            p.setAlpha(charging ? 210 : 150);
            canvas.drawRoundRect(l + in, t + in, l + in + fw, b - in,
                    rad * 0.6f, rad * 0.6f, p);
        }
        if (charging) {
            // 中间一道小闪电
            float bx = cx;
            float by = cy;
            float u = size * 0.11f;
            Path bolt = new Path();
            bolt.moveTo(bx + u * 0.15f, by - u);
            bolt.lineTo(bx - u * 0.55f, by + u * 0.12f);
            bolt.lineTo(bx - u * 0.08f, by + u * 0.12f);
            bolt.lineTo(bx - u * 0.18f, by + u);
            bolt.lineTo(bx + u * 0.55f, by - u * 0.14f);
            bolt.lineTo(bx + u * 0.06f, by - u * 0.14f);
            bolt.close();
            p.setColor(0xFF1A1A1E);
            p.setAlpha(255);
            canvas.drawPath(bolt, p);
        }
    }

    /** 液态桥：两端粗、中间细，左端藏在主岛下面。 */
    private void drawBridge(Canvas canvas, float ih) {
        float mid = ih / 2f;
        float e = ih * bridgeEnd / 2f;
        float m = ih * bridgeMid / 2f;
        if (m > e) m = e;
        float bw = bridgeW;
        bridgePath.reset();
        bridgePath.moveTo(0, mid - e);
        bridgePath.cubicTo(bw * 0.30f, mid - e, bw * 0.34f, mid - m, bw * 0.5f, mid - m);
        bridgePath.cubicTo(bw * 0.66f, mid - m, bw * 0.70f, mid - e, bw, mid - e);
        bridgePath.lineTo(bw, mid + e);
        bridgePath.cubicTo(bw * 0.70f, mid + e, bw * 0.66f, mid + m, bw * 0.5f, mid + m);
        bridgePath.cubicTo(bw * 0.34f, mid + m, bw * 0.30f, mid + e, 0, mid + e);
        bridgePath.close();
        bridgePaint.setAlpha((int) (255 * bridgeAlpha));
        canvas.drawPath(bridgePath, bridgePaint);
    }

    private void drawIcon(Canvas canvas, Context c, float cx, float cy, float size, boolean center) {
        if (kind == KIND_CHARGE && size > 0) {
            drawBattery(canvas, c, cx, cy, size, true);
            return;
        }
        if (kind == KIND_SYS && size > 0) {
            drawSysIcon(canvas, c, cx, cy, size);
            return;
        }
        if (icon == null || icon.isRecycled() || size <= 0) return;
        iconBox.set(cx - size / 2f, cy - size / 2f, cx + size / 2f, cy + size / 2f);
        int save = canvas.save();
        clip.reset();
        clip.addCircle(cx, cy, size / 2f, Path.Direction.CW);
        canvas.clipPath(clip);
        iconPaint.setAlpha(255);
        canvas.drawBitmap(icon, null, iconBox, iconPaint);
        canvas.restoreToCount(save);
    }

    private void drawRing(Canvas canvas, Context c, float cx, float cy, float iconSize) {
        float p2 = Common.dp(c, 1.5f);
        oval.set(cx - iconSize / 2f - p2, cy - iconSize / 2f - p2,
                cx + iconSize / 2f + p2, cy + iconSize / 2f + p2);
        arc.setStrokeWidth(Common.dp(c, 2f));
        arc.setColor(0x33FFFFFF);
        canvas.drawArc(oval, -90, 360, false, arc);
        arc.setColor(accent);
        canvas.drawArc(oval, -90, 360f * Math.max(0, Math.min(100, progress)) / 100f,
                false, arc);
    }

    private void drawBars(Canvas canvas, Context c, float right, float cy, boolean compact) {
        float t = (System.currentTimeMillis() - startAt) / 1000f;
        // 高分辨率只改变密度：总占用宽度不变，条数变多、每条更细
        float footprint = compact ? Common.dp(c, 30) : Common.dp(c, 44);
        int n = hiRes ? (compact ? 14 : 16) : (compact ? 5 : 7);
        float bw = Math.max(Common.dp(c, 1f), footprint / (n * 1.95f));
        float gap = bw * 0.95f;
        float maxH = compact ? Common.dp(c, 19) : Common.dp(c, 30);
        barPaint.setStrokeWidth(bw);
        barPaint.setColor(accent);
        barPaint.setAlpha(compact ? 210 : 235);
        long now = System.currentTimeMillis();
        float dt = lastBarAt == 0 ? 0.016f : Math.min(0.06f, (now - lastBarAt) / 1000f);
        lastBarAt = now;
        for (int i = 0; i < n; i++) {
            double phase = t * (3.4 + (i % 5) * 1.35) + i * 1.7;
            // 每根条一个固定权重：长短差异更明显，不再是一片齐刷刷
            float wv = 0.45f + 0.55f * ((i * 7 % 5) / 4f);
            float s1 = (float) Math.abs(Math.sin(phase));
            float target;
            if (level >= 0) {
                // 软饱和：再大声也不会所有条一起顶满，留出层次
                float norm = (float) Math.tanh(level * 1.7f);
                target = 0.10f + 0.90f * norm * (0.35f + 0.65f * wv)
                        * (0.30f + 0.70f * s1);
            } else {
                target = 0.10f + 0.90f * s1 * (0.45f + 0.75f * wv);
            }
            target = Math.min(0.97f, target);
            // 快起慢落：短促的鼓点冲上去，再慢慢落回来
            float e = env[i];
            if (target > e) e += (target - e) * 0.62f;
            else e -= dt * 1.5f;
            env[i] = Math.max(0.04f, Math.min(1f, e));
            float f = env[i];
            if (compact) f = Math.min(1f, f * 1.05f);
            if (colorful) {
                float[] hsv = new float[3];
                Color.colorToHSV(accent, hsv);
                hsv[0] = (hsv[0] + i * 13f) % 360f;
                hsv[1] = Math.min(1f, hsv[1] + 0.12f);
                barPaint.setColor(Color.HSVToColor(hsv));
            }
            float hgt = maxH * f;
            float x = right - (n - 1 - i) * (bw + gap);
            canvas.drawLine(x, cy - hgt / 2f, x, cy + hgt / 2f, barPaint);
        }
        if (animating && playing) postInvalidateOnAnimation();
    }

    private float downX, downY;
    private boolean moved;
    private boolean swipeFired;

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        boolean controls = showText && kind == KIND_MUSIC
                && getHeight() - padB >= Common.dp(getContext(), 104);
        float x = e.getX(), y = e.getY();
        if (!showText && !idleTouch(x, y)) return false;
        if (e.getAction() == MotionEvent.ACTION_DOWN) {
            downX = x;
            downY = y;
            moved = false;
            swipedFlag = false;
            pullFlag = false;
            swipeFired = false;
            longPressFired = false;
            cancelDragAnim();
            dragX = 0f;
            dragY = 0f;
            removeCallbacks(longPressTask);
            postDelayed(longPressTask, 460);
            if (controls) {
                pressed = hit(x, y);
                if (pressed >= 0) invalidate();
            }
            return true;
        }
        if (e.getAction() == MotionEvent.ACTION_MOVE) {
            float dx = x - downX, dy = y - downY;
            if (Math.abs(dx) > Common.dp(getContext(), 5)
                    || Math.abs(dy) > Common.dp(getContext(), 5)) {
                removeCallbacks(longPressTask);
            }
            if (!swipedFlag && !pullFlag) {
                float ax = Math.abs(dx), ay = Math.abs(dy);
                // 滑动到一定距离就直接执行，不做跟手拖动
                if (ax > Common.dp(getContext(), 46) && ax > ay * 1.25f) {
                    swipedFlag = true;
                    pressed = -1;
                    if (actions != null) actions.onSwipe(dx > 0 ? 1 : -1);
                    return true;
                }
                if (pullClose && dy > Common.dp(getContext(), 46) && ay > ax * 1.25f) {
                    pullFlag = true;
                    pressed = -1;
                }
            }
            if (swipedFlag) {
                // 已触发，等手势结束，不再做任何移动
                return true;
            }
            if (pullFlag) {
                float limY = Math.max(Common.dp(getContext(), 8), padB - Common.dp(getContext(), 2));
                dragY = Math.max(0f, Math.min(limY, dy * 0.55f));
                invalidate();
                return true;
            }
            if (Math.abs(dx) > Common.dp(getContext(), 8)
                    || Math.abs(dy) > Common.dp(getContext(), 8)) {
                moved = true;
            }
            if (pressed >= 0) {
                int p = hit(x, y);
                if (p != pressed) {
                    pressed = p;
                    invalidate();
                }
            }
            return true;
        }
        if (e.getAction() == MotionEvent.ACTION_UP) {
            removeCallbacks(longPressTask);
            if (longPressFired) {
                longPressFired = false;
                return true;
            }
            if (!moved && kind == KIND_QUICK && quickCount > 0) {
                for (int i = 0; i < quickCount && i < quickRects.length; i++) {
                    if (quickRects[i].contains(x, y)) {
                        if (actions != null) {
                            if (quickHide && i == 0) actions.onHideIsland();
                            else actions.onQuickApp(quickHide ? i - 1 : i);
                        }
                        return true;
                    }
                }
            }
            if (pullFlag) {
                float dy = y - downY;
                pullFlag = false;
                if (dy > Common.dp(getContext(), 26)) {
                    dragY = 0f;
                    dragX = 0f;
                    invalidate();
                    if (actions != null) actions.onPullDown();
                } else {
                    bounceBackY();
                }
                return true;
            }
            if (swipedFlag) {
                swipedFlag = false;
                return true;
            }
            if (pressed >= 0) {
                int p = pressed;
                pressed = -1;
                invalidate();
                if (!moved && hit(x, y) == p && actions != null) {
                    actions.onIslandAction(btnAction(p));
                }
                return true;
            }
            if (!moved && actions != null) actions.onTap();
            return true;
        }
        if (e.getAction() == MotionEvent.ACTION_CANCEL) {
            removeCallbacks(longPressTask);
            longPressFired = false;
            pressed = -1;
            float dy = y - downY;
            if (pullFlag && dy > Common.dp(getContext(), 26) && actions != null) {
                actions.onPullDown();
            } else if (pullFlag) {
                bounceBackY();
            }
            swipedFlag = false;
            pullFlag = false;
            cancelDragAnim();
            dragX = 0f;
            dragY = 0f;
            invalidate();
        }
        return true;
    }

    /** 下拉后回弹。 */
    private void bounceBackY() {
        if (dragY == 0f) return;
        cancelDragAnim();
        android.animation.ValueAnimator a =
                android.animation.ValueAnimator.ofFloat(dragY, 0f);
        dragAnim = a;
        a.setDuration(240);
        a.setInterpolator(new android.view.animation.OvershootInterpolator(1.6f));
        a.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator an) {
                dragAnim = null;
                dragY = 0f;
                dragX = 0f;
                invalidate();
            }
        });
        a.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(android.animation.ValueAnimator va) {
                dragY = (Float) va.getAnimatedValue();
                invalidate();
            }
        });
        a.start();
    }

    private void cancelDragAnim() {
        if (dragAnim != null) {
            android.animation.ValueAnimator old = dragAnim;
            dragAnim = null;
            old.cancel();
        }
    }

    /** 朝滑动方向撞一下再弹回。 */
    private void bounceBack() {
        if (dragX == 0f && dragY == 0f) return;
        cancelDragAnim();
        android.animation.ValueAnimator a =
                android.animation.ValueAnimator.ofFloat(dragX, 0f);
        a.setDuration(280);
        a.setInterpolator(new android.view.animation.OvershootInterpolator(2.2f));
        dragAnim = a;
        a.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator an) {
                dragAnim = null;
                dragX = 0f;
                dragY = 0f;
                invalidate();
            }
        });
        a.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(android.animation.ValueAnimator va) {
                dragX = (Float) va.getAnimatedValue();
                invalidate();
            }
        });
        a.start();
    }

    private int btnAction(int idx) {
        if (hideBtn) {
            if (idx == 0) return ACT_HIDE;
            idx--;
        }
        if (noLike) {
            return idx == 0 ? ACT_PREV : idx == 1 ? ACT_TOGGLE : ACT_NEXT;
        }
        return idx == 0 ? ACT_LIKE : idx == 1 ? ACT_PREV
                : idx == 2 ? ACT_TOGGLE : ACT_NEXT;
    }

    private int hit(float x, float y) {
        for (int i = 0; i < btnCount; i++) {
            if (btns[i].contains(x, y)) return i;
        }
        return -1;
    }
}
