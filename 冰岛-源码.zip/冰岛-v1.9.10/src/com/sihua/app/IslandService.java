/*
 * 冰岛 (Bingdao) - Android 灵动岛
 * Copyright (c) 2026 casuallw (Gitee: casual-wear / GitHub: Casuallw)
 * All rights reserved. Licensed under the Bingdao Non-Commercial License 1.1.
 * 非商业许可：禁止商用、倒卖或收费分发。完整条款见项目根目录 LICENSE 文件。
 * https://gitee.com/casual-wear/bingdao
 */
package com.sihua.app;

import android.Manifest;
import android.app.DownloadManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaMetadata;
import android.media.MediaRecorder;
import android.media.Rating;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.net.Uri;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.graphics.drawable.GradientDrawable;

import java.util.List;

/** 灵动岛：悬浮胶囊，接收消息 / 音乐 / 下载 / 充电事件。 */
public class IslandService extends Service {

    public static final String CHANNEL = "sihua_island";
    private static final int FG_ID = 0x5A11;
    private static final int HIDDEN_ID = 0x5A12;
    private static final String CHANNEL_HIDDEN = "sihua_hidden";

    static IslandService current;

    private WindowManager wm;
    private IslandView island;
    private WindowManager.LayoutParams lp;
    private android.animation.ValueAnimator widthAnim;
    private android.animation.ValueAnimator contentAnim;
    private IslandView sub;
    private WindowManager.LayoutParams subLp;
    private boolean subAttached;
    private int subKind, subAccent, subProgress;
    private String subTitle, subSub, subPkg;
    private Runnable subTask;
    private android.animation.ValueAnimator subAnim;
    private boolean subAnimCanceling;
    private int shiftPx;
    private int shiftGoal;
    private android.animation.ValueAnimator shiftAnim;
    private View replyBar;
    private Runnable restoreTask;
    private Runnable followTask;
    private boolean hiddenByUser;
    private final java.util.List<String> quickIndex = new java.util.ArrayList<String>();
    private boolean hasQuickPrev;
    private int quickPrevKind, quickPrevProgress, quickPrevAccent;
    private String quickPrevTitle, quickPrevSub, quickPrevPkg;
    private int batteryLevel = -1;
    private boolean batteryPlugged;
    private boolean fullNotified;
    private boolean lowNotified;
    private boolean headsetOn;
    private int lastRinger = -1;
    private int subPillLeft;
    private boolean subWasShown;
    private int absentTicks;
    private boolean idleExpanded;
    private boolean fgSuppressed;
    private String fgPkg;
    private int saveKind = -1, saveProgress, saveAccent;
    private String saveTitle, saveSub, savePkg;
    private int dragWinX;
    private int pullWinY;
    private int pullBaseY = -1;
    private android.animation.ValueAnimator pullAnim;
    private android.animation.ValueAnimator swipeAnim;
    private boolean pullPendingHide;
    private android.animation.ValueAnimator dragWinAnim;
    private int idleExtraX;
    private int dragPad;
    private int subTravelLeft;
    private int subInset;
    private boolean subWide;
    private android.animation.ValueAnimator bridgeAnim;
    private android.animation.ValueAnimator neckAnim;
    private NeckView neck;
    private WindowManager.LayoutParams neckLp;
    private boolean subShell;
    private float flatVal;
    private android.animation.ValueAnimator flatAnim;
    private final Handler h = new Handler(Looper.getMainLooper());
    private Runnable collapseTask;
    private Runnable dismissTask;
    private boolean attached;
    private boolean expanded;
    private boolean dismissing;
    private boolean a11yWin;
    private int musicH;
    private boolean liked;
    private AudioRecord mic;
    private android.media.audiofx.Visualizer vis;
    private int visSession;
    private boolean visHadData;
    private int visGen;
    private android.media.projection.MediaProjection projection;
    private Thread micThread;
    private volatile boolean micRun;
    private volatile float micLevel;
    private volatile float shownLevel;
    private final Runnable levelTick = new Runnable() {
        @Override
        public void run() {
            shownLevel += (micLevel - shownLevel) * 0.5f;
            if (island != null) island.setLevel(shownLevel);
            if (micRun) h.postDelayed(this, 60);
        }
    };
    private int compactW, expandedW, islandH, expandedH, idleW;
    private int shape, offX, offY, padS, padB;
    private boolean preview;
    private int lastKind = IslandView.KIND_NOTI;
    private String lastTitle, lastSub, lastPkg;
    private int lastProgress = -1, lastAccent = 0xFF5EE7FF;
    private String artRetryTitle;
    private boolean landscapeMusicOff;
    private Rating lastRating;
    private int lastArtSig;
    private Runnable artRefreshTask;

    private MediaSessionManager msm;
    private ComponentName listenerCn;
    private MediaController controller;
    private MediaController.Callback mediaCb;

    private BroadcastReceiver rx;
    private int batteryPct = -1;
    private Runnable dlTick;
    private boolean hadDownload;

    @Override
    public void onCreate() {
        super.onCreate();
        current = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        computeDims();
        createChannel();
        startForeground(FG_ID, buildFg());

        registerReceiver();
        setupMusic();
        startDownloadTick();
        startMediaPoll();

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "请先允许「冰岛」显示在其他应用上层", Toast.LENGTH_LONG).show();
            stopSelf();
            return;
        }
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (pinned()) {
                    showIdle();
                } else if (lastTitle == null) {
                    test();
                }
            }
        }, 500);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (Common.ACTION_STOP.equals(action)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!Common.getB(this, Common.K_ISLAND, true)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (Common.ACTION_RELOAD.equals(action)) {
            applyLook();
            if (msm == null) setupMusic();
            return START_STICKY;
        }
        if (Common.ACTION_TEST.equals(action)) {
            preview = false;
            test();
            return START_STICKY;
        }
        if (Common.ACTION_PREVIEW.equals(action)) {
            preview = true;
            computeDims();
            showPreview();
            return START_STICKY;
        }
        if (Common.ACTION_RESTORE_MUSIC.equals(action)) {
            landscapeMusicOff = false;
            cancelHiddenMusic();
            updateMusic();
            return START_STICKY;
        }
        if (Common.ACTION_PROJECTION.equals(action)) {
            if (Build.VERSION.SDK_INT >= 29) {
                int code = intent.getIntExtra("code", 0);
                Intent data = intent.getParcelableExtra("data");
                if (data != null) {
                    try {
                        android.media.projection.MediaProjectionManager mpm =
                                (android.media.projection.MediaProjectionManager)
                                        getSystemService(MEDIA_PROJECTION_SERVICE);
                        if (mpm != null) {
                            try {
                                startForeground(FG_ID, buildFg(),
                                        android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                                                | android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
                            } catch (Exception ignored) {
                            }
                            android.media.projection.MediaProjection mp =
                                    mpm.getMediaProjection(code, data);
                            if (mp != null) {
                                projection = mp;
                                mp.registerCallback(new android.media.projection.MediaProjection.Callback() {
                                    @Override
                                    public void onStop() {
                                        projection = null;
                                        stopMic();
                                    }
                                }, h);
                                if (Common.getB(this, Common.K_MIC, false)) {
                                    stopMic();
                                    startMic();
                                }
                            }
                        }
                    } catch (Exception e) {
                        Toast.makeText(this, "录屏授权失败：" + e.getMessage(),
                                Toast.LENGTH_LONG).show();
                    }
                }
            }
            return START_STICKY;
        }
        if (Common.ACTION_PREVIEW_IDLE.equals(action)) {
            preview = false;
            showIdle();
            return START_STICKY;
        }
        if (Common.ACTION_UNPREVIEW.equals(action)) {
            leavePreview();
            return START_STICKY;
        }
        if (pinned()) showIdle();
        return START_STICKY;
    }

    private void computeDims() {
        shape = Common.getI(this, Common.K_SHAPE, 0);
        int hDp = Common.clamp(Common.getI(this, Common.K_H, 34), 30, 70);
        int wDp = Common.clamp(Common.getI(this, Common.K_W, 139), 24, 280);
        islandH = Common.dp(this, hDp);
        compactW = Common.dp(this, wDp);
        int screenW = getResources().getDisplayMetrics().widthPixels;
        expandedW = Math.min(screenW - Common.dp(this, 32), Common.dp(this, 366));
        expandedW = Math.max(expandedW, compactW + Common.dp(this, 80));
        int lines = Common.clamp(Common.getI(this, Common.K_LINES, 2), 1, 4);
        expandedH = Math.max(islandH + Common.dp(this, 44),
                Common.dp(this, 84) + (lines - 1) * Common.dp(this, 15));
        expandedH = Math.min(expandedH, Common.dp(this, 210));
        musicH = Math.max(expandedH, Common.dp(this, 150));
        idleW = Math.max(Common.dp(this, 36),
                Math.min(Common.dp(this, 160), (int) (compactW * 0.62f)));
        offX = Common.dp(this, Common.getI(this, Common.K_X, 0));
        offY = Common.dp(this, Common.getI(this, Common.K_Y, 3));
        padS = IslandView.padSide(this);
        padB = IslandView.padBottom(this);
        dragPad = 0;
    }

    /** 主岛窗口左右各多留一格，左右拖动只画内容、不挪窗口，才不会卡。 */
    private int winW(int content) {
        return content + (padS + dragPad) * 2;
    }

    private int winH(int content) {
        return content + padB;
    }

    private void leavePreview() {
        h.removeCallbacks(collapseTask);
        h.removeCallbacks(dismissTask);
        preview = false;
        if (pinned()) {
            showIdle();
            return;
        }
        dismiss();
    }

    /** 常驻且没有事件：一条短一点的空胶囊。 */
    private void showIdle() {
        computeDims();
        idleExpanded = false;
        if (!Common.getB(this, Common.K_ISLAND, true)) return;
        if (hiddenByUser || isLandscape()) {
            removeIsland(island != null);
            return;
        }
        preview = false;
        boolean fresh = !attached;
        boolean wasEvent = lastTitle != null;
        if (!attach()) return;
        h.removeCallbacks(collapseTask);
        h.removeCallbacks(dismissTask);
        lastKind = IslandView.KIND_NOTI;
        lastTitle = null;
        lastSub = null;
        lastPkg = null;
        lastProgress = -1;
        island.setShape(shape);
        island.setData(IslandView.KIND_NOTI, "", "", null, -1, 0xFF5EE7FF);
        island.setPullClose(false);
        island.setHideBtn(false);
        island.setIdle(true);
        island.setShowText(false);
        expanded = false;
        boolean circle = Common.getB(this, Common.K_IDLE_CIRCLE, false);
        int circleD = Common.dp(this, Common.clamp(Common.getI(this, Common.K_IDLE_SIZE, 34), 20, 60));
        if (circle) {
            int content = circleD;
            int cy = offY + islandH / 2 - content / 2;
            int cx = offX;
            if (!Common.getB(this, Common.K_IDLE_LINK, true)) {
                cx = offX + Common.dp(this, Common.clamp(Common.getI(this, Common.K_IDLE_X, 0), -160, 160));
                cy += Common.dp(this, Common.clamp(Common.getI(this, Common.K_IDLE_Y, 0), -160, 160));
            }
            idleExtraX = cx - offX;
            if (fresh) {
                // 首次出现：点 → 圆，沿用弹出动画
                island.setIdleCircle(circleD);
                popIn(winW(content), winH(content), cy);
            } else {
                // 事件收成常驻：先按胶囊宽度收，收到和高度一样自然成圆（参考视频一）
                island.setIdleCircle(0);
                animateTo(winW(content), winH(content), cy, idleDur(wasEvent), circleEnd(circleD));
            }
        } else {
            island.setIdleCircle(0);
            idleExtraX = 0;
            if (fresh) popIn(winW(idleW), winH(islandH), yFor(false));
            else animateTo(winW(idleW), winH(islandH), yFor(false), idleDur(wasEvent), revealEnd());
        }
        applyCutout();
    }

    /** 收成圆形后再把常驻圆点开，同时把副岛露出来。 */
    private Runnable circleEnd(final int circleD) {
        return new Runnable() {
            @Override
            public void run() {
                if (island != null) island.setIdleCircle(circleD);
                revealSub();
            }
        };
    }

    /** 常驻岛出现 / 事件收成常驻：沿用消失动画的时长。 */
    private long idleDur(boolean wasEvent) {
        if (!wasEvent) return 300;
        return Common.clamp(Common.getI(this, Common.K_DISMISS_MS, 520), 200, 1000);
    }

    /** 缩回常驻后，把之前换到副岛的事件重新露出来。 */
    private Runnable revealEnd() {
        return new Runnable() {
            @Override
            public void run() {
                revealSub();
            }
        };
    }

    /** 前摄（圆形常驻岛覆盖区域）换算成岛的视图坐标，给文字让位。 */
    private void applyCutout() {
        if (island == null || lp == null) return;
        int sw = getResources().getDisplayMetrics().widthPixels;
        int d = Common.dp(this, Common.clamp(Common.getI(this, Common.K_IDLE_SIZE, 34), 20, 60));
        int cx = sw / 2 + offX;
        if (!Common.getB(this, Common.K_IDLE_LINK, true)) {
            cx += Common.dp(this, Common.clamp(Common.getI(this, Common.K_IDLE_X, 0), -160, 160));
        }
        int bottomScreen = offY + islandH / 2 + d / 2 + Common.dp(this, 4);
        island.setCutout(cx + d / 2f + Common.dp(this, 6), bottomScreen);
    }

    private void clearEvent() {
        if (pinned()) showIdle();
        else dismiss();
    }

    private void applyLook() {
        computeDims();
        if (!attached) {
            if (preview) showPreview();
            return;
        }
        if (island != null && island.isIdle()) {
            showIdle();
            return;
        }
        if (lastTitle == null) return;
        // 预览常驻：不重播入场，只把尺寸和位置平滑对齐
        island.setShape(shape);
        island.setLines(Common.clamp(Common.getI(this, Common.K_LINES, 2), 1, 4));
        island.setVisual(Common.getB(this, Common.K_COLORFUL, false),
                Common.getB(this, Common.K_HIRES, false));
        island.setLiked(liked);
        island.setPullClose(false);
        island.setHideBtn(lastKind == IslandView.KIND_MUSIC && isLandscape());
        applyCutout();
        island.setShowText(expanded);
        animateTo(winW(expanded ? expandedW : compactW),
                winH(expanded ? expandedH : islandH), yFor(expanded));
    }

    /** 设置页进入外观调节时调用：直接弹岛并常驻，调参数即时可见。 */
    private void showPreview() {
        computeDims();
        if (!Common.getB(this, Common.K_ISLAND, true)) return;
        if (!attach()) {
            Toast.makeText(this, "灵动岛需要悬浮窗权限", Toast.LENGTH_SHORT).show();
            return;
        }
        h.removeCallbacks(collapseTask);
        h.removeCallbacks(dismissTask);
        if (lastTitle == null) {
            lastKind = IslandView.KIND_NOTI;
            lastTitle = "正在预览灵动岛";
            lastSub = "点岛展开 · 拖滑杆即时生效";
            lastPkg = getPackageName();
            lastProgress = -1;
            lastAccent = 0xFF5EE7FF;
        }
        island.setShape(shape);
        island.setIdle(false);
        island.setData(lastKind, lastTitle, lastSub,
                Common.iconBitmap(this, lastPkg, Common.dp(this, 64)),
                lastProgress, lastAccent);
        expanded = false;
        island.setShowText(false);
        animateTo(winW(compactW), winH(islandH), yFor(false));
    }

    private void test() {
        preview = false;
        show(IslandView.KIND_NOTI, "灵动岛已就绪", "点我展开，再点收起", getPackageName(),
                -1, 0xFF5EE7FF, 6000, 10000);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        current = null;
        stopMic();
        h.removeCallbacksAndMessages(null);
        if (widthAnim != null) widthAnim.cancel();
        removeIsland(true);
        if (rx != null) {
            try {
                unregisterReceiver(rx);
            } catch (Exception ignored) {
            }
            rx = null;
        }
        if (controller != null && mediaCb != null) {
            try {
                controller.unregisterCallback(mediaCb);
            } catch (Exception ignored) {
            }
        }
        super.onDestroy();
    }

    private void createChannel() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL, "冰岛服务",
                NotificationManager.IMPORTANCE_MIN);
        ch.setShowBadge(false);
        ch.setSound(null, null);
        ch.enableVibration(false);
        ch.setDescription("保持灵动岛与切换动画运行");
        nm.createNotificationChannel(ch);
        NotificationChannel hc = new NotificationChannel(CHANNEL_HIDDEN, "已收起的岛",
                NotificationManager.IMPORTANCE_LOW);
        hc.setShowBadge(false);
        hc.setSound(null, null);
        hc.enableVibration(false);
        hc.setDescription("音乐岛被收起后，从这里重新打开");
        nm.createNotificationChannel(hc);
    }

    /** 收起音乐岛后留一条通知，可以从通知栏重新打开。 */
    private void postHiddenMusic(String track) {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) return;
            PendingIntent pi = PendingIntent.getService(this, 2,
                    new Intent(this, IslandService.class).setAction(Common.ACTION_RESTORE_MUSIC),
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            Notification.Builder b = new Notification.Builder(this, CHANNEL_HIDDEN)
                    .setSmallIcon(R.drawable.ic_stat)
                    .setContentTitle("音乐岛已收起")
                    .setContentText(track == null || track.length() == 0
                            ? "点一下重新显示" : track + " · 点一下重新显示")
                    .setAutoCancel(true)
                    .setShowWhen(false)
                    .setPriority(Notification.PRIORITY_LOW)
                    .setContentIntent(pi);
            nm.notify(HIDDEN_ID, b.build());
        } catch (Exception ignored) {
        }
    }

    private void cancelHiddenMusic() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.cancel(HIDDEN_ID);
        } catch (Exception ignored) {
        }
    }

    private Notification buildFg() {
        PendingIntent pi = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("冰岛正在运行")
                .setContentText("灵动岛已就绪")
                .setOngoing(true)
                .setShowWhen(false)
                .setPriority(Notification.PRIORITY_MIN)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setContentIntent(pi);
        return b.build();
    }

    // ---------------- 悬浮窗 ----------------

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : Common.dp(this, 24);
    }

    private boolean attach() {
        if (attached) return true;
        if (!Settings.canDrawOverlays(this)) return false;
        try {
            a11yWin = false;
            SihuaA11y a = SihuaA11y.instance;
            if (a != null && Common.hasA11y(this)) {
                try {
                    wm = (WindowManager) a.getSystemService(WINDOW_SERVICE);
                    a11yWin = true;
                } catch (Exception ignored) {
                    wm = (WindowManager) getSystemService(WINDOW_SERVICE);
                }
            } else {
                wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            }
            island = new IslandView(this);
            island.setLeftInset(padS + dragPad);
            island.setRightInset(padS + dragPad);
            island.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent e) {
                    if (e.getAction() == MotionEvent.ACTION_OUTSIDE && expanded) {
                        if (lastKind == IslandView.KIND_QUICK) {
                            clearQuick();
                        } else {
                            collapse();
                        }
                        return true;
                    }
                    return false;
                }
            });
            island.setActions(new IslandView.Actions() {
                @Override
                public void onIslandAction(int action) {
                    cancelRestore();
                    onMusicAction(action);
                }

                @Override
                public void onTap() {
                    cancelRestore();
                    if (lastKind == IslandView.KIND_QUICK) {
                        clearQuick();
                        return;
                    }
                    if (island != null && island.isIdle()) {
                        if (Common.getB(IslandService.this, Common.K_IDLE_CIRCLE, false)) {
                            expandFromIdle();
                        } else {
                            openQuick();
                        }
                        return;
                    }
                    if (!expanded) {
                        expand();
                    } else if (lastKind == IslandView.KIND_NOTI
                            && Common.getB(IslandService.this, Common.K_REPLY, false)) {
                        openReply();
                    } else {
                        openSource();
                    }
                }

                @Override
                public void onLong() {
                    cancelRestore();
                    onLongPress();
                }

                @Override
                public void onQuickApp(int index) {
                    hasQuickPrev = false;
                    if (index >= 0 && index < quickIndex.size()) {
                        openPkg(quickIndex.get(index));
                    }
                    clearQuick();
                }

                @Override
                public void onDragMove(int dx) {
                    dragIsland(dx);
                }

                @Override
                public void onDragEnd() {
                    endDragIsland();
                }

                @Override
                public void onPullMove(int dy) {
                    movePull(dy);
                }

                @Override
                public void onPullCancel() {
                    pullPendingHide = false;
                    cancelPull();
                }

                @Override
                public void onPullDown() {
                }

                @Override
                public void onHideIsland() {
                    hideIslandByUser();
                }

                @Override
                public void onSwipe(int dir) {
                    handleHorizontalSwipe(dir);
                }
            });
            island.setVisual(Common.getB(this, Common.K_COLORFUL, false),
                    Common.getB(this, Common.K_HIRES, false));
            island.setLiked(liked);
            lp = new WindowManager.LayoutParams(winW(compactW), winH(islandH),
                    a11yWin ? 2032 : WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                            | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            lp.y = yFor(false);
            lp.x = offX;
            island.setShape(shape);
            island.setShowText(false);
            if (Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode =
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            }
            island.setAlpha(0f);
            island.setScaleX(0.92f);
            island.setScaleY(0.92f);
            // 副岛窗口先挂上，排在主岛下层：分裂时才能从主岛下面「长」出来
            ensureSubShell();
            try {
                wm.addView(island, lp);
            } catch (Exception e) {
                if (!a11yWin) {
                    removeSubShell();
                    throw e;
                }
                // 无障碍窗口加不进去时退回普通悬浮窗
                removeSubShell();
                a11yWin = false;
                wm = (WindowManager) getSystemService(WINDOW_SERVICE);
                lp.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
                wm.addView(island, lp);
                ensureSubShell();
            }
            island.animate().alpha(1f).scaleX(1f).scaleY(1f)
                    .setDuration(220)
                    .setInterpolator(new android.view.animation.DecelerateInterpolator(1.6f))
                    .start();
            attached = true;
            expanded = false;
            return true;
        } catch (Exception e) {
            attached = false;
            return false;
        }
    }

    /**
     * 弹出：一个点 → 鼓成圆（像前摄那个点）→ 横向拉开成胶囊 / 卡片。
     * 高度和圆心在第一段里不动，所以看不到上下跳。
     */
    private void popIn(final int targetW, final int targetH, final int targetY) {
        stopDragAnims();
        if (!attached || island == null || lp == null) return;
        island.animate().cancel();
        island.setScaleX(1f);
        island.setScaleY(1f);
        final int dot = Math.max(Common.dp(this, 6), islandH / 5);
        final int startW = dot + (padS + dragPad) * 2;
        final int startH = dot + padB;
        final int circleW = winW(islandH);
        final int circleH = winH(islandH);
        final float centerY = offY + islandH / 2f;
        lp.width = startW;
        lp.height = startH;
        lp.x = offX + shiftPx;
        lp.y = Math.round(centerY - dot / 2f);
        try {
            wm.updateViewLayout(island, lp);
        } catch (Exception ignored) {
        }
        island.setContentAlpha(0f);
        if (contentAnim != null) {
            contentAnim.cancel();
            contentAnim = null;
        }
        island.setAlpha(0.3f);
        island.animate().alpha(1f).setDuration(150).start();
        final int circleY = offY;
        final int fromW = startW;
        final int fromH = startH;
        final long durA = 170;
        final long durB = 330;
        final float share = durA / (float) (durA + durB);
        final float fadeAt = Math.max(share, 0.62f);
        if (widthAnim != null) {
            android.animation.ValueAnimator old = widthAnim;
            widthAnim = null;
            old.cancel();
        }
        final boolean[] shown = {false};
        widthAnim = android.animation.ValueAnimator.ofFloat(0f, 1f);
        widthAnim.setDuration(durA + durB);
        final android.animation.ValueAnimator anim = widthAnim;
        widthAnim.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(android.animation.ValueAnimator a) {
                if (!attached || island == null || lp == null) return;
                float f = (Float) a.getAnimatedValue();
                float w;
                float hh;
                float yy;
                if (f <= share) {
                    float t = f / share;
                    float e = 1f - (1f - t) * (1f - t);
                    w = fromW + (circleW - fromW) * e;
                    hh = fromH + (circleH - fromH) * e;
                    yy = centerY - (hh - padB) / 2f;
                } else {
                    float t = (f - share) / (1f - share);
                    float e = 1f - (1f - t) * (1f - t) * (1f - t);
                    w = circleW + (targetW - circleW) * e;
                    hh = circleH + (targetH - circleH) * e;
                    yy = circleY + (targetY - circleY) * e;
                }
                lp.width = Math.round(w);
                lp.height = Math.round(hh);
                lp.y = Math.round(yy);
                try {
                    wm.updateViewLayout(island, lp);
                } catch (Exception ignored) {
                }
                if (!shown[0] && f > fadeAt) {
                    shown[0] = true;
                    float left = (1f - f) / (1f - fadeAt);
                    fadeContent(1f, (long) Math.max(60, 320 * left), 0);
                }
            }
        });
        widthAnim.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator a) {
                if (anim != widthAnim) return;
                widthAnim = null;
                if (island != null) island.setContentAlpha(1f);
            }
        });
        widthAnim.start();
    }

    /** 卡片内容自身淡入淡出，尺寸变化时不会整块文字瞬间消失。 */
    private void fadeSubContent(float to, long durMs, long delayMs) {
        if (sub == null) return;
        final android.animation.ValueAnimator anim =
                android.animation.ValueAnimator.ofFloat(sub.getContentAlpha(), to);
        anim.setDuration(durMs);
        anim.setStartDelay(delayMs);
        anim.setInterpolator(new android.view.animation.DecelerateInterpolator(1.5f));
        anim.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(android.animation.ValueAnimator a) {
                if (sub != null) sub.setContentAlpha((Float) a.getAnimatedValue());
            }
        });
        anim.start();
    }

    private void fadeContent(float to, long durMs, long delayMs) {
        if (island == null) return;
        if (contentAnim != null) contentAnim.cancel();
        final IslandView v = island;
        contentAnim = android.animation.ValueAnimator.ofFloat(v.getContentAlpha(), to);
        contentAnim.setDuration(durMs);
        contentAnim.setStartDelay(delayMs);
        contentAnim.setInterpolator(new android.view.animation.DecelerateInterpolator(1.5f));
        contentAnim.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(android.animation.ValueAnimator a) {
                if (v == island) v.setContentAlpha((Float) a.getAnimatedValue());
            }
        });
        contentAnim.start();
    }

    /** 无障碍开关变化后重挂窗口（无障碍窗口能盖住状态栏）。 */
    void reconnect() {
        boolean want = SihuaA11y.instance != null && Common.hasA11y(this)
                && Common.getB(this, Common.K_ISLAND, true);
        if (attached && want != a11yWin) {
            removeSub(false);
            removeIsland(true);
            if (preview) {
                showPreview();
            } else if (pinned()) {
                showIdle();
            } else if (lastKind == IslandView.KIND_MUSIC && playingState()) {
                updateMusic();
            }
        } else if (!attached && want && preview) {
            showPreview();
        }
    }

    private int cardHeight() {
        if (lastKind == IslandView.KIND_MUSIC) return musicH;
        if (lastKind == IslandView.KIND_QUICK) return quickCardH(quickIndex.size());
        return expandedH;
    }

    /** 圆形常驻岛点一下：展开成普通卡片，没操作再缩回圆。 */
    private void expandFromIdle() {
        if (!attached || island == null) return;
        lastKind = IslandView.KIND_NOTI;
        lastTitle = "冰岛";
        lastSub = "点空白处收起 · 无操作自动缩小";
        lastPkg = getPackageName();
        lastProgress = -1;
        lastAccent = 0xFF5EE7FF;
        island.setIdle(false);
        island.setIdleCircle(0);
        island.setData(IslandView.KIND_NOTI, lastTitle, lastSub,
                Common.iconBitmap(this, getPackageName(), Common.dp(this, 64)), -1, lastAccent);
        island.setPullClose(false);
        idleExpanded = true;
        expand();
        h.removeCallbacks(collapseTask);
        collapseTask = new Runnable() {
            @Override
            public void run() {
                if (island == null || !expanded) return;
                if (pinned()) showIdle();
                else dismiss();
            }
        };
        h.postDelayed(collapseTask, stayMs());
    }

    private void expand() {
        idleExtraX = 0;
        h.removeCallbacks(collapseTask);
        cancelBridgeAnim();
        if (sub != null) sub.setBridge(0f, 0f, 0f, 0f);
        if (island != null) island.setStrokeHole(0);
        shiftMain(0, 320);
        expanded = true;
        int hh = cardHeight();
        // 展开时副岛直接消失，位置一点不动；收起时再原地淡回来
        hideSubInstant();
        shapeTo(winW(expandedW), winH(hh), yFor(true), true);
    }

    private void collapse() {
        h.removeCallbacks(collapseTask);
        // 已经收起：什么都不做，否则每次回调都会重放一遍淡入淡出，看着像在闪
        if (!expanded) return;
        expanded = false;
        if (idleExpanded) {
            idleExpanded = false;
            showIdle();
            return;
        }
        shapeTo(winW(compactW), winH(islandH), yFor(false), false);
    }

    private static float easeOut(float t) {
        t = Math.max(0f, Math.min(1f, t));
        float u = 1f - t;
        return 1f - u * u * u;
    }

    private static float easeInOut(float t) {
        t = Math.max(0f, Math.min(1f, t));
        return t < 0.5f ? 4f * t * t * t : 1f - (float) Math.pow(-2f * t + 2f, 3) / 2f;
    }

    /**
     * 展开：先收内容，再「先横向拉长、再向下长高」，最后文字淡入；
     * 收起反过来：先收高度，再收长度。整段由一个 ValueAnimator 驱动窗口尺寸。
     */
    private void shapeTo(final int targetW, final int targetH, final int targetY,
                         final boolean expanding) {
        if (!attached || island == null || lp == null) {
            animateTo(targetW, targetH, targetY);
            return;
        }
        if (contentAnim != null) {
            contentAnim.cancel();
            contentAnim = null;
        }
        if (expanding) {
            island.setShowText(true);
            fadeContent(0f, 90, 0);
        } else {
            fadeContent(0f, 110, 0);
        }
        if (widthAnim != null) {
            android.animation.ValueAnimator old = widthAnim;
            widthAnim = null;
            old.cancel();
        }
        final int fromW = lp.width, fromH = lp.height, fromX = lp.x, fromY = lp.y;
        int expMs = Common.clamp(Common.getI(this, Common.K_EXPAND_MS, 520), 200, 1200);
        final long dur = expanding ? expMs : Math.max(200, (long) (expMs * 0.72f));
        final boolean[] shown = {false};
        final android.animation.ValueAnimator anim =
                android.animation.ValueAnimator.ofFloat(0f, 1f);
        widthAnim = anim;
        anim.setDuration(dur);
        if (expanding) anim.setStartDelay(70);
        anim.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(android.animation.ValueAnimator a) {
                if (!attached || island == null || lp == null) return;
                float f = (Float) a.getAnimatedValue();
                float wp;
                float hp;
                if (expanding) {
                    wp = easeOut(f / 0.62f);
                    hp = easeOut((f - 0.28f) / 0.72f);
                } else {
                    hp = easeInOut(f / 0.62f);
                    wp = easeOut((f - 0.38f) / 0.62f);
                }
                lp.width = (int) (fromW + (targetW - fromW) * wp);
                lp.height = (int) (fromH + (targetH - fromH) * hp);
                lp.y = (int) (fromY + (targetY - fromY) * hp);
                lp.x = (int) (fromX + (offX + shiftPx + idleExtraX - fromX) * wp);
                try {
                    wm.updateViewLayout(island, lp);
                } catch (Exception ignored) {
                }
                if (!shown[0] && f > (expanding ? 0.55f : 0.70f)) {
                    shown[0] = true;
                    if (!expanding) island.setShowText(false);
                    fadeContent(1f, expanding ? 230 : 170, 0);
                }
            }
        });
        anim.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator a) {
                if (anim != widthAnim) return;
                widthAnim = null;
                if (island != null) {
                    if (!expanding) {
                        island.setShowText(false);
                        island.setContentAlpha(1f);
                    } else if (!shown[0]) {
                        island.setContentAlpha(1f);
                    }
                }
                if (!expanding) revealSub();
            }
        });
        anim.start();
    }

    /** 副岛整体淡入淡出（收起 / 展开时用）。 */
    private void fadeSub(float to, long dur) {
        if (!subAttached || sub == null) return;
        dropSubAnim();
        final IslandView v = sub;
        subAnim = android.animation.ValueAnimator.ofFloat(
                to > 0.5f ? 0f : v.getAlpha(), to);
        subAnim.setDuration(dur);
        subAnim.setInterpolator(new android.view.animation.DecelerateInterpolator(1.2f));
        subAnim.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(android.animation.ValueAnimator a) {
                if (v != sub) return;
                float f = (Float) a.getAnimatedValue();
                v.setAlpha(f);
                v.setContentAlpha(f);
            }
        });
        subAnim.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator a) {
                if (subAnimCanceling) return;
                subAnim = null;
                if (v == sub) {
                    v.setAlpha(to);
                    v.setContentAlpha(to);
                    if (subLp != null) {
                        if (to > 0.5f) {
                            subLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
                        } else {
                            subLp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
                        }
                        try {
                            wm.updateViewLayout(sub, subLp);
                        } catch (Exception ignored) {
                        }
                    }
                }
            }
        });
        subAnim.start();
    }

    /** 收起后副岛在原地淡回来，不挪位置。 */
    private void revealSub() {
        if (!subWasShown || sub == null || subLp == null) return;
        subWasShown = false;
        sub.setAlpha(0f);
        sub.setContentAlpha(0f);
        sub.setScaleX(1f);
        sub.setScaleY(1f);
        // 展开期间主岛宽度变了，露出来之前先贴回它旁边，避免和主岛重叠
        subPillLeft = subPillTarget();
        subLp.y = offY;
        subWindow(false);
        fadeSub(1f, 220);
    }

    /** 展开时副岛立刻隐掉，窗口和位置都保持原样。 */
    private void hideSubInstant() {
        subWasShown = subAttached && sub != null && sub.getAlpha() > 0.05f;
        subAttached = false;
        dropSubAnim();
        if (sub == null || subLp == null) return;
        sub.setAlpha(0f);
        sub.setContentAlpha(1f);
        if (island != null) island.setStrokeHole(0);
        subLp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        try {
            wm.updateViewLayout(sub, subLp);
        } catch (Exception ignored) {
        }
    }

    /** 设置里选的快捷应用（逗号分隔，兼容早期只有一个的写法）。 */
    private java.util.List<String> quickPkgs() {
        java.util.List<String> out = new java.util.ArrayList<String>();
        String raw = Common.getS(this, Common.K_QUICK_PKG, "");
        if (raw == null) return out;
        for (String p : raw.split(",")) {
            String t = p.trim();
            if (t.length() > 0 && !out.contains(t)) out.add(t);
        }
        return out;
    }

    /** 常驻岛单击：一个直接打开，多个展开岛里选。 */
    private void openQuick() {
        java.util.List<String> list = quickPkgs();
        if (list.isEmpty()) {
            Toast.makeText(this, "在设置里选一个快捷应用", Toast.LENGTH_SHORT).show();
            return;
        }
        if (list.size() == 1) {
            openPkg(list.get(0));
            return;
        }
        showQuickChooser(list);
    }

    private void openPkg(String pkg) {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) {
                Toast.makeText(this, "这个应用打不开", Toast.LENGTH_SHORT).show();
                return;
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "打开失败", Toast.LENGTH_SHORT).show();
        }
    }

    /** 多个快捷应用：把岛展开成一排图标来选。 */
    private void showQuickChooser(java.util.List<String> list) {
        if (!Common.getB(this, Common.K_ISLAND, true)) return;
        if (!attach()) return;
        quickIndex.clear();
        java.util.List<IslandView.QuickApp> apps = new java.util.ArrayList<IslandView.QuickApp>();
        android.content.pm.PackageManager pm = getPackageManager();
        boolean qHide = isLandscape();
        for (String p : list) {
            if (apps.size() >= (qHide ? 9 : 10)) break;
            IslandView.QuickApp q = new IslandView.QuickApp();
            q.pkg = p;
            try {
                q.label = String.valueOf(pm.getApplicationLabel(pm.getApplicationInfo(p, 0)));
            } catch (Exception e) {
                continue;
            }
            q.icon = Common.iconBitmap(this, p, Common.dp(this, 64));
            apps.add(q);
            quickIndex.add(p);
        }
        if (apps.isEmpty()) {
            Toast.makeText(this, "快捷应用都不可用了", Toast.LENGTH_SHORT).show();
            return;
        }
        if (lastKind != IslandView.KIND_QUICK && lastTitle != null) {
            hasQuickPrev = true;
            quickPrevKind = lastKind;
            quickPrevTitle = lastTitle;
            quickPrevSub = lastSub;
            quickPrevPkg = lastPkg;
            quickPrevProgress = lastProgress;
            quickPrevAccent = lastAccent;
        }
        island.setQuickApps(apps.toArray(new IslandView.QuickApp[0]));
        island.setQuickHide(qHide);
        island.setData(IslandView.KIND_QUICK, "快捷打开", "点图标打开应用", null, -1, 0xFF5EE7FF);
        island.setShape(shape);
        island.setIdle(false);
        island.setShowText(true);
        island.setContentAlpha(1f);
        expanded = true;
        cancelRestore();
        int qh = quickCardH(apps.size());
        animateTo(winW(expandedW), winH(qh), yFor(true), 300, null);
        lastKind = IslandView.KIND_QUICK;
        lastTitle = "快捷打开";
        lastSub = "点图标打开应用";
        lastPkg = null;
        lastProgress = -1;
        lastAccent = 0xFF5EE7FF;
        h.removeCallbacks(collapseTask);
        h.removeCallbacks(dismissTask);
        collapseTask = new Runnable() {
            @Override
            public void run() {
                clearQuick();
            }
        };
        h.postDelayed(collapseTask, 7000);
    }

    private int quickCardH(int n) {
        if (n <= 5) return Math.max(expandedH, Common.dp(this, 96));
        return Math.max(musicH, Common.dp(this, 168));
    }

    private void clearQuick() {
        h.removeCallbacks(collapseTask);
        if (lastKind == IslandView.KIND_QUICK) {
            lastKind = IslandView.KIND_NOTI;
            lastTitle = null;
        }
        if (island != null) {
            island.setQuickApps(null);
            island.setQuickHide(false);
        }
        if (hasQuickPrev) {
            hasQuickPrev = false;
            show(quickPrevKind, quickPrevTitle, quickPrevSub, quickPrevPkg,
                    quickPrevProgress, quickPrevAccent, stayMs() + 800, stayMs());
            return;
        }
        if (pinned()) showIdle();
        else dismiss();
    }

    /** 有事件时长按：按设置执行快捷应用 / 隐藏岛 / 截图。 */
    private void onLongPress() {
        int act = Common.getI(this, Common.K_LONG, 0);
        if (act == 1) {
            hiddenByUser = true;
            removeIsland(false);
            return;
        }
        if (act == 2) {
            boolean ok = false;
            SihuaA11y a = SihuaA11y.instance;
            if (a != null && Build.VERSION.SDK_INT >= 28) {
                try {
                    ok = a.performGlobalAction(9);
                } catch (Exception ignored) {
                }
            }
            if (!ok) Toast.makeText(this, "要在设置里开启无障碍才能截图", Toast.LENGTH_SHORT).show();
            return;
        }
        openQuick();
    }

    private void openSource() {
        final String pkg = lastPkg == null ? getPackageName() : lastPkg;
        collapse();
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(this, MainActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Exception ignored) {
            }
        }
    }

    private int yFor(boolean exp) {
        // 收起 / 展开都用用户设定的顶部距离，展开不再强制避开状态栏
        return offY;
    }

    /** 消息 / 系统事件停留时长（3–60 秒），音乐与下载不自动消失。 */
    private long stayMs() {
        return Common.clamp(Common.getI(this, Common.K_TAU, 5), 3, 60) * 1000L;
    }

    private void animateTo(final int targetW, final int targetH, final int targetY) {
        animateTo(targetW, targetH, targetY, 300, null);
    }

    private void animateTo(final int targetW, final int targetH, final int targetY,
                           long durationMs, final Runnable end) {
        if (!attached || lp == null) return;
        if (widthAnim != null) {
            android.animation.ValueAnimator old = widthAnim;
            widthAnim = null;
            old.cancel();
        }
        dragWinX = 0;
        pullPendingHide = false;
        final int fromW = lp.width, fromH = lp.height, fromY = lp.y;
        final int fromX = lp.x;
        widthAnim = android.animation.ValueAnimator.ofFloat(0f, 1f);
        widthAnim.setDuration(durationMs);
        widthAnim.setInterpolator(new android.view.animation.PathInterpolator(0.22f, 0f, 0f, 1f));
        final android.animation.ValueAnimator anim = widthAnim;
        if (island != null) island.setShadow(false);
        anim.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator a) {
                if (anim != widthAnim) return;
                if (island != null) island.setShadow(true);
                if (end != null) end.run();
            }
        });
        widthAnim.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(android.animation.ValueAnimator a) {
                if (!attached) return;
                float f = (Float) a.getAnimatedValue();
                lp.width = (int) (fromW + (targetW - fromW) * f);
                lp.height = (int) (fromH + (targetH - fromH) * f);
                lp.y = (int) (fromY + (targetY - fromY) * f);
                lp.x = (int) (fromX + (offX + shiftPx + idleExtraX - fromX) * f);
                try {
                    wm.updateViewLayout(island, lp);
                } catch (Exception ignored) {
                }
            }
        });
        widthAnim.start();
    }

    private void removeIsland(boolean instant) {
        h.removeCallbacks(collapseTask);
        h.removeCallbacks(dismissTask);
        removeSub(false);
        removeSubShell();
        if (island != null && attached) {
            final IslandView v = island;
            attached = false;
            island = null;
            try {
                if (instant) {
                    wm.removeView(v);
                } else {
                    v.animate().alpha(0f).scaleX(0.8f).scaleY(0.8f).setDuration(180)
                            .withEndAction(new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        wm.removeView(v);
                                    } catch (Exception ignored) {
                                    }
                                }
                            }).start();
                }
            } catch (Exception ignored) {
            }
        }
    }

    /**
     * 消失：先把长度收到和高度一样（变成圆），圆再缩小淡出。
     * 起点固定是收起后的胶囊，所以两段动画衔接自然。
     */
    private void dismiss() {
        if (pinned()) {
            showIdle();
            return;
        }
        h.removeCallbacks(collapseTask);
        h.removeCallbacks(dismissTask);
        if (island == null || !attached || dismissing) {
            restoreMusicSoon();
            return;
        }
        dismissing = true;
        expanded = false;
        removeSub(true);
        final IslandView v = island;
        long dur = Common.clamp(Common.getI(this, Common.K_DISMISS_MS, 520), 200, 1000);
        fadeContent(0f, (long) (dur * 0.4f), 0);
        animateTo(winW(islandH), winH(islandH), yFor(false), (long) (dur * 0.56f), new Runnable() {
            @Override
            public void run() {
                if (!attached || v != island) {
                    dismissing = false;
                    return;
                }
                v.setShowText(false);
                v.setPivotX(v.getWidth() / 2f);
                v.setPivotY((v.getHeight() - padB) / 2f);
                v.animate().scaleX(0.22f).scaleY(0.22f).alpha(0f)
                        .setDuration((long) (dur * 0.44f))
                        .setInterpolator(new android.view.animation.AccelerateInterpolator(1.9f))
                        .withEndAction(new Runnable() {
                            @Override
                            public void run() {
                                attached = false;
                                if (island == v) island = null;
                                dismissing = false;
                                try {
                                    wm.removeView(v);
                                } catch (Exception ignored) {
                                }
                                restoreMusicSoon();
                            }
                        }).start();
            }
        });
    }

    // ---------------- 展示 ----------------

    private void show(int kind, String title, String sub, String pkg, int progress,
                      int accent, long collapseMs, long dismissMs) {
        show(kind, title, sub, pkg, null, progress, accent, collapseMs, dismissMs);
    }

    private void show(int kind, String title, String sub, String pkg, Bitmap art, int progress,
                      int accent, long collapseMs, long dismissMs) {
        if (!Common.getB(this, Common.K_ISLAND, true)) return;
        if (fgSuppressed && pkg != null && pkg.equals(fgPkg)) {
            saveKind = kind;
            saveTitle = title;
            saveSub = sub;
            savePkg = pkg;
            saveProgress = progress;
            saveAccent = accent;
            return;
        }
        boolean fresh = !attached;
        if (!attach()) {
            Toast.makeText(this, "灵动岛需要悬浮窗权限", Toast.LENGTH_SHORT).show();
            return;
        }
        if (dismissing) {
            dismissing = false;
            try {
                island.animate().cancel();
                island.setScaleX(1f);
                island.setScaleY(1f);
                island.setAlpha(1f);
            } catch (Exception ignored) {
            }
        }
        hiddenByUser = false;
        idleExpanded = false;
        if (island != null) island.setAlpha(1f);
        idleExtraX = 0;
        lastKind = kind;
        lastTitle = title;
        lastSub = sub;
        lastPkg = pkg;
        lastProgress = progress;
        lastAccent = accent;
        if (kind != IslandView.KIND_MUSIC) lastArtSig = 0;
        island.setShape(shape);
        island.setLines(Common.clamp(Common.getI(this, Common.K_LINES, 2), 1, 4));
        island.setIdle(false);
        island.setIdleCircle(0);
        Bitmap ic = art != null ? art : Common.iconBitmap(this, pkg, Common.dp(this, 64));
        island.setContentAlpha(1f);
        island.setData(kind, title, sub, ic, progress, accent);
        island.setVisual(Common.getB(this, Common.K_COLORFUL, false),
                Common.getB(this, Common.K_HIRES, false));
        island.setLiked(liked);
        island.setPullClose(false);
        island.setHideBtn(kind == IslandView.KIND_MUSIC && isLandscape());
        applyCutout();
        if (kind == IslandView.KIND_MUSIC) island.setPlaying(playingState());
        // 音乐、下载都按「缩小窗」弹出；点一下才展开成大卡片
        boolean big = Common.getI(this, Common.K_POPUP, 1) == 1
                && kind != IslandView.KIND_MUSIC && kind != IslandView.KIND_DOWNLOAD;
        expanded = big;
        island.setShowText(big);
        final int targetW = winW(big ? expandedW : compactW);
        final int targetH = winH(big
                ? (kind == IslandView.KIND_MUSIC ? musicH : expandedH) : islandH);
        final int targetY = yFor(big);
        if (fresh) {
            // 刚从屏幕顶部「长」出来：点 → 圆 → 拉开
            popIn(targetW, targetH, targetY);
        } else {
            animateTo(targetW, targetH, targetY);
        }
        h.removeCallbacks(collapseTask);
        h.removeCallbacks(dismissTask);
        collapseTask = new Runnable() {
            @Override
            public void run() {
                collapse();
            }
        };
        if (collapseMs > 0) h.postDelayed(collapseTask, collapseMs);
        if (dismissMs > 0) {
            dismissTask = new Runnable() {
                @Override
                public void run() {
                    dismiss();
                }
            };
            h.postDelayed(dismissTask, dismissMs);
        }
    }

    private void restoreMusicSoon() {
        PlaybackState ps = controller != null ? controller.getPlaybackState() : null;
        if (ps != null && ps.getState() == PlaybackState.STATE_PLAYING
                && Common.getB(this, Common.K_MUSIC, true)) {
            h.postDelayed(new Runnable() {
                @Override
                public void run() {
                    updateMusic();
                }
            }, 900);
        }
    }

    // ---------------- 通知 ----------------

    /** 锁屏时宁可什么都不显示，也不要把验证码之类的内容亮在锁屏上。 */
    private boolean lockedNow() {
        try {
            android.app.KeyguardManager km = (android.app.KeyguardManager)
                    getSystemService(KEYGUARD_SERVICE);
            return km != null && km.isKeyguardLocked();
        } catch (Exception e) {
            return false;
        }
    }

    void pushNotification(String pkg, String title, String text, int progress) {
        if (pkg == null) return;
        if (lockedNow()) return;
        preview = false;
        if (progress >= 0) {
            if (!Common.getB(this, Common.K_DL, true)) return;
            // 同一下载：原地刷进度，不再重播展开动画
            if (attached && island != null && lastKind == IslandView.KIND_DOWNLOAD) {
                lastTitle = title;
                lastSub = text;
                lastPkg = pkg;
                lastProgress = progress;
                lastAccent = 0xFF38D98A;
                island.setData(IslandView.KIND_DOWNLOAD, title, text, subIcon(pkg),
                        progress, 0xFF38D98A);
                return;
            }
            if (subAttached && subKind == IslandView.KIND_DOWNLOAD) {
                subTitle = title;
                subSub = text;
                subProgress = progress;
                if (sub != null) {
                    sub.setData(IslandView.KIND_DOWNLOAD, title, text, subIcon(pkg),
                            progress, 0xFF38D98A);
                }
                return;
            }
            if (multiOn() && attached && lastKind == IslandView.KIND_MUSIC) {
                showSub(IslandView.KIND_DOWNLOAD, title, text, pkg, progress,
                        0xFF38D98A, progress >= 100 ? 3000 : 0);
                return;
            }
            show(IslandView.KIND_DOWNLOAD, title, text, pkg, progress, 0xFF38D98A, 3200, 0);
        } else {
            if (!Common.getB(this, Common.K_NOTI, true)) return;
            // 只在前台的应用，不打扰
            if (Common.getB(this, Common.K_FG_HIDE, false)
                    && pkg.equals(SihuaA11y.foreground)) return;
            long total = stayMs();
            // 收起模式下的连发消息：新消息顶上来，旧消息挪到副岛
            if (Common.getI(this, Common.K_POPUP, 1) == 0 && attached && island != null
                    && lastKind == IslandView.KIND_NOTI && lastTitle != null
                    && !title.equals(lastTitle)) {
                showSub(IslandView.KIND_NOTI, lastTitle, lastSub, lastPkg, lastProgress,
                        lastAccent, total + 800);
            }
            if (multiOn() && attached && lastKind == IslandView.KIND_MUSIC) {
                showSub(IslandView.KIND_NOTI, title, text, pkg, -1, 0xFF5EE7FF,
                        total + 800);
                return;
            }
            show(IslandView.KIND_NOTI, title, text, pkg, -1, 0xFF5EE7FF,
                    total + 800, total);
        }
    }

    // ---------------- 副岛（多岛 / 细胞分裂） ----------------

    private boolean multiOn() {
        return Common.getB(this, Common.K_MULTI, true);
    }

    /** 常驻：手动开了常驻，或者开了圆形常驻岛，都算常驻。 */
    private boolean pinned() {
        return Common.getB(this, Common.K_PIN, false)
                || Common.getB(this, Common.K_IDLE_CIRCLE, false);
    }

    private Bitmap subIcon(String pkg) {
        return Common.iconBitmap(this, pkg, Common.dp(this, 64));
    }

    private int subContent() {
        // 与主岛同高：分裂出来才像同一个形状被拉开
        return islandH;
    }

    private int subW() {
        return subContent() + padS * 2;
    }

    private int subH() {
        return subContent() + padB;
    }

    private int mainCenterX() {
        int sw = getResources().getDisplayMetrics().widthPixels;
        return sw / 2 + (lp != null ? lp.x : offX);
    }

    private int mainWNow() {
        return lp != null ? lp.width : winW(compactW);
    }

    /** 主岛位移的目标值：副岛定位要按主岛最终位置算，才不会差一截。 */
    private int mainShiftForLayout() {
        return shiftAnim != null ? shiftGoal : shiftPx;
    }

    /** 主岛窗口左边（含透明内边距）。 */
    private int mainLeftNow() {
        int sw = getResources().getDisplayMetrics().widthPixels;
        return (sw - mainWNow()) / 2 + offX + shiftPx;
    }

    private int mainRightNow() {
        return mainLeftNow() + mainWNow();
    }

    /** 主岛黑色胶囊的左右边缘。 */
    private int mainPillLeft() {
        return mainLeftNow() + padS + dragPad;
    }

    private int mainPillRight() {
        return mainRightNow() - padS - dragPad;
    }

    private int subSide() {
        return Common.getI(this, Common.K_MULTI_SIDE, 0);
    }

    /** 副岛展开后从主岛卡片下面探出来一点，层级在下，不挡卡片。 */
    private int subY() {
        if (expanded) {
            // 完全藏到展开岛后面：图层在下，被卡片整个盖住
            int hh = lastKind == IslandView.KIND_MUSIC ? musicH : expandedH;
            return offY + (hh - subH()) / 2;
        }
        return offY;
    }

    /** 副岛一侧出现时，主岛往反方向让出的距离。 */
    private int subShift() {
        return subSide() == 1 ? Common.dp(this, 6) : -Common.dp(this, 6);
    }

    private int subTargetX() {
        int gap = Common.dp(this, 8);
        if (expanded) return mainCenterX() - subW() / 2;
        if (subSide() == 1) return mainPillLeft() - gap - subContent() - padS;
        return mainPillRight() + gap - padS;
    }

    /** 副岛完全藏在主岛胶囊里的位置。 */
    private int subHiddenX() {
        if (subSide() == 1) return mainPillLeft() + Common.dp(this, 2) - padS;
        return mainPillRight() - subContent() - Common.dp(this, 2) - padS;
    }

    /** 窗口一次摆好覆盖整段行程：之后每帧只改视图内部，不再重排窗口，副岛运动不卡。 */
    private void subWindow(boolean travel) {
        if (!attached || sub == null || subLp == null) return;
        int m = Common.dp(this, 10);
        subLp.height = subH();
        if (travel) {
            int h = subPillHidden();
            int t = subPillTarget();
            int left = Math.min(h, t) - padS - m;
            int right = Math.max(h, t) + islandH + padS + m;
            subLp.x = left;
            subLp.width = Math.max(1, right - left);
            subWide = true;
        } else {
            int touch = Common.dp(this, 8);
            subLp.x = subPillLeft - padS - touch;
            subLp.width = islandH + padS * 2 + touch * 2;
            subWide = false;
            subInset = padS + touch;
            sub.setLeftInset(padS + touch);
            sub.setRightInset(padS + touch);
            sub.setBridge(0f, 0f, 0f, 0f);
        }
        subTravelLeft = subLp.x;
        try {
            wm.updateViewLayout(sub, subLp);
        } catch (Exception ignored) {
        }
    }

    /** 只改副岛视图内部（胶囊位置 / 桥），窗口不动。 */
    private void subRender(boolean bridged) {
        if (sub == null) return;
        int inset = Math.max(padS, subPillLeft - subTravelLeft);
        subInset = inset;
        sub.setLeftInset(inset);
        boolean linking = bridged && subPillLeft > mainPillRight() + Common.dp(this, 1);
        if (linking) {
            sub.setBridge(inset + Common.dp(this, 5), 0.58f, 0.34f, 1f);
        } else {
            sub.setBridge(0f, 0f, 0f, 0f);
        }
        if (island != null) island.setStrokeHole(linking ? (subSide() == 1 ? 1 : 2) : 0);
    }

    private void cancelBridgeAnim() {
        if (bridgeAnim != null) {
            android.animation.ValueAnimator old = bridgeAnim;
            bridgeAnim = null;
            old.cancel();
        }
    }

    /** 分裂完成后桥继续收细、淡出，最后收成不带桥的小窗。 */
    private void bridgeDissolve() {
        if (sub == null || subLp == null) return;
        cancelBridgeAnim();
        final int extra = subPillLeft - subLp.x + Common.dp(this, 5);
        final android.animation.ValueAnimator anim =
                android.animation.ValueAnimator.ofFloat(0f, 1f);
        bridgeAnim = anim;
        anim.setDuration(280);
        anim.setInterpolator(new android.view.animation.PathInterpolator(0.3f, 0f, 0.3f, 1f));
        anim.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(android.animation.ValueAnimator a) {
                if (sub == null) return;
                float f = (Float) a.getAnimatedValue();
                float k = 1f - f;
                sub.setBridge(extra, 0.58f * k + 0.02f, 0.34f * k + 0.02f, 1f - f * 0.9f);
            }
        });
        anim.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator a) {
                if (anim != bridgeAnim) return;
                bridgeAnim = null;
                if (sub != null) sub.setBridge(0f, 0f, 0f, 0f);
                if (island != null) island.setStrokeHole(0);
            }
        });
        anim.start();
    }

    private int subPillTarget() {
        if (expanded) return mainCenterX() - islandH / 2;
        int gap = Common.dp(this, isLandscape() ? 16 : 8);
        int sw = getResources().getDisplayMetrics().widthPixels;
        int p;
        if (subSide() == 1) {
            p = mainPillLeft() - gap - islandH;
            p = Math.max(padS, p);
        } else {
            p = mainPillRight() + gap;
            p = Math.min(p, sw - islandH - padS);
        }
        return p;
    }

    /** 副岛藏在主岛里面的位置（胶囊左边）。 */
    private int subPillHidden() {
        if (subSide() == 1) return mainPillLeft() + Common.dp(this, 2);
        return mainPillRight() - islandH - Common.dp(this, 2);
    }

    /** 副岛窗口常驻在主岛下面（透明、不可点），分裂时才从主岛底下长出来。 */
    private boolean ensureSubShell() {
        if (subShell && sub != null && subLp != null) return true;
        if (wm == null) return false;
        if (sub == null) {
            sub = new IslandView(this);
            sub.setShape(0);
            sub.setShowText(false);
            sub.setVisual(Common.getB(this, Common.K_COLORFUL, false), false);
            sub.setActions(new IslandView.Actions() {
                @Override
                public void onIslandAction(int action) {
                }

                @Override
                public void onTap() {
                    promoteSub();
                }

                @Override
                public void onSwipe(int dir) {
                    removeSub(true);
                }

                @Override
                public void onLong() {
                    promoteSub();
                }

                @Override
                public void onQuickApp(int index) {
                }

                @Override
                public void onPullDown() {
                }

                @Override
                public void onDragMove(int dx) {
                }

                @Override
                public void onDragEnd() {
                }

                @Override
                public void onPullMove(int dy) {
                }

                @Override
                public void onPullCancel() {
                }

                @Override
                public void onHideIsland() {
                }
            });
        }
        sub.setAlpha(0f);
        sub.setScaleX(1f);
        sub.setScaleY(1f);
        sub.setContentAlpha(1f);
        sub.setLeftInset(padS);
        sub.setRightInset(padS);
        sub.setBridge(0f, 0f, 0f, 0f);
        subLp = new WindowManager.LayoutParams(1, 1,
                a11yWin ? 2032 : WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        subLp.gravity = Gravity.TOP | Gravity.LEFT;
        subLp.y = offY;
        subLp.x = mainCenterX();
        if (Build.VERSION.SDK_INT >= 28) {
            subLp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        try {
            wm.addView(sub, subLp);
            subShell = true;
        } catch (Exception e) {
            subLp = null;
            subShell = false;
        }
        return subShell;
    }

    private void removeSubShell() {
        if (sub != null && subShell) {
            try {
                wm.removeView(sub);
            } catch (Exception ignored) {
            }
        }
        sub = null;
        subLp = null;
        subShell = false;
        subAttached = false;
    }

    /** 副岛有内容：可以点。 */
    private boolean attachSub() {
        if (!attached) return false;
        if (!ensureSubShell()) return false;
        subLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        sub.setAlpha(1f);
        sub.setScaleX(1f);
        sub.setScaleY(1f);
        subAttached = true;
        return true;
    }

    /** 副岛收掉：窗口留着，缩成 1px 藏到主岛下面。 */
    private void hideSubShell() {
        subAttached = false;
        if (island != null) island.setStrokeHole(0);
        if (sub == null || subLp == null) return;
        sub.setAlpha(0f);
        sub.setScaleX(1f);
        sub.setScaleY(1f);
        sub.setContentAlpha(1f);
        sub.setLeftInset(padS);
        sub.setRightInset(padS);
        sub.setBridge(0f, 0f, 0f, 0f);
        subWide = false;
        subLp.width = 1;
        subLp.height = 1;
        subLp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        try {
            wm.updateViewLayout(sub, subLp);
        } catch (Exception ignored) {
        }
    }

    /** 主事件在显示时来新事件：从主岛底下抽出来，中间连着一条液态桥。 */
    private void showSub(int kind, String title, String text, String pkg, int progress,
                         int accent, long stay) {
        if (!attached) return;
        computeDims();
        subKind = kind;
        subTitle = title;
        subSub = text;
        subPkg = pkg;
        subAccent = accent;
        subProgress = progress;
        if (!subAttached || sub == null) {
            if (!attachSub()) return;
        }
        sub.setData(kind, title, text, subIcon(pkg), progress, accent);
        sub.setIdle(false);
        sub.setShowText(false);
        sub.setContentAlpha(0f);
        sub.setAlpha(1f);
        sub.setScaleX(1f);
        sub.setScaleY(1f);
        dropSubAnim();
        cancelBridgeAnim();
        h.removeCallbacks(subTask);
        subTask = null;

        // 副岛直接落在最终位置：整段只做淡入和轻微放大，窗口不动，才不会「到位后又瞬移」
        final int basePill = subPillTarget();
        subPillLeft = basePill;
        subWasShown = false;
        subLp.y = offY;
        subWindow(false);
        sub.setContentAlpha(0f);
        sub.setAlpha(0f);
        sub.setPivotX(islandH / 2f + padS);
        sub.setPivotY(subH() / 2f);
        sub.setScaleX(0.92f);
        sub.setScaleY(0.92f);
        subAnim = android.animation.ValueAnimator.ofFloat(0f, 1f);
        subAnim.setDuration(260);
        subAnim.setInterpolator(new android.view.animation.PathInterpolator(0.2f, 0f, 0.2f, 1f));
        subAnim.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(android.animation.ValueAnimator a) {
                if (sub == null) return;
                float f = (Float) a.getAnimatedValue();
                float sc = 0.92f + 0.08f * f;
                sub.setScaleX(sc);
                sub.setScaleY(sc);
                sub.setAlpha(f);
                sub.setContentAlpha(f);
            }
        });
        subAnim.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator a) {
                if (subAnimCanceling) return;
                subAnim = null;
                if (sub != null) {
                    sub.setScaleX(1f);
                    sub.setScaleY(1f);
                    sub.setAlpha(1f);
                    sub.setContentAlpha(1f);
                }
            }
        });
        subAnim.start();

        if (expanded) {
            subWasShown = true;
            hideSubInstant();
            subWasShown = true;
        }

        if (stay > 0) {
            subTask = new Runnable() {
                @Override
                public void run() {
                    removeSub(true);
                }
            };
            h.postDelayed(subTask, stay);
        }
    }

    /** 通知来源 App 切到前台时，把岛收掉（可在通用里关）。 */
    private void checkForegroundHide() {
        if (!Common.getB(this, Common.K_FG_HIDE, false)) return;
        String fg = SihuaA11y.foreground;
        if (fg != null && fg.equals(getPackageName())) return;
        boolean same = fg != null && fgPkg != null && fg.equals(fgPkg);
        if (!fgSuppressed) {
            if (!attached || island == null || lastPkg == null) return;
            if (fg == null || !fg.equals(lastPkg)) return;
            // 事件来源 App 在前台：按设置变成圆形常驻，或者直接隐藏
            fgSuppressed = true;
            fgPkg = fg;
            saveKind = lastKind;
            saveTitle = lastTitle;
            saveSub = lastSub;
            savePkg = lastPkg;
            saveProgress = lastProgress;
            saveAccent = lastAccent;
            if (Common.getB(this, Common.K_IDLE_CIRCLE, false)) showIdle();
            else removeIsland(false);
            return;
        }
        if (same) return;
        // 来源 App 退到后台：把刚才的事件还回来
        fgSuppressed = false;
        fgPkg = null;
        if (saveKind == IslandView.KIND_MUSIC && saveTitle != null) {
            updateMusic();
            if (!attached) {
                show(IslandView.KIND_MUSIC, saveTitle, saveSub, savePkg,
                        saveProgress, saveAccent, 3200, 0);
            }
        } else if (saveTitle != null) {
            show(saveKind, saveTitle, saveSub, savePkg, saveProgress, saveAccent,
                    stayMs() + 800, stayMs());
        } else if (pinned() && !attached) {
            showIdle();
        }
    }

    /** 点副岛：淡出，再把副事件升成主事件。 */
    private void promoteSub() {
        if (!subAttached || sub == null || subLp == null) return;
        final int k = subKind;
        final String t = subTitle;
        final String t2 = subSub;
        final String p = subPkg;
        final int pr = subProgress;
        final int ac = subAccent;
        // 记住原来的主事件，换下去当副岛，别直接丢掉
        final int oldKind = lastKind;
        final String oldTitle = lastTitle;
        final String oldSub = lastSub;
        final String oldPkg = lastPkg;
        final int oldProgress = lastProgress;
        final int oldAccent = lastAccent;
        h.removeCallbacks(subTask);
        subTask = null;
        dropSubAnim();
        cancelBridgeAnim();
        shiftMain(0, 320);
        subAttached = false;
        final IslandView v = sub;
        subAnim = android.animation.ValueAnimator.ofFloat(1f, 0f);
        subAnim.setDuration(180);
        subAnim.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(android.animation.ValueAnimator a) {
                if (v != sub) return;
                float f = (Float) a.getAnimatedValue();
                v.setAlpha(f);
                v.setContentAlpha(f);
            }
        });
        subAnim.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator a) {
                if (subAnimCanceling) return;
                subAnim = null;
                hideSubShell();
                show(k, t, t2, p, pr, ac, 3200, 0);
                if (!expanded) expand();
                if (multiOn() && oldTitle != null) {
                    showSub(oldKind, oldTitle, oldSub, oldPkg, oldProgress, oldAccent, 0);
                }
                if (oldKind == IslandView.KIND_MUSIC && playingState()) {
                    scheduleRestore();
                }
            }
        });
        subAnim.start();
    }

    private void removeSub(boolean anim) {
        h.removeCallbacks(subTask);
        subTask = null;
        dropSubAnim();
        shiftMain(0, 320);
        cancelBridgeAnim();
        if (sub == null || subLp == null || !subAttached) {
            subAttached = false;
            subWasShown = false;
            return;
        }
        subAttached = false;
        final IslandView v = sub;
        if (!anim) {
            hideSubShell();
            return;
        }
        final int fromPill = subPillLeft;
        final int awayDir = subSide() == 1 ? 1 : -1;
        final int toPill = fromPill + awayDir * Common.dp(this, 9);
        sub.setPivotX(islandH / 2f + padS);
        sub.setPivotY(subH() / 2f);
        subAnim = android.animation.ValueAnimator.ofFloat(1f, 0f);
        subAnim.setDuration(260);
        subAnim.setInterpolator(new android.view.animation.PathInterpolator(0.3f, 0f, 0.5f, 1f));
        subAnim.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(android.animation.ValueAnimator a) {
                if (v != sub || subLp == null) return;
                float f = (Float) a.getAnimatedValue();
                subPillLeft = toPill + (int) ((fromPill - toPill) * f);
                subLp.x = subPillLeft - padS;
                try {
                    wm.updateViewLayout(sub, subLp);
                } catch (Exception ignored) {
                }
                float sc = 0.9f + 0.1f * f;
                v.setScaleX(sc);
                v.setScaleY(sc);
                v.setAlpha(f);
                v.setContentAlpha(f);
            }
        });
        subAnim.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator a) {
                if (subAnimCanceling) return;
                subAnim = null;
                if (v == sub) hideSubShell();
            }
        });
        subAnim.start();
    }

    private void scheduleRestore() {
        h.removeCallbacks(restoreTask);
        restoreTask = new Runnable() {
            @Override
            public void run() {
                if (!attached || lastKind == IslandView.KIND_MUSIC) return;
                if (!playingState()) return;
                String ct = lastTitle;
                String cs = lastSub;
                String cp = lastPkg;
                int ck = lastKind;
                int cpr = lastProgress;
                int ca = lastAccent;
                if (multiOn() && ct != null) {
                    showSub(ck, ct, cs, cp, cpr, ca, 0);
                }
                updateMusic();
            }
        };
        h.postDelayed(restoreTask, 5000);
    }

    private void cancelRestore() {
        h.removeCallbacks(restoreTask);
        restoreTask = null;
    }

    /** 下拉：窗口整体跟着手指往下走，回弹或收起前先归位。 */
    private void movePull(int dy) {
        if (!attached || lp == null) return;
        if (pullAnim != null) {
            android.animation.ValueAnimator old = pullAnim;
            pullAnim = null;
            old.cancel();
        }
        if (pullWinY == 0) pullBaseY = lp.y;
        int max = Common.dp(this, 46);
        pullWinY = (int) (max * Math.tanh(dy / (double) max));
        lp.y = pullBaseY + pullWinY;
        try {
            wm.updateViewLayout(island, lp);
        } catch (Exception ignored) {
        }
    }

    private void resetPullY() {
        if (pullAnim != null) {
            android.animation.ValueAnimator old = pullAnim;
            pullAnim = null;
            old.cancel();
        }
        pullWinY = 0;
        if (attached && lp != null) {
            lp.y = pullBaseY >= 0 ? pullBaseY : yFor(expanded);
            try {
                wm.updateViewLayout(island, lp);
            } catch (Exception ignored) {
            }
        }
        pullBaseY = -1;
    }

    private void cancelPull() {
        if (!attached || lp == null) {
            pullWinY = 0;
            pullBaseY = -1;
            return;
        }
        if (pullWinY == 0) {
            resetPullY();
            return;
        }
        if (pullAnim != null) {
            android.animation.ValueAnimator old = pullAnim;
            pullAnim = null;
            old.cancel();
        }
        final int base = pullBaseY >= 0 ? pullBaseY : yFor(expanded);
        final android.animation.ValueAnimator a =
                android.animation.ValueAnimator.ofInt(pullWinY, 0);
        pullAnim = a;
        a.setDuration(240);
        a.setInterpolator(new android.view.animation.OvershootInterpolator(1.8f));
        a.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(android.animation.ValueAnimator va) {
                if (!attached || lp == null) return;
                pullWinY = (Integer) va.getAnimatedValue();
                lp.y = base + pullWinY;
                try {
                    wm.updateViewLayout(island, lp);
                } catch (Exception ignored) {
                }
            }
        });
        a.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator an) {
                if (pullAnim == a) pullAnim = null;
                resetPullY();
                if (pullPendingHide) {
                    pullPendingHide = false;
                    performPullHide();
                }
            }
        });
        a.start();
    }

    private boolean canPullHide() {
        return isLandscape() && lastKind == IslandView.KIND_MUSIC
                && Common.getB(this, Common.K_PULL, true);
    }

    /** 横屏快捷岛 / 音乐卡的「隐藏岛」：收起并停止检测音乐，竖屏再恢复。 */
    private void hideIslandByUser() {
        if (!isLandscape()) return;
        String track = lastKind == IslandView.KIND_MUSIC ? lastTitle : null;
        landscapeMusicOff = true;
        hasQuickPrev = false;
        if (lastKind == IslandView.KIND_QUICK) clearQuick();
        else clearEvent();
        postHiddenMusic(track);
    }

    /** 横屏音乐卡上的「隐藏岛」：收起并停止检测音乐，回到竖屏再恢复。 */
    private void hideMusicEvent() {
        if (!isLandscape()) return;
        cancelRestore();
        String track = lastTitle;
        landscapeMusicOff = true;
        clearEvent();
        postHiddenMusic(track);
    }

    private void performPullHide() {
        if (!canPullHide()) return;
        String track = lastTitle;
        landscapeMusicOff = true;
        clearEvent();
        postHiddenMusic(track);
    }

    /** 开新的窗口动画前先停掉拖拽/回弹动画，避免两个动画抢着写 lp.x。 */
    private void stopDragAnims() {
        if (dragWinAnim != null) {
            android.animation.ValueAnimator a = dragWinAnim;
            dragWinAnim = null;
            try {
                a.cancel();
            } catch (Exception ignored) {
            }
        }
        if (pullAnim != null) {
            android.animation.ValueAnimator a = pullAnim;
            pullAnim = null;
            try {
                a.cancel();
            } catch (Exception ignored) {
            }
        }
        if (swipeAnim != null) {
            android.animation.ValueAnimator a = swipeAnim;
            swipeAnim = null;
            try {
                a.cancel();
            } catch (Exception ignored) {
            }
        }
        dragWinX = 0;
        pullWinY = 0;
        if (pullBaseY >= 0 && lp != null) lp.y = pullBaseY;
        pullBaseY = -1;
    }

    /** 拖动时直接挪窗口：完全跟手，也不会被窗口边缘裁掉。 */
    private void dragIsland(int dx) {
        if (!attached || lp == null) return;
        if (dragWinAnim != null) {
            android.animation.ValueAnimator old = dragWinAnim;
            dragWinAnim = null;
            old.cancel();
        }
        h.removeCallbacks(resetXTask);
        // 不设窗口限制：跟手到底，只保证不拖出屏幕
        int sw = getResources().getDisplayMetrics().widthPixels;
        int max = Math.max(Common.dp(this, 40), (sw - lp.width) / 2 - Common.dp(this, 6));
        dragWinX = Math.max(-max, Math.min(max, dx));
        if (widthAnim != null && widthAnim.isRunning()) return;
        lp.x = offX + shiftPx + idleExtraX + dragWinX;
        try {
            wm.updateViewLayout(island, lp);
        } catch (Exception ignored) {
        }
    }

    /** 把窗口严格放回基准位置。 */
    private void resetWindowX() {
        dragWinX = 0;
        if (!attached || lp == null) return;
        lp.x = offX + shiftPx + idleExtraX;
        try {
            wm.updateViewLayout(island, lp);
        } catch (Exception ignored) {
        }
    }

    /** 松手：无论动画是否被打断，最后一定回到基准位置。 */
    private void endDragIsland() {
        if (dragWinAnim != null) {
            android.animation.ValueAnimator old = dragWinAnim;
            dragWinAnim = null;
            old.cancel();
        }
        if (!attached || lp == null) {
            dragWinX = 0;
            return;
        }
        if (dragWinX == 0) {
            resetWindowX();
            return;
        }
        final int from = dragWinX;
        final android.animation.ValueAnimator a =
                android.animation.ValueAnimator.ofInt(from, 0);
        dragWinAnim = a;
        a.setDuration(240);
        a.setInterpolator(new android.view.animation.OvershootInterpolator(1.8f));
        a.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(android.animation.ValueAnimator va) {
                dragWinX = (Integer) va.getAnimatedValue();
                if (!attached || lp == null) return;
                lp.x = offX + shiftPx + idleExtraX + dragWinX;
                try {
                    wm.updateViewLayout(island, lp);
                } catch (Exception ignored) {
                }
            }
        });
        a.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator an) {
                if (dragWinAnim == a) dragWinAnim = null;
                resetWindowX();
            }

            @Override
            public void onAnimationCancel(android.animation.Animator an) {
                resetWindowX();
            }
        });
        a.start();
        // 兜底：动画万一没跑完，稍后强制归位一次，保证 100% 复位
        h.removeCallbacks(resetXTask);
        h.postDelayed(resetXTask, 420);
    }

    private final Runnable resetXTask = new Runnable() {
        @Override
        public void run() {
            resetWindowX();
        }
    };

    /** 横向滑动：滑到位直接执行，切歌带一下回弹，清消息整块飞出去。 */
    private void handleHorizontalSwipe(int dir) {
        if (!attached || lp == null || island == null) return;
        if (island.isIdle()) return;
        cancelRestore();
        if (lastKind == IslandView.KIND_QUICK) {
            clearQuick();
            return;
        }
        if (lastKind == IslandView.KIND_MUSIC
                && Common.getB(this, Common.K_SWIPE, true)) {
            onMusicAction(dir > 0 ? IslandView.ACT_NEXT : IslandView.ACT_PREV);
            swipeNudge(dir);
        } else {
            swipeFlyOut(dir);
        }
    }

    private void swipeNudge(int dir) {
        stopSwipeAnim();
        final int base = lp.x;
        final int delta = Common.dp(this, dir > 0 ? 18 : -18);
        final android.animation.ValueAnimator a =
                android.animation.ValueAnimator.ofFloat(0f, 1f);
        swipeAnim = a;
        a.setDuration(260);
        a.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(android.animation.ValueAnimator va) {
                if (!attached || lp == null) return;
                float f = (Float) va.getAnimatedValue();
                int off = (int) (delta * Math.sin(Math.PI * f));
                lp.x = base + off;
                try {
                    wm.updateViewLayout(island, lp);
                } catch (Exception ignored) {
                }
            }
        });
        a.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator an) {
                if (swipeAnim == a) swipeAnim = null;
                if (!attached || lp == null) return;
                lp.x = base;
                try {
                    wm.updateViewLayout(island, lp);
                } catch (Exception ignored) {
                }
            }
        });
        a.start();
    }

    private void swipeFlyOut(int dir) {
        stopSwipeAnim();
        final int base = lp.x;
        final int sw = getResources().getDisplayMetrics().widthPixels;
        final int delta = dir > 0 ? sw : -sw;
        final android.animation.ValueAnimator a =
                android.animation.ValueAnimator.ofFloat(0f, 1f);
        swipeAnim = a;
        a.setDuration(190);
        a.setInterpolator(new android.view.animation.AccelerateInterpolator(1.7f));
        a.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(android.animation.ValueAnimator va) {
                if (!attached || lp == null || island == null) return;
                float f = (Float) va.getAnimatedValue();
                lp.x = base + (int) (delta * f * 0.5f);
                island.setAlpha(1f - f);
                try {
                    wm.updateViewLayout(island, lp);
                } catch (Exception ignored) {
                }
            }
        });
        a.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator an) {
                if (swipeAnim == a) swipeAnim = null;
                if (!attached || island == null) return;
                island.setAlpha(1f);
                if (lp != null) lp.x = base;
                if (pinned()) {
                    showIdle();
                } else {
                    lastKind = IslandView.KIND_NOTI;
                    lastTitle = null;
                    lastSub = null;
                    lastPkg = null;
                    lastProgress = -1;
                    removeIsland(true);
                }
            }
        });
        a.start();
    }

    private void stopSwipeAnim() {
        if (swipeAnim != null) {
            android.animation.ValueAnimator a = swipeAnim;
            swipeAnim = null;
            try {
                a.cancel();
            } catch (Exception ignored) {
            }
        }
    }

    private void shiftMain(int target, long dur) {
        if (shiftAnim != null) shiftAnim.cancel();
        shiftGoal = target;
        final int from = shiftPx;
        if (from == target) return;
        shiftAnim = android.animation.ValueAnimator.ofInt(from, target);
        shiftAnim.setDuration(dur);
        shiftAnim.setInterpolator(new android.view.animation.PathInterpolator(0.22f, 0f, 0f, 1f));
        shiftAnim.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(android.animation.ValueAnimator a) {
                shiftPx = (Integer) a.getAnimatedValue();
                if (island == null || !attached || lp == null) return;
                if (widthAnim != null && widthAnim.isRunning()) return;
                lp.x = offX + shiftPx + idleExtraX;
                try {
                    wm.updateViewLayout(island, lp);
                } catch (Exception ignored) {
                }
            }
        });
        shiftAnim.start();
    }

    /** 展开的消息点一下：弹键盘直接回复（通知带 RemoteInput 才行）。 */
    private void openReply() {
        if (replyBar != null) return;
        if (NotificationListener.replyPi == null
                || NotificationListener.replyInputs == null
                || (NotificationListener.replyPkg != null && lastPkg != null
                && !NotificationListener.replyPkg.equals(lastPkg))) {
            Toast.makeText(this, "这条消息没有回复入口，已打开应用", Toast.LENGTH_SHORT).show();
            openSource();
            return;
        }
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xF2161923);
        g.setCornerRadius(Common.dp(this, 22));
        g.setStroke(Common.dp(this, 1), 0x40FFFFFF);
        bar.setBackground(g);
        bar.setPadding(Common.dp(this, 16), Common.dp(this, 6),
                Common.dp(this, 8), Common.dp(this, 6));

        final EditText et = new EditText(this);
        et.setHint("回复消息…");
        et.setTextSize(13.5f);
        et.setTextColor(0xFFF2F4F8);
        et.setHintTextColor(0xFF8A90A0);
        et.setBackground(null);
        et.setSingleLine(true);
        et.setImeOptions(EditorInfo.IME_ACTION_SEND);
        bar.addView(et, new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView send = Ui.text(this, "发送", 13f, 0xFF5EE7FF, true);
        send.setPadding(Common.dp(this, 14), Common.dp(this, 8),
                Common.dp(this, 14), Common.dp(this, 8));
        bar.addView(send);

        int wpx = Math.min(getResources().getDisplayMetrics().widthPixels - Common.dp(this, 32),
                Common.dp(this, 360));
        WindowManager.LayoutParams rlp = new WindowManager.LayoutParams(wpx,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT);
        rlp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        int hh = expanded ? (lastKind == IslandView.KIND_MUSIC ? musicH : expandedH) : islandH;
        rlp.y = offY + winH(hh) + Common.dp(this, 8);
        rlp.flags |= WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH;
        rlp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE
                | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;
        bar.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, android.view.MotionEvent e) {
                if (e.getAction() == android.view.MotionEvent.ACTION_OUTSIDE) {
                    closeReply();
                }
                return false;
            }
        });
        try {
            wm.addView(bar, rlp);
            replyBar = bar;
        } catch (Exception e) {
            replyBar = null;
            return;
        }
        final View.OnClickListener sendAct = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendReply(et.getText().toString());
            }
        };
        send.setOnClickListener(sendAct);
        et.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, android.view.KeyEvent e) {
                if (actionId == EditorInfo.IME_ACTION_SEND
                        || (e != null && e.getKeyCode() == android.view.KeyEvent.KEYCODE_ENTER)) {
                    sendReply(et.getText().toString());
                    return true;
                }
                return false;
            }
        });
        et.requestFocus();
        et.post(new Runnable() {
            @Override
            public void run() {
                try {
                    InputMethodManager imm = (InputMethodManager)
                            getSystemService(INPUT_METHOD_SERVICE);
                    if (imm != null) imm.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT);
                } catch (Exception ignored) {
                }
            }
        });
    }

    private void sendReply(String text) {
        if (text == null || text.trim().length() == 0) {
            closeReply();
            return;
        }
        try {
            Bundle res = new Bundle();
            for (android.app.RemoteInput in : NotificationListener.replyInputs) {
                res.putCharSequence(in.getResultKey(), text.trim());
            }
            Intent i = new Intent();
            android.app.RemoteInput.addResultsToIntent(NotificationListener.replyInputs,
                    i, res);
            NotificationListener.replyPi.send(this, 0, i);
            Toast.makeText(this, "已发送", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "发送失败", Toast.LENGTH_SHORT).show();
        }
        closeReply();
    }

    private void closeReply() {
        if (replyBar == null) return;
        try {
            InputMethodManager imm = (InputMethodManager)
                    getSystemService(INPUT_METHOD_SERVICE);
            View f = replyBar.findFocus();
            if (imm != null && f != null) imm.hideSoftInputFromWindow(f.getWindowToken(), 0);
        } catch (Exception ignored) {
        }
        try {
            wm.removeView(replyBar);
        } catch (Exception ignored) {
        }
        replyBar = null;
    }

    private void dropSubAnim() {
        if (subAnim != null) {
            subAnimCanceling = true;
            subAnim.cancel();
            subAnimCanceling = false;
            subAnim = null;
        }
    }

    // ---------------- 音乐 ----------------

    private void setupMusic() {
        if (!Common.hasNotiListener(this)) return;
        try {
            msm = (MediaSessionManager) getSystemService(MEDIA_SESSION_SERVICE);
            listenerCn = new ComponentName(this, NotificationListener.class);
            msm.addOnActiveSessionsChangedListener(
                    new MediaSessionManager.OnActiveSessionsChangedListener() {
                        @Override
                        public void onActiveSessionsChanged(List<MediaController> list) {
                            pickSession(list);
                        }
                    }, listenerCn);
            pickSession(msm.getActiveSessions(listenerCn));
        } catch (Exception ignored) {
        }
    }

    private void startMediaPoll() {
        final Runnable tick = new Runnable() {
            @Override
            public void run() {
                try {
                    if (msm == null && Common.hasNotiListener(IslandService.this)) setupMusic();
                    if (msm != null && listenerCn != null) {
                        // 一直检测：设置页预览、切后台等场景过后也能自动恢复音乐岛
                        pickSession(msm.getActiveSessions(listenerCn));
                    }
                } catch (Exception ignored) {
                }
                checkForegroundHide();
                h.postDelayed(this, 1200);
            }
        };
        h.postDelayed(tick, 600);
    }

    private void pickSession(List<MediaController> list) {
        if (list == null) list = new java.util.ArrayList<MediaController>();
        boolean hasCurrent = false;
        for (MediaController c : list) {
            if (c == controller) hasCurrent = true;
            PlaybackState ps = c.getPlaybackState();
            if (ps != null && ps.getState() == PlaybackState.STATE_PLAYING) {
                bind(c);
                return;
            }
        }
        if (controller == null) return;
        if (hasCurrent) {
            absentTicks = 0;
            updateMusic();
            return;
        }
        // 会话从列表里消失了：播放中可能是播放器被杀，暂停中先等等，别一暂停就收岛
        PlaybackState ps = null;
        try {
            ps = controller.getPlaybackState();
        } catch (Exception ignored) {
        }
        int st = ps == null ? PlaybackState.STATE_NONE : ps.getState();
        absentTicks++;
        if (st == PlaybackState.STATE_PLAYING) {
            if (absentTicks >= 2) musicGone();
        } else if (st == PlaybackState.STATE_PAUSED || st == PlaybackState.STATE_BUFFERING) {
            if (absentTicks >= 10) musicGone();
        } else {
            musicGone();
        }
    }

    /** 播放器被关掉 / 会话没了：音乐岛跟着退场，别留一个停住的卡片。 */
    private void musicGone() {
        if (controller != null && mediaCb != null) {
            try {
                controller.unregisterCallback(mediaCb);
            } catch (Exception ignored) {
            }
        }
        controller = null;
        mediaCb = null;
        landscapeMusicOff = false;
        cancelHiddenMusic();
        if (lastKind != IslandView.KIND_MUSIC || !attached) return;
        lastKind = IslandView.KIND_NOTI;
        if (pinned()) showIdle();
        else dismiss();
    }

    private void bind(MediaController c) {
        if (controller == c) {
            updateMusic();
            return;
        }
        if (controller != null && mediaCb != null) {
            try {
                controller.unregisterCallback(mediaCb);
            } catch (Exception ignored) {
            }
        }
        if (controller != null) {
            String oldPkg = controller.getPackageName();
            String newPkg = c.getPackageName();
            if (oldPkg != null && newPkg != null && !oldPkg.equals(newPkg)) {
                landscapeMusicOff = false;
                cancelHiddenMusic();
            }
        }
        controller = c;
        absentTicks = 0;
        mediaCb = new MediaController.Callback() {
            @Override
            public void onPlaybackStateChanged(PlaybackState state) {
                updateMusic();
            }

            @Override
            public void onMetadataChanged(MediaMetadata metadata) {
                updateMusic();
            }
        };
        try {
            c.registerCallback(mediaCb);
        } catch (Exception ignored) {
        }
        updateMusic();
    }

    /** 媒体通知里带了会话 Token：系统没列出来的播放器也能接上。 */
    void onMediaNotification(String pkg, android.media.session.MediaSession.Token token) {
        if (token == null) return;
        try {
            if (controller != null && pkg != null
                    && pkg.equals(controller.getPackageName()) && playingState()) {
                refreshMusicArt();
                return;
            }
            MediaController c = new MediaController(this, token);
            PlaybackState ps = c.getPlaybackState();
            if (ps != null && ps.getState() == PlaybackState.STATE_PLAYING) bind(c);
        } catch (Exception ignored) {
        }
    }

    /** 通知里补到新封面时，把当前音乐岛的画面换掉。 */
    void refreshMusicArt() {
        if (!attached || lastKind != IslandView.KIND_MUSIC) return;
        h.removeCallbacks(artRefreshTask);
        artRefreshTask = new Runnable() {
            @Override
            public void run() {
                artRefreshTask = null;
                updateMusic();
            }
        };
        h.postDelayed(artRefreshTask, 220);
    }

    private void updateMusic() {
        if (controller == null) return;
        PlaybackState ps = controller.getPlaybackState();
        boolean playing = ps != null && ps.getState() == PlaybackState.STATE_PLAYING;
        if (!playing) {
            stopMic();
            // 音乐暂停：缩成小岛保留，不消失；已经收起就别再重播收起动画（会闪）
            if (island != null && attached && lastKind == IslandView.KIND_MUSIC) {
                island.setPlaying(false);
                if (expanded) collapse();
            }
            return;
        }
        if (!Common.getB(this, Common.K_MUSIC, true)) {
            stopMic();
            return;
        }
        MediaMetadata md = controller.getMetadata();
        String title = "";
        String artist = "";
        if (md != null) {
            CharSequence t = md.getText(MediaMetadata.METADATA_KEY_TITLE);
            CharSequence a = md.getText(MediaMetadata.METADATA_KEY_ARTIST);
            if (t == null) t = md.getText(MediaMetadata.METADATA_KEY_DISPLAY_TITLE);
            if (a == null) a = md.getText(MediaMetadata.METADATA_KEY_ALBUM);
            title = t == null ? "" : t.toString();
            artist = a == null ? "" : a.toString();
        }
        if (title.length() == 0) title = "正在播放";
        // 横屏下拉收起后：先不检测音乐，回到竖屏再恢复
        if (landscapeMusicOff) {
            if (isLandscape()) return;
            landscapeMusicOff = false;
            cancelHiddenMusic();
        }
        // 收藏状态：能从播放器 metadata 读到 user rating 就同步，读不到按未收藏显示
        Rating rating = md == null ? null
                : md.getRating(MediaMetadata.METADATA_KEY_USER_RATING);
        boolean trackChanged = lastTitle == null || !title.equals(lastTitle);
        // 播放器有收藏状态就跟着同步；读不到时看通知里的「取消喜欢」按钮
        lastRating = rating;
        if (rating != null && rating.isRated()) {
            liked = isLikedRating(rating);
        } else if (trackChanged) {
            // 只在换歌时用通知按钮猜，避免刚点完收藏又被旧通知覆盖
            Boolean hint = null;
            try {
                hint = NotificationListener.likedHint(controller.getPackageName());
            } catch (Exception ignored) {
            }
            liked = hint != null && hint.booleanValue();
        }
        Bitmap art = null;
        if (md != null) {
            art = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
            if (art == null) art = md.getBitmap(MediaMetadata.METADATA_KEY_ART);
            if (art == null) art = md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
        }
        int sz = Common.dp(this, 64);
        if (art != null) art = square(art, sz);
        if (art == null && md != null) art = artFromUri(md.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI), sz);
        if (art == null && md != null) art = artFromUri(md.getString(MediaMetadata.METADATA_KEY_ART_URI), sz);
        if (art == null && md != null) art = artFromUri(md.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI), sz);
        String pkg = controller.getPackageName();
        // 网易云 / 酷狗这类只把封面放在通知里，Metadata 是空的
        if (art == null) {
            art = square(NotificationListener.mediaIcon(pkg), sz);
        }
        // 有些播放器封面比元数据晚一步到，同一次播放里再补捞一次
        if (art == null && !title.equals(artRetryTitle)) {
            artRetryTitle = title;
            h.postDelayed(new Runnable() {
                @Override
                public void run() {
                    updateMusic();
                }
            }, 900);
        }
        boolean video = isVideoPkg(pkg);
        // 正在前台看视频 / 看相册：不弹音乐岛
        if (video && pkg.equals(SihuaA11y.foreground)) {
            stopMic();
            if (island != null && attached && lastKind == IslandView.KIND_MUSIC) collapse();
            return;
        }
        int accent = 0xFF9A6BFF;
        if (Common.getB(this, Common.K_COVER, false) && art != null) accent = coverColor(art);
        if (Common.getB(this, Common.K_MIC, false)) startMic(); else stopMic();

        // 正在显示别的消息：别把音乐岛硬顶上来，等它自己收掉再弹
        if (attached && lastKind != IslandView.KIND_MUSIC && lastTitle != null) return;
        // 已经在显示音乐岛：切歌只更新内容，不再播放入场 / 展开动画
        if (island != null && attached && lastKind == IslandView.KIND_MUSIC) {
            boolean same = title.equals(lastTitle) && artist.equals(lastSub)
                    && pkg.equals(lastPkg) && artSig(art) == lastArtSig;
            // 内容没变就别重画：播放器一秒发好几次播放状态，重画会看成在闪
            island.setPullClose(false);
            island.setHideBtn(isLandscape());
            applyCutout();
            if (same) {
                island.setNoLike(video);
                island.setPlaying(true);
                island.setLiked(liked);
                return;
            }
            lastArtSig = artSig(art);
            lastTitle = title;
            lastSub = artist;
            lastPkg = pkg;
            lastAccent = accent;
            lastProgress = -1;
            island.setNoLike(video);
            island.setVisual(Common.getB(this, Common.K_COLORFUL, false),
                    Common.getB(this, Common.K_HIRES, false));
            island.setData(IslandView.KIND_MUSIC, title, artist, art, -1, accent);
            island.setPlaying(true);
            island.setLiked(liked);
            return;
        }
        lastArtSig = artSig(art);
        show(IslandView.KIND_MUSIC, title, artist, pkg, art, -1, accent, 3200, 0);
        if (island != null) {
            island.setPlaying(true);
            island.setNoLike(video);
        }
    }

    private static boolean isLikedRating(Rating r) {
        if (r == null || !r.isRated()) return false;
        if (r.hasHeart() || r.isThumbUp()) return true;
        return r.getRatingStyle() == Rating.RATING_5_STARS && r.getStarRating() >= 3f;
    }

    /** 视频类应用：前台播放时不弹岛，后台播放时弹岛但不给收藏按钮。 */
    private boolean isVideoPkg(String pkg) {
        if (pkg == null) return false;
        String[] v = {"tv.danmaku.bili", "com.bilibili.", "com.ss.android.ugc.aweme",
                "com.google.android.youtube", "com.tencent.qqlive", "com.qiyi.video",
                "com.youku.phone", "com.hunantv.imgo", "com.vivo.gallery",
                "com.android.gallery3d", "com.google.android.apps.photos",
                "com.coloros.gallery3d", "com.miui.gallery", "com.oppo.gallery3d"};
        for (String p : v) {
            if (pkg.equals(p) || pkg.startsWith(p)) return true;
        }
        return false;
    }

    private boolean playingState() {
        PlaybackState ps = controller != null ? controller.getPlaybackState() : null;
        return ps != null && ps.getState() == PlaybackState.STATE_PLAYING;
    }

    private void onMusicAction(int act) {
        if (act == IslandView.ACT_HIDE) {
            hideMusicEvent();
            return;
        }
        if (act == IslandView.ACT_LIKE) {
            Boolean now = toggleLike();
            if (now == null) {
                Toast.makeText(this, "这个播放器不支持岛内收藏，请到播放器里点", Toast.LENGTH_SHORT)
                        .show();
                return;
            }
            liked = now.booleanValue();
            if (island != null) island.setLiked(liked);
            // 等播放器回写真实状态，再同步一次
            h.postDelayed(new Runnable() {
                @Override
                public void run() {
                    updateMusic();
                }
            }, 800);
            return;
        }
        if (controller == null) {
            controller = pickPlaying();
            if (controller == null) return;
            bind(controller);
        }
        try {
            switch (act) {
                case IslandView.ACT_PREV:
                    controller.getTransportControls().skipToPrevious();
                    break;
                case IslandView.ACT_TOGGLE:
                    if (playingState()) controller.getTransportControls().pause();
                    else controller.getTransportControls().play();
                    break;
                case IslandView.ACT_NEXT:
                    controller.getTransportControls().skipToNext();
                    break;
                default:
                    break;
            }
        } catch (Exception ignored) {
        }
    }

    /** 收藏开关：先摸清当前状态，再决定点哪个；返回新的收藏状态，失败返回 null。 */
    private Boolean toggleLike() {
        if (controller == null) {
            controller = pickPlaying();
            if (controller != null) bind(controller);
        }
        if (controller == null) return null;
        String pkg = controller.getPackageName();
        Rating cur = null;
        try {
            MediaMetadata md = controller.getMetadata();
            if (md != null) cur = md.getRating(MediaMetadata.METADATA_KEY_USER_RATING);
        } catch (Exception ignored) {
        }
        Boolean known = null;
        if (cur != null && cur.isRated()) known = isLikedRating(cur);
        if (known == null) {
            try {
                known = NotificationListener.likedHint(pkg);
            } catch (Exception ignored) {
            }
        }
        boolean target = known != null ? !known.booleanValue() : !liked;
        int type = Rating.RATING_NONE;
        try {
            type = controller.getRatingType();
        } catch (Exception ignored) {
        }
        if (type == Rating.RATING_NONE && cur != null) type = cur.getRatingStyle();
        if (type != Rating.RATING_NONE) {
            try {
                Rating r;
                if (type == Rating.RATING_THUMB_UP_DOWN) {
                    r = Rating.newThumbRating(target);
                } else if (type == Rating.RATING_5_STARS) {
                    r = Rating.newStarRating(Rating.RATING_5_STARS, target ? 5f : 1f);
                } else if (type == Rating.RATING_3_STARS) {
                    r = Rating.newStarRating(Rating.RATING_3_STARS, target ? 3f : 1f);
                } else {
                    r = Rating.newHeartRating(target);
                }
                controller.getTransportControls().setRating(r);
                return Boolean.valueOf(target);
            } catch (Exception ignored) {
            }
        }
        // 只有确认过当前状态，才敢去点通知按钮，否则可能把已收藏的点成取消
        if (known != null && NotificationListener.tapLike(pkg, target)) {
            return Boolean.valueOf(target);
        }
        if (known != null) {
            try {
                Bundle b = new Bundle();
                b.putBoolean("like", target);
                b.putBoolean("isFavorite", target);
                controller.getTransportControls().sendCustomAction(target ? "like" : "unlike", b);
                return Boolean.valueOf(target);
            } catch (Exception ignored) {
            }
        }
        return null;
    }

    private MediaController pickPlaying() {
        try {
            MediaSessionManager m = msm;
            if (m == null) {
                m = (MediaSessionManager) getSystemService(MEDIA_SESSION_SERVICE);
                msm = m;
                listenerCn = new ComponentName(this, NotificationListener.class);
            }
            List<MediaController> l = m.getActiveSessions(
                    new ComponentName(this, NotificationListener.class));
            MediaController paused = null;
            if (l != null) for (MediaController c : l) {
                PlaybackState ps = c.getPlaybackState();
                if (ps == null) continue;
                if (ps.getState() == PlaybackState.STATE_PLAYING) return c;
                if (paused == null && (ps.getState() == PlaybackState.STATE_PAUSED
                        || ps.getState() == PlaybackState.STATE_BUFFERING)) paused = c;
            }
            return paused;
        } catch (Exception ignored) {
        }
        return null;
    }

    private Bitmap artFromUri(String u, int size) {
        if (u == null) return null;
        try {
            java.io.InputStream in = getContentResolver().openInputStream(Uri.parse(u));
            if (in == null) return null;
            Bitmap b = BitmapFactory.decodeStream(in);
            in.close();
            return square(b, size);
        } catch (Exception e) {
            return null;
        }
    }

    /** 封面指纹：判断是不是同一张图，避免每次回调都重画。 */
    private int artSig(Bitmap b) {
        if (b == null || b.isRecycled()) return 0;
        int w = b.getWidth(), hh = b.getHeight();
        if (w <= 0 || hh <= 0) return 0;
        int sig = w * 31 + hh;
        try {
            for (int i = 1; i <= 3; i++) {
                sig = sig * 31 + b.getPixel(w * i / 4, hh * i / 4);
            }
        } catch (Exception ignored) {
        }
        return sig;
    }

    /** 封面统一裁成方形再缩放，避免被拉扁。 */
    private Bitmap square(Bitmap b, int size) {
        if (b == null || b.isRecycled()) return null;
        try {
            int w = b.getWidth(), hh = b.getHeight();
            int s = Math.min(w, hh);
            if (s <= 0) return null;
            if (w != hh) b = Bitmap.createBitmap(b, (w - s) / 2, (hh - s) / 2, s, s);
            if (b.getWidth() != size) b = Bitmap.createScaledBitmap(b, size, size, true);
            return b;
        } catch (Exception e) {
            try {
                return Bitmap.createScaledBitmap(b, size, size, true);
            } catch (Exception e2) {
                return b;
            }
        }
    }

    /** 封面主色：跳过接近黑 / 白 / 灰的像素，取最饱和的一簇。 */
    private int coverColor(Bitmap b) {
        try {
            int w = Math.min(24, b.getWidth());
            int h = Math.min(24, b.getHeight());
            int ss = Math.max(1, b.getWidth() / w);
            long r = 0, g = 0, bl = 0;
            int n = 0;
            float bestSat = -1;
            int best = 0xFF9A6BFF;
            for (int y = 0; y < h; y += 2) {
                for (int x = 0; x < w; x += 2) {
                    int p = b.getPixel(x * ss, y * ss);
                    int rr = (p >> 16) & 0xFF, gg = (p >> 8) & 0xFF, bb = p & 0xFF;
                    int mx = Math.max(rr, Math.max(gg, bb)), mn = Math.min(rr, Math.min(gg, bb));
                    float sat = mx == 0 ? 0 : (mx - mn) / (float) mx;
                    if (mx < 36 || mn > 235) continue;
                    if (sat > bestSat) {
                        bestSat = sat;
                        best = p;
                    }
                    r += rr;
                    g += gg;
                    bl += bb;
                    n++;
                }
            }
            if (bestSat > 0.25f) {
                int max = Math.max((best >> 16) & 0xFF, Math.max((best >> 8) & 0xFF, best & 0xFF));
                if (max < 110) {
                    float k = 110f / Math.max(1, max);
                    int rr = Math.min(255, (int) (((best >> 16) & 0xFF) * k));
                    int gg = Math.min(255, (int) (((best >> 8) & 0xFF) * k));
                    int bb = Math.min(255, (int) ((best & 0xFF) * k));
                    return Color.rgb(rr, gg, bb);
                }
                return best | 0xFF000000;
            }
            if (n > 0) return Color.rgb((int) (r / n), (int) (g / n), (int) (bl / n));
        } catch (Exception ignored) {
        }
        return 0xFF9A6BFF;
    }

    // ---------------- 真实音律 ----------------

    private void startMic() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) return;
        if (micRun) return;
        int mode = Common.getI(this, Common.K_MIC_MODE, 0);
        if (mode == 2) {
            if (startPlaybackCapture()) return;
            startMicRecord();
            return;
        }
        if (mode == 0 && !Common.getB(this, Common.K_VIS_FAILED, false)) {
            if (startVisualizer(0)) {
                scheduleVisCheck();
                return;
            }
        }
        startMicRecord();
    }

    /** 3 秒内一点波形都没有，判定这台机器不给全局混音，自动回退麦克风。 */
    private void scheduleVisCheck() {
        final int gen = ++visGen;
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (gen != visGen || !micRun || vis == null) return;
                if (visHadData) return;
                Common.setB(IslandService.this, Common.K_VIS_FAILED, true);
                stopMic();
                startMic();
            }
        }, 3000);
    }

    /** 直接读系统播放的波形（AudioEffect.Visualizer），不需要录屏授权。 */
    private boolean startVisualizer(int sid) {
        try {
            if (vis != null) {
                try {
                    vis.setEnabled(false);
                    vis.release();
                } catch (Exception ignored) {
                }
                vis = null;
            }
            vis = new android.media.audiofx.Visualizer(sid);
            if (!vis.getEnabled()) vis.setEnabled(true);
            visSession = sid;
            visHadData = false;
            int size = android.media.audiofx.Visualizer.getCaptureSizeRange()[1];
            size = Math.min(size, 1024);
            vis.setCaptureSize(size);
            micRun = true;
            micLevel = 0f;
            shownLevel = 0f;
            h.post(levelTick);
            vis.setDataCaptureListener(new android.media.audiofx.Visualizer.OnDataCaptureListener() {
                @Override
                public void onWaveFormDataCapture(android.media.audiofx.Visualizer v,
                                                  byte[] bytes, int rate) {
                    if (bytes == null || bytes.length == 0) return;
                    double sum = 0;
                    float peak = 0f;
                    for (byte b : bytes) {
                        double x = (b & 0xFF) - 128;
                        sum += (x / 128.0) * (x / 128.0);
                        peak = Math.max(peak, (float) Math.abs(x / 128.0));
                    }
                    if (peak > 0.02f) visHadData = true;
                    float rms = (float) Math.sqrt(sum / bytes.length);
                    micLevel = Math.min(1f, rms * 7f);
                }

                @Override
                public void onFftDataCapture(android.media.audiofx.Visualizer v,
                                             byte[] bytes, int rate) {
                }
            }, android.media.audiofx.Visualizer.getMaxCaptureRate() / 2, true, false);
            return true;
        } catch (Exception e) {
            vis = null;
            visSession = 0;
            return false;
        }
    }

    /** Android 10+ 官方内录：需要录屏授权。 */
    private boolean startPlaybackCapture() {
        if (Build.VERSION.SDK_INT < 29 || projection == null) return false;
        try {
            int min = AudioRecord.getMinBufferSize(44100,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (min <= 0) min = 4096;
            AudioFormat fmt = new AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(44100)
                    .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                    .build();
            android.media.AudioPlaybackCaptureConfiguration cfg =
                    new android.media.AudioPlaybackCaptureConfiguration.Builder(projection)
                            .addMatchingUsage(android.media.AudioAttributes.USAGE_MEDIA)
                            .addMatchingUsage(android.media.AudioAttributes.USAGE_GAME)
                            .addMatchingUsage(android.media.AudioAttributes.USAGE_UNKNOWN)
                            .build();
            mic = new AudioRecord.Builder()
                    .setAudioFormat(fmt)
                    .setBufferSizeInBytes(Math.max(min, 4096))
                    .setAudioPlaybackCaptureConfig(cfg)
                    .build();
            return startRecording();
        } catch (Exception e) {
            mic = null;
            return false;
        }
    }

    private void startMicRecord() {
        try {
            int min = AudioRecord.getMinBufferSize(44100,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (min <= 0) min = 4096;
            mic = new AudioRecord(MediaRecorder.AudioSource.MIC, 44100,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    Math.max(min, 4096));
            startRecording();
        } catch (Exception e) {
            micRun = false;
        }
    }

    private boolean startRecording() {
        try {
            mic.startRecording();
            micRun = true;
            micLevel = 0f;
            shownLevel = 0f;
            h.post(levelTick);
            micThread = new Thread() {
                @Override
                public void run() {
                    short[] buf = new short[1024];
                    while (micRun) {
                        int n;
                        try {
                            n = mic.read(buf, 0, buf.length);
                        } catch (Exception e) {
                            break;
                        }
                        if (n <= 0) continue;
                        double sum = 0;
                        for (int i = 0; i < n; i++) {
                            double v = buf[i] / 32768.0;
                            sum += v * v;
                        }
                        float rms = (float) Math.sqrt(sum / n);
                        micLevel = Math.min(1f, rms * 14f);
                    }
                }
            };
            micThread.start();
            return true;
        } catch (Exception e) {
            micRun = false;
            return false;
        }
    }

    private void stopMic() {
        micRun = false;
        visGen++;
        try {
            if (mic != null) {
                mic.stop();
                mic.release();
            }
        } catch (Exception ignored) {
        }
        mic = null;
        micThread = null;
        if (vis != null) {
            try {
                vis.setEnabled(false);
                vis.release();
            } catch (Exception ignored) {
            }
            vis = null;
        }
        visSession = 0;
        micLevel = 0f;
        if (island != null) island.setLevel(-1f);
        h.removeCallbacks(levelTick);
    }

    // ---------------- 下载 ----------------

    private void startDownloadTick() {
        dlTick = new Runnable() {
            @Override
            public void run() {
                int delay = 6000;
                try {
                    if (Common.getB(IslandService.this, Common.K_DL, true) && checkDownloads()) {
                        delay = 1500;
                    }
                } catch (Exception ignored) {
                }
                h.postDelayed(this, delay);
            }
        };
        h.postDelayed(dlTick, 2500);
    }

    private boolean checkDownloads() {
        DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        if (dm == null) return false;
        Cursor c = null;
        try {
            c = dm.query(new DownloadManager.Query().setFilterByStatus(
                    DownloadManager.STATUS_RUNNING | DownloadManager.STATUS_PENDING));
            if (c != null && c.moveToFirst()) {
                int ti = c.getColumnIndex(DownloadManager.COLUMN_TITLE);
                int di = c.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR);
                int si = c.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES);
                String title = ti >= 0 ? c.getString(ti) : "正在下载";
                long done = di >= 0 ? c.getLong(di) : 0;
                long total = si >= 0 ? c.getLong(si) : 0;
                int pct = total > 0 ? (int) (done * 100 / total) : -1;
                hadDownload = true;
                show(IslandView.KIND_DOWNLOAD, title == null ? "正在下载" : title,
                        total > 0 ? human(done) + " / " + human(total) : "下载中",
                        getPackageName(), Math.max(0, pct), 0xFF38D98A, 3000, 0);
                return true;
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        if (hadDownload) {
            hadDownload = false;
            show(IslandView.KIND_DOWNLOAD, "下载完成", "", getPackageName(), 100,
                    0xFF38D98A, 3000, 5200);
        }
        return false;
    }

    private String human(long b) {
        if (b > 1024L * 1024L) return String.format(java.util.Locale.US, "%.1fMB", b / 1048576.0);
        if (b > 1024) return String.format(java.util.Locale.US, "%dKB", b / 1024);
        return b + "B";
    }

    // ---------------- 充电 ----------------

    private void registerReceiver() {
        rx = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String a = intent.getAction();
                if (Intent.ACTION_BATTERY_CHANGED.equals(a)) {
                    int lvl = intent.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1);
                    int scale = intent.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100);
                    batteryPct = scale > 0 ? lvl * 100 / scale : lvl;
                    batteryLevel = batteryPct;
                    batteryPlugged = intent.getIntExtra(
                            android.os.BatteryManager.EXTRA_PLUGGED, 0) != 0;
                    if (!batteryPlugged) fullNotified = false;
                    if (batteryLevel > 25) lowNotified = false;
                    if (batteryPlugged && batteryLevel >= 100) {
                        if (Common.getB(IslandService.this, Common.K_SYS_FULL, true)
                                && !fullNotified) {
                            fullNotified = true;
                            showSys(IslandView.SYS_FULL, "已充满电",
                                    "系统事件 · 可以拔掉充电器", 0xFF38D98A, 3000);
                        }
                    } else if (!batteryPlugged && batteryLevel > 0 && batteryLevel <= 15) {
                        if (Common.getB(IslandService.this, Common.K_SYS_LOW, true)
                                && !lowNotified) {
                            lowNotified = true;
                            showSys(IslandView.SYS_LOW, "电量低 " + batteryLevel + "%",
                                    "系统事件 · 记得充电", 0xFFFF4D4D, 4000);
                        }
                    }
                } else if (Intent.ACTION_POWER_CONNECTED.equals(a)) {
                    if (Common.getB(IslandService.this, Common.K_CHARGE, true)) {
                        int p = batteryPct;
                        show(IslandView.KIND_CHARGE, "充电中 " + (p >= 0 ? p + "%" : ""),
                                "系统事件 · 已连接电源", getPackageName(), -1,
                                0xFFFFB23E, Math.min(3500, stayMs() / 2), stayMs());
                    }
                } else if (Intent.ACTION_POWER_DISCONNECTED.equals(a)) {
                    if (Common.getB(IslandService.this, Common.K_CHARGE, true)) {
                        int p = batteryPct;
                        show(IslandView.KIND_CHARGE, "已断开电源 " + (p >= 0 ? p + "%" : ""),
                                "系统事件 · 使用电池", getPackageName(), -1,
                                0xFFFFB23E, Math.min(3500, stayMs() / 2), stayMs());
                    }
                } else if (Intent.ACTION_SCREEN_OFF.equals(a)) {
                    removeIsland(true);
                } else if (Intent.ACTION_USER_PRESENT.equals(a)) {
                    if (Common.getB(IslandService.this, Common.K_SYS_UNLOCK, false)) {
                        showSys(IslandView.SYS_UNLOCK, "已解锁",
                                "系统事件 · 欢迎回来", 0xFF5EE7FF, 2200);
                    }
                } else if ("android.intent.action.HEADSET_PLUG".equals(a)) {
                    int st = intent.getIntExtra("state", -1);
                    boolean now = st == 1;
                    if (now != headsetOn && now) {
                        if (Common.getB(IslandService.this, Common.K_SYS_HEADSET, true)) {
                            showSys(IslandView.SYS_HEADSET, "耳机已连接",
                                    "系统事件 · 已切换音频输出", 0xFF9A6BFF, 2600);
                        }
                    }
                    headsetOn = now;
                } else if (android.media.AudioManager.RINGER_MODE_CHANGED_ACTION.equals(a)) {
                    int m = intent.getIntExtra(android.media.AudioManager.EXTRA_RINGER_MODE, -1);
                    if (m == lastRinger) return;
                    lastRinger = m;
                    if (!Common.getB(IslandService.this, Common.K_SYS_RINGER, true)) return;
                    if (m == android.media.AudioManager.RINGER_MODE_SILENT) {
                        showSys(IslandView.SYS_SILENT, "已静音", "系统事件 · 铃声模式",
                                0xFFFFB23E, 2200);
                    } else if (m == android.media.AudioManager.RINGER_MODE_VIBRATE) {
                        showSys(IslandView.SYS_VIBRATE, "已振动", "系统事件 · 铃声模式",
                                0xFFFFB23E, 2200);
                    } else if (m == android.media.AudioManager.RINGER_MODE_NORMAL) {
                        showSys(IslandView.SYS_RING, "铃声已开", "系统事件 · 铃声模式",
                                0xFF5EE7FF, 2200);
                    }
                }
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_BATTERY_CHANGED);
        f.addAction(Intent.ACTION_POWER_CONNECTED);
        f.addAction(Intent.ACTION_POWER_DISCONNECTED);
        f.addAction(Intent.ACTION_SCREEN_OFF);
        f.addAction(Intent.ACTION_USER_PRESENT);
        f.addAction("android.intent.action.HEADSET_PLUG");
        f.addAction(android.media.AudioManager.RINGER_MODE_CHANGED_ACTION);
        registerReceiver(rx, f);
    }

    private void showSys(int style, String title, String sub, int accent, long stay) {
        if (!Common.getB(this, Common.K_ISLAND, true)) return;
        if (!attach()) return;
        island.setSysStyle(style);
        show(IslandView.KIND_SYS, title, sub, getPackageName(), -1, accent,
                Math.min(3000, stayMs() / 2), stay);
    }

    private boolean isLandscape() {
        return getResources().getConfiguration().orientation
                == android.content.res.Configuration.ORIENTATION_LANDSCAPE;
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration cfg) {
        super.onConfigurationChanged(cfg);
        if (isLandscape()) {
            if (island != null && island.isIdle()) removeIsland(true);
        } else {
            // 回到竖屏：恢复音乐检测，并让横屏收起的岛回来
            boolean resume = landscapeMusicOff;
            landscapeMusicOff = false;
            if (resume) {
                cancelHiddenMusic();
                updateMusic();
            }
            if (!attached && pinned() && !preview) showIdle();
        }
        if (island != null && attached) {
            island.setPullClose(false);
            island.setHideBtn(lastKind == IslandView.KIND_MUSIC && isLandscape());
            if (subAttached && subLp != null) {
                subPillLeft = subPillTarget();
                subLp.x = subPillLeft - padS;
                try {
                    wm.updateViewLayout(sub, subLp);
                } catch (Exception ignored) {
                }
            }
        }
    }
}
