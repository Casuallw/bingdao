/*
 * 冰岛 (Bingdao) - Android 灵动岛
 * Copyright (c) 2026 casuallw (Gitee: casual-wear / GitHub: Casuallw)
 * All rights reserved. Licensed under the Bingdao Non-Commercial License 1.1.
 * 非商业许可：禁止商用、倒卖或收费分发。完整条款见项目根目录 LICENSE 文件。
 * https://gitee.com/casual-wear/bingdao
 */
package com.sihua.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;

/** 权限跳转：尽量直接落到「冰岛」自己的设置页，而不是一长串应用列表。 */
public final class Perm {
    private Perm() {}

    private static boolean open(Activity a, Intent i) {
        try {
            if (a.getPackageManager().resolveActivity(i, 0) == null) return false;
            a.startActivity(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static void tip(Activity a, String s) {
        Toast.makeText(a, s, Toast.LENGTH_LONG).show();
    }

    /** 通知使用权：Android 11+ 有「指定应用」的详情页。 */
    public static void notiListener(Activity a) {
        ComponentName cn = new ComponentName(a, NotificationListener.class);
        if (Build.VERSION.SDK_INT >= 30) {
            Intent d = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS);
            d.putExtra(Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME,
                    cn.flattenToString());
            if (open(a, d)) {
                tip(a, "已定位到「冰岛」的通知使用权页，请打开开关");
                return;
            }
        }
        Intent l = new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
        l.putExtra(":settings:fragment_args_key", cn.flattenToString());
        if (open(a, l)) {
            tip(a, "已打开通知使用权，请在列表中找到「冰岛」并开启");
            return;
        }
        appDetails(a);
    }

    /** 悬浮窗：直接按包名打开「冰岛」的授权页。 */
    public static void overlay(Activity a) {
        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + a.getPackageName()));
        if (open(a, i)) {
            tip(a, "请在「冰岛」的页面里允许显示在其他应用上层");
            return;
        }
        appDetails(a);
    }

    /** 无障碍：直接按组件名落到「冰岛」的服务页。 */
    public static void a11y(Activity a) {
        ComponentName cn = new ComponentName(a, SihuaA11y.class);
        if (Build.VERSION.SDK_INT >= 26) {
            Intent d = new Intent("android.settings.ACCESSIBILITY_DETAILS_SETTINGS");
            d.putExtra("android.provider.extra.ACCESSIBILITY_SERVICE_COMPONENT_NAME",
                    cn.flattenToString());
            d.putExtra("component_name", cn.flattenToString());
            if (open(a, d)) {
                tip(a, "已打开「冰岛」的无障碍开关页，打开即可");
                return;
            }
        }
        Intent l = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
        l.putExtra(":settings:fragment_args_key", cn.flattenToString());
        if (open(a, l)) {
            tip(a, "在无障碍列表里点「冰岛」");
            return;
        }
        appDetails(a);
        tip(a, "设置 → 无障碍 → 已下载的服务 →「冰岛」");
    }

    /** vivo 的「后台弹出界面 / 自启动」：落到「冰岛」自己的应用信息页。 */
    public static void vivoPopup(Activity a) {
        String[][] cs = {
                {"com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"},
                {"com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager"},
        };
        for (String[] c : cs) {
            try {
                Intent i = new Intent();
                i.setComponent(new ComponentName(c[0], c[1]));
                i.putExtra("package_name", a.getPackageName());
                i.putExtra("pkgName", a.getPackageName());
                if (a.getPackageManager().resolveActivity(i, 0) == null) continue;
                a.startActivity(i);
                tip(a, "只针对「冰岛」：把自启动 / 后台运行（vivo 叫后台弹出界面）都打开");
                return;
            } catch (Exception ignored) {
            }
        }
        appDetails(a);
        tip(a, "在「冰岛」的权限里打开：自启动、后台运行");
    }

    /** 电池：直接对「冰岛」请求忽略优化，厂商拦了就去应用信息页手动设。 */
    public static void battery(Activity a) {
        Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:" + a.getPackageName()));
        if (open(a, i)) return;
        appDetails(a);
        tip(a, "在「冰岛」的耗电 / 后台设置里允许后台运行");
    }

    /** 最后兜底：本应用的「应用信息」页。 */
    public static void appDetails(Activity a) {
        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + a.getPackageName()));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            a.startActivity(i);
            tip(a, "已打开「冰岛」的应用信息页");
        } catch (Exception ignored) {
        }
    }
}
