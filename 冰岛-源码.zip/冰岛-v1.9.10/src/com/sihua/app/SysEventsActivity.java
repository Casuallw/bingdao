/*
 * 冰岛 (Bingdao) - Android 灵动岛
 * Copyright (c) 2026 casuallw (Gitee: casual-wear / GitHub: Casuallw)
 * All rights reserved. Licensed under the Bingdao Non-Commercial License 1.1.
 * 非商业许可：禁止商用、倒卖或收费分发。完整条款见项目根目录 LICENSE 文件。
 * https://gitee.com/casual-wear/bingdao
 */
package com.sihua.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Point;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

/** 系统事件：哪些系统动作要在灵动岛上提示。 */
public class SysEventsActivity extends Activity {

    private LinearLayout list;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Window win = getWindow();
        win.setStatusBarColor(Color.TRANSPARENT);
        win.setNavigationBarColor(Ui.BG);
        win.getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        Point p = new Point();
        win.getWindowManager().getDefaultDisplay().getSize(p);
        FrameLayout root = new FrameLayout(this);
        root.setBackground(new Ui.GlowDrawable(p.x, p.y));
        ScrollView sv = new ScrollView(this);
        sv.setClipToPadding(false);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(Ui.dp(this, 20), Ui.dp(this, 46), Ui.dp(this, 20), Ui.dp(this, 30));
        sv.addView(list, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT));
        root.addView(sv, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        build();
    }

    private void build() {
        list.removeAllViews();

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView back = Ui.text(this, "‹", 30, Ui.TEXT, false);
        back.setPadding(0, 0, Ui.dp(this, 12), Ui.dp(this, 4));
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        head.addView(back);
        head.addView(Ui.text(this, "系统事件", 22, Ui.TEXT, true));
        list.addView(head);

        TextView tip = Ui.text(this,
                "选中的系统动作会像消息一样在灵动岛上弹一下，播放器 / 消息不受影响。",
                12, Ui.SUB, false);
        tip.setLineSpacing(0, 1.35f);
        LinearLayout.LayoutParams tlp2 = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tlp2.topMargin = Ui.dp(this, 10);
        tlp2.bottomMargin = Ui.dp(this, 6);
        list.addView(tip, tlp2);

        LinearLayout card = Ui.card(this);
        card.setPadding(Ui.dp(this, 14), Ui.dp(this, 4), Ui.dp(this, 14), Ui.dp(this, 4));
        toggleRow(card, "充电 / 断电", "插上或拔掉充电器时提示", Common.K_CHARGE, true);
        Ui.divider(this, card);
        toggleRow(card, "解锁手机", "屏幕解锁时提示已解锁", Common.K_SYS_UNLOCK, false);
        Ui.divider(this, card);
        toggleRow(card, "耳机连接", "插上耳机 / 连上蓝牙耳机时提示", Common.K_SYS_HEADSET, true);
        Ui.divider(this, card);
        toggleRow(card, "充满电", "电量到 100% 时提示可以拔掉充电器", Common.K_SYS_FULL, true);
        Ui.divider(this, card);
        toggleRow(card, "低电量", "电量低于 15% 时提示", Common.K_SYS_LOW, true);
        Ui.divider(this, card);
        toggleRow(card, "铃声模式", "静音 / 振动 / 铃声切换时提示", Common.K_SYS_RINGER, true);
        list.addView(card);

        TextView note = Ui.text(this,
                "这些提示都走灵动岛的同一条通道：有消息来了会先让消息显示，最多两三秒后自动收掉。",
                11.5f, Ui.DIM, false);
        note.setLineSpacing(0, 1.4f);
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        nlp.topMargin = Ui.dp(this, 14);
        nlp.leftMargin = Ui.dp(this, 4);
        list.addView(note, nlp);
    }

    private void toggleRow(LinearLayout parent, String title, String sub,
                           final String key, boolean def) {
        Switch sw = Ui.toggle(this, Common.getB(this, key, def));
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean v) {
                Common.setB(SysEventsActivity.this, key, v);
            }
        });
        final Switch fsw = sw;
        LinearLayout row = Ui.clickRow(this, Ui.row(this, title, sub, 0, sw),
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        fsw.toggle();
                    }
                });
        parent.addView(row);
    }
}
