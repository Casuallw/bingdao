/*
 * 冰岛 (Bingdao) - Android 灵动岛
 * Copyright (c) 2026 casuallw (Gitee: casual-wear / GitHub: Casuallw)
 * All rights reserved. Licensed under the Bingdao Non-Commercial License 1.1.
 * 非商业许可：禁止商用、倒卖或收费分发。完整条款见项目根目录 LICENSE 文件。
 * https://gitee.com/casual-wear/bingdao
 */
package com.sihua.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/**
 * 主岛与副岛之间那条「液态桥」：两端较粗、中间略细，两侧是凹进去的弧线。
 * 纯黑、不描边，盖在两边岛的接缝上，看上去就是同一个形状被拉开。
 */
class NeckView extends View {

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private float endFrac = 0.74f;
    private float midFrac = 0.46f;

    NeckView(Context c) {
        super(c);
        paint.setColor(0xFF000000);
    }

    /** 两端 / 中间的高度占窗口高度的比例。 */
    void setShape(float end, float mid) {
        if (Math.abs(end - endFrac) < 0.005f && Math.abs(mid - midFrac) < 0.005f) return;
        endFrac = Math.max(0.05f, Math.min(1f, end));
        midFrac = Math.max(0.03f, Math.min(1f, mid));
        invalidate();
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth();
        float h = getHeight();
        if (w <= 0 || h <= 0) return;
        float mid = h / 2f;
        float e = h * endFrac / 2f;
        float m = h * midFrac / 2f;
        if (m > e) m = e;
        path.reset();
        path.moveTo(0, mid - e);
        path.cubicTo(w * 0.30f, mid - e, w * 0.34f, mid - m, w * 0.5f, mid - m);
        path.cubicTo(w * 0.66f, mid - m, w * 0.70f, mid - e, w, mid - e);
        path.lineTo(w, mid + e);
        path.cubicTo(w * 0.70f, mid + e, w * 0.66f, mid + m, w * 0.5f, mid + m);
        path.cubicTo(w * 0.34f, mid + m, w * 0.30f, mid + e, 0, mid + e);
        path.close();
        cv.drawPath(path, paint);
    }
}
