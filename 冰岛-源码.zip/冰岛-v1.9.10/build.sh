#!/bin/bash
set -e
cd "$(dirname "$0")"
SDK=/root/sdk/platforms/android-34/android.jar
AAPT2=/usr/bin/aapt2
D8=/root/dl/bt/android-14/lib/d8.jar
rm -rf out && mkdir -p out/gen out/classes out/dex
$AAPT2 compile --dir res -o out/res.zip
ASSETS=""
[ -d assets ] && ASSETS="-A assets"
$AAPT2 link -o out/base.apk -I $SDK --manifest AndroidManifest.xml out/res.zip $ASSETS \
  --java out/gen --min-sdk-version 26 --target-sdk-version 33 \
  --version-code 59 --version-name 1.9.10 --auto-add-overlay
find src out/gen -name "*.java" > out/sources.txt
javac -encoding UTF-8 -source 1.8 -target 1.8 -nowarn \
  -classpath $SDK -d out/classes @out/sources.txt
find out/classes -name "*.class" > out/classes.txt
java -cp $D8 com.android.tools.r8.D8 --release --min-api 26 --lib $SDK \
  --output out/dex @out/classes.txt
python3 - <<'PY'
import zipfile, shutil
shutil.copy("out/base.apk", "out/unsigned.apk")
with zipfile.ZipFile("out/unsigned.apk", "a", zipfile.ZIP_DEFLATED) as z:
    z.write("out/dex/classes.dex", "classes.dex")
print("dex injected")
PY
zipalign -f 4 out/unsigned.apk out/aligned.apk
if [ ! -f keystore.jks ]; then
  keytool -genkeypair -keystore keystore.jks -alias sihua -keyalg RSA -keysize 2048 \
    -validity 10000 -storepass sihua123 -keypass sihua123 -dname "CN=Sihua, O=Sihua" >/dev/null 2>&1
fi
apksigner sign --ks keystore.jks --ks-pass pass:sihua123 --key-pass pass:sihua123 \
  --out out/sihua.apk out/aligned.apk
apksigner verify --print-certs out/sihua.apk | head -2
ls -lh out/sihua.apk
